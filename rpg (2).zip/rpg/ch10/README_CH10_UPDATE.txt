ZERAPHIA STORY10 UI/背景当たり判定更新

更新: rpg/ch10/ 配下のみ。既存の同じ場所へ上書き。
背景: images/bg_garden.webp（モックのフィールド領域から作成、UIなし）
UI: ui_header.webp, ui_frame.png, ui_stick_base.png, ui_action.png, ui_menu.png
キャラ: 既存のWebPを保持、ノベル台詞もそのまま
当たり判定: rpg.js 内 GARDEN_OBSTACLES を参照。画像内の柱・瓦礫の概略矩形に対応（手動微調整可能）
注意: 画面サイズの違いは座標正規化で処理。実ブラウザ検証は未実施。
