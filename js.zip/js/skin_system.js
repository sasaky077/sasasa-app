(function(){
  'use strict';

  const SKIN_MASTER = {
    112: {
      limited_01: {
        id:'limited_01',
        name:'雪桜',
        img:'images/chara_112_b.webp',
        home:'images/chara_112_b_cut.webp',
        panel:'images/chara_112_b_panel.webp',
        battle:'images/chara_112_b_battle_back.webp',
        cutin:'images/chara_112_b_cutin.webp',
        exchangeCost:3,
        exchangeItem:'flower_sr'
      }
    },
    3: {
      limited_01: {
        id:'limited_01',
        name:'カエル',
        img:'images/chara_03_b.webp',   // build1465: 限定衣装の立ち絵（キャラ詳細用）
        home:'images/chara_03_b_cut.webp',
        panel:'images/chara_03_b_panel.webp',
        battle:'images/chara_03_b_battle_back.webp', // build1477: 限定衣装のバトルユニット（背面）
        exchangeCost:10
      }
    },
    9: {
      limited_01: {
        id:'limited_01',
        name:'青い春',
        img:'images/chara_09_b.webp',   // build1465: 限定衣装の立ち絵（キャラ詳細用）
        home:'images/chara_09_b_cut.webp',
        panel:'images/chara_09_b_panel.webp',
        battle:'images/chara_09_b_battle_back.webp', // build1477: 限定衣装のバトルユニット（背面）
        exchangeCost:10
      }
    },
    20: {
      limited_01: {
        id:'limited_01',
        name:'闇夜',
        img:'images/chara_20_b.webp',   // build1465: 限定衣装の立ち絵（キャラ詳細用）
        home:'images/chara_20_b_cut.webp',
        panel:'images/chara_20_b_panel.webp',
        battle:'images/chara_20_b_battle_back.webp', // build1477: 限定衣装のバトルユニット（背面）
        exchangeCost:10
      }
    },
    36: {
      limited_01: {
        id:'limited_01',
        name:'給仕',
        img:'images/chara_36_b.webp',   // build1465: 限定衣装の立ち絵（キャラ詳細用）
        home:'images/chara_36_b_cut.webp',
        panel:'images/chara_36_b_panel.webp',
        battle:'images/chara_36_b_battle_back.webp', // build1477: 限定衣装のバトルユニット（背面）
        exchangeCost:10
      }
    },
    // build1705: レオナクロス ハロウィン衣装。ULTカットイン（cutin）とTRAPの設置物（battleObject）も衣装版になる。
    39: {
      limited_01: {
        id:'limited_01',
        name:'収穫祭',
        img:'images/chara_39_b.webp',                       // キャラ詳細の立ち絵（背景つき）
        home:'images/chara_39_b_cut.webp',                  // ホーム（全身・透過）
        panel:'images/chara_39_b_panel.webp',               // パネル（バストアップ・透過）
        battle:'images/chara_39_b_battle_back.webp',        // バトルユニット（背面・透過）
        cutin:'images/chara_39_b_cutin.webp',               // ULTカットイン（横長）
        battleObject:'images/chara_39_b_battle_object.webp',// TRAPの設置物（かぼちゃ・透過）
        // build1706: お知らせのプレゼントで全員に配布（聖霊花交換なし）
        gift:true
      }
    },
    // build2146: アヤネ（正装）。入手はガチャ・イベント報酬で配布予定のため hidden（所持者にだけ衣装欄に出る）。
    //   付与：player_character_skins に (user_id, 11, 'limited_01')。
    11: {
      limited_01: {
        id:'limited_01',
        name:'正装',
        img:'images/chara_11_b.webp',               // キャラ詳細の立ち絵（背景つき）
        home:'images/chara_11_b_cut.webp',          // ホーム（全身・透過）
        panel:'images/chara_11_b_panel.webp',       // パネル（バストアップ）
        battle:'images/chara_11_b_battle_back.webp',// バトルユニット（背面）
        cutin:'images/chara_11_b_cutin.webp',       // ULTカットイン（横長）
        hidden:true
      }
    },
    // build1709: トワ 衣装違い。入手経路は未実装のため hidden（所持者にだけ衣装欄に出る）。
    //   配布するときは player_character_skins に (user_id, 101, 'limited_01') を付与すればそのまま着替えられる。
    //   名前を決めたら name を変えるだけでよい。
    101: {
      limited_01: {
        id:'limited_01',
        name:'限定衣装',
        img:'images/chara_101_b.webp',               // キャラ詳細の立ち絵（背景つき）
        home:'images/chara_101_b_cut.webp',          // ホーム（全身・透過）
        panel:'images/chara_101_b_panel.webp',       // パネル（バストアップ・透過）
        battle:'images/chara_101_b_battle_back.webp',// バトルユニット（背面・透過）
        cutin:'images/chara_101_b_cutin.webp',       // ULTカットイン（横長）
        hidden:true
      }
    }
  };

  const state = {
    loaded:false,
    loading:false,
    owned:new Set(),
    equipped:new Map(),
    publicEquipped:new Map()
  };

  function key(characterId, skinId){
    return String(Number(characterId||0)) + ':' + String(skinId||'');
  }

  function currentUserId(){
    return String(localStorage.getItem('zukan_user_id') || '').trim().toLowerCase();
  }

  function client(){
    return window.zsSupabase || null;
  }

  function chara(characterId){
    const id=Number(characterId||0);
    const list=Array.isArray(window.CHARACTERS) ? window.CHARACTERS : [];
    return list.find(c=>c && Number(c.id)===id) || null;
  }

  function defaultHome(characterId, fallback){
    const c=chara(characterId);
    return String(fallback || (c && c.cutImg) || ('images/chara_'+String(Number(characterId||0)).padStart(2,'0')+'_cut.webp'));
  }

  function defaultPanel(characterId, fallback){
    const c=chara(characterId);
    return String(fallback || (c && (c.panelImg||c.img)) || ('images/chara_'+String(Number(characterId||0)).padStart(2,'0')+'_panel.webp'));
  }

  function getSkin(characterId, skinId){
    const group=SKIN_MASTER[Number(characterId||0)];
    return group ? (group[String(skinId||'')] || null) : null;
  }

  // build1709: hidden の衣装（入手経路が未実装）は、所持していない人には一覧に出さない
  function getSkins(characterId){
    const group=SKIN_MASTER[Number(characterId||0)] || {};
    return Object.values(group).filter(skin=>!skin.hidden || isOwned(characterId,skin.id));
  }

  function hasSkins(characterId){
    return getSkins(characterId).length > 0;
  }

  function isOwned(characterId, skinId){
    if(!skinId || skinId==='default') return true;
    return state.owned.has(key(characterId,skinId));
  }

  function getEquippedSkinId(characterId){
    return state.equipped.get(Number(characterId||0)) || 'default';
  }

  function getHomeImage(characterId, fallback){
    const skinId=getEquippedSkinId(characterId);
    const skin=getSkin(characterId,skinId);
    return skin && isOwned(characterId,skinId) ? skin.home : defaultHome(characterId,fallback);
  }

  function getPanelImage(characterId, fallback){
    const skinId=getEquippedSkinId(characterId);
    const skin=getSkin(characterId,skinId);
    return skin && isOwned(characterId,skinId) ? skin.panel : defaultPanel(characterId,fallback);
  }

  async function loadMySkins(force){
    if(state.loading) return false;
    if(state.loaded && !force) return true;

    const sb=client();
    const userId=currentUserId();
    if(!sb || !userId) return false;

    state.loading=true;
    try{
      const [ownedRes,equippedRes]=await Promise.all([
        sb.from('player_character_skins')
          .select('character_id,skin_id')
          .eq('user_id',userId),
        sb.from('player_equipped_character_skins')
          .select('character_id,skin_id')
          .eq('user_id',userId)
      ]);

      if(ownedRes && ownedRes.error) throw ownedRes.error;
      if(equippedRes && equippedRes.error) throw equippedRes.error;

      state.owned.clear();
      (ownedRes && ownedRes.data || []).forEach(row=>{
        state.owned.add(key(row.character_id,row.skin_id));
      });

      state.equipped.clear();
      (equippedRes && equippedRes.data || []).forEach(row=>{
        const charId=Number(row.character_id||0);
        const skinId=String(row.skin_id||'');
        if(charId && getSkin(charId,skinId) && state.owned.has(key(charId,skinId))){
          state.equipped.set(charId,skinId);
        }
      });

      state.loaded=true;
      try{window.dispatchEvent(new CustomEvent('zeraphia:skins-loaded'));}catch(_){}
      if(typeof window.updateMainUI==='function'){
        try{window.updateMainUI();}catch(_){}
      }
      return true;
    }catch(err){
      console.warn('[CharacterSkins] load skipped',err&&err.message||err);
      return false;
    }finally{
      state.loading=false;
    }
  }

  async function equip(characterId, skinId){
    const charId=Number(characterId||0);
    const next=String(skinId||'default');
    if(!charId) return false;

    if(next!=='default' && !isOwned(charId,next)){
      if(typeof window.showToast==='function') window.showToast('この衣装は未所持です');
      return false;
    }

    const sb=client();
    const userId=currentUserId();
    if(!sb || !userId) return false;

    try{
      const res=await sb.rpc('equip_character_skin',{
        p_user_id:userId,
        p_character_id:charId,
        p_skin_id:next
      });
      if(res && res.error) throw res.error;

      if(next==='default') state.equipped.delete(charId);
      else state.equipped.set(charId,next);

      state.publicEquipped.delete(userId+':'+charId);

      try{window.dispatchEvent(new CustomEvent('zeraphia:skin-changed',{detail:{characterId:charId,skinId:next}}));}catch(_){}
      if(typeof window.updateMainUI==='function'){
        try{window.updateMainUI();}catch(_){}
      }

      // build1070: character box / character detail image follows equipped skin too.
      try{
        if(Number(window.currentZukanDetailCharaId||0)===charId && typeof window.renderBoxDetail==='function'){
          window.renderBoxDetail(charId);
        }else{
          var zukanScreen=document.getElementById('screen-zukan');
          if(zukanScreen && zukanScreen.classList.contains('active') && typeof window.renderBox==='function'){
            window.renderBox();
          }
        }
      }catch(_){}

      // build1708: 旧キャラ詳細モーダル（#detail-modal）は、開いている時だけ描き直す。
      // 新しいキャラ詳細画面も currentDetailData を持つため、無条件に呼ぶと閉じていた旧画面が開いてしまっていた。
      var oldDetail=document.getElementById('detail-modal');
      if(oldDetail && oldDetail.classList.contains('active') &&
         window.currentDetailData && Number(window.currentDetailData.id)===charId && typeof window.showDetail==='function'){
        try{window.showDetail(window.currentDetailData,false);}catch(_){}
      }

      if(typeof window.showToast==='function'){
        window.showToast(next==='default' ? '通常衣装に変更しました' : skinLabel(getSkin(charId,next))+'に変更しました');
      }
      return true;
    }catch(err){
      console.error('[CharacterSkins] equip failed',err);
      if(typeof window.showToast==='function') window.showToast(err&&err.message?err.message:'衣装変更に失敗しました');
      return false;
    }
  }

  function isCharacterOwned(characterId){
    const id=Number(characterId||0);
    try{
      if(window.collected && window.collected[id]) return true;
      if(Array.isArray(window.box) && window.box.some(x=>x&&Number(x.id)===id)) return true;
    }catch(_){}
    return false;
  }

  function esc(v){
    return String(v==null?'':v)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#39;');
  }

  function buildFullscreenControlsHTML(charaDef){
    const charId=Number(charaDef && charaDef.id || 0);
    if(!charId || !hasSkins(charId) || !isCharacterOwned(charId)) return '';

    const limited=getSkins(charId)[0];
    if(!limited) return '';

    const equipped=getEquippedSkinId(charId);
    const owned=isOwned(charId,limited.id);

    return ''+
      '<div class="primor-skin-controls" onclick="event.stopPropagation()">'+
        '<div class="primor-skin-controls-label">衣装</div>'+
        '<div class="primor-skin-controls-buttons">'+
          '<button type="button" class="primor-skin-choice'+(equipped==='default'?' is-selected':'')+'" data-skin-choice="default">'+
            '<span>通常</span>'+
            '<small class="primor-skin-choice-state">'+(equipped==='default'?'装備中':'変更')+'</small>'+
          '</button>'+
          '<button type="button" class="primor-skin-choice'+(equipped===limited.id?' is-selected':'')+(owned?'':' is-locked')+'" '+
            'data-skin-choice="'+esc(limited.id)+'" '+(owned?'':'disabled')+'>'+
            '<span>'+esc(skinLabel(limited))+'</span>'+
            '<small class="primor-skin-choice-state">'+(owned ? (equipped===limited.id?'装備中':'変更') : '未所持')+'</small>'+
          '</button>'+
        '</div>'+
      '</div>';
  }

  function buildSelectorHTML(data){
    const charId=Number(data && data.id || 0);
    if(!charId || !hasSkins(charId) || !isCharacterOwned(charId)) return '';

    const equipped=getEquippedSkinId(charId);
    const c=chara(charId) || data || {};
    const normalPanel=defaultPanel(charId,c.panelImg||c.img||'');
    const limited=getSkins(charId)[0];
    const owned=isOwned(charId,limited.id);

    return ''+
      '<div class="detail-shooting-section detail-skin-section">'+
        '<div class="detail-section-title">衣装</div>'+
        '<div class="detail-skin-options">'+
          '<button type="button" class="detail-skin-card'+(equipped==='default'?' is-selected':'')+'" onclick="CharacterSkins.equip('+charId+',\'default\')">'+
            '<span class="detail-skin-thumb"><img src="'+esc(normalPanel)+'" alt="" onerror="this.style.display=\'none\'"></span>'+
            '<span class="detail-skin-copy"><strong>通常</strong><small>'+(equipped==='default'?'装備中':'変更')+'</small></span>'+
          '</button>'+
          '<button type="button" class="detail-skin-card detail-skin-limited'+(equipped===limited.id?' is-selected':'')+(owned?'':' is-locked')+'" '+
            (owned ? 'onclick="CharacterSkins.equip('+charId+',\''+esc(limited.id)+'\')"' : 'disabled')+'>'+
            '<span class="detail-skin-thumb"><img src="'+esc(limited.panel)+'" alt="" onerror="this.style.display=\'none\'"></span>'+
            '<span class="detail-skin-copy"><strong>'+esc(skinLabel(limited))+'</strong><small>'+(owned ? (equipped===limited.id?'装備中':'変更') : (limited.gift?'未所持・お知らせのプレゼント':'未所持・聖霊花交換'))+'</small></span>'+
          '</button>'+
        '</div>'+
      '</div>';
  }

  // build1466: 自分のキャラ詳細の立ち絵。装備中かつ所持中の衣装があれば立ち絵（無ければhome）、なければ fallback。
  function getPortraitImage(characterId, fallback){
    const skinId=getEquippedSkinId(characterId);
    const skin=getSkin(characterId,skinId);
    return skin && isOwned(characterId,skinId) ? (skin.img || skin.home) : String(fallback||'');
  }

  // build1477: バトルユニット（背面）画像。装備中かつ所持中の衣装があればその画像、なければ fallback。
  function getBattleImage(characterId, fallback){
    const skinId=getEquippedSkinId(characterId);
    const skin=getSkin(characterId,skinId);
    return skin && skin.battle && isOwned(characterId,skinId) ? skin.battle : String(fallback||'');
  }

  // build1705: ULTカットイン／設置物（TRAP等）の衣装版。装備中かつ所持中で、その衣装に画像が設定されていれば返す。
  function getCutinImage(characterId, fallback){
    const skinId=getEquippedSkinId(characterId);
    const skin=getSkin(characterId,skinId);
    return skin && skin.cutin && isOwned(characterId,skinId) ? skin.cutin : String(fallback||'');
  }
  function getBattleObjectImage(characterId, fallback){
    const skinId=getEquippedSkinId(characterId);
    const skin=getSkin(characterId,skinId);
    return skin && skin.battleObject && isOwned(characterId,skinId) ? skin.battleObject : String(fallback||'');
  }
  function skinLabel(skin){ return (skin && skin.name) || '限定衣装'; }

  // build2231: 他のプレイヤーの装備中衣装。
  //  ・まずサーバー関数 get_public_equipped_skins（RLSを越えて「装備中の衣装だけ」返す）でまとめて取得
  //  ・関数が無い／失敗した時は従来どおりテーブルを直接読む（user_id は小文字化せず元の値で照会）
  //  ・取得失敗は記録しない（次回また取りに行く）。成功結果も5分で取り直す（相手が着替えても反映される）
  const PUBLIC_TTL=5*60*1000;
  const publicFetchedAt=new Map(); // uidLower -> time
  let publicRpcMissing=false;

  function putPublic(uidLower, rows){
    // その人の全キャラをいったん通常扱いにしてから、返ってきた衣装を入れる
    for(const k of Array.from(state.publicEquipped.keys())){ if(k.indexOf(uidLower+':')===0) state.publicEquipped.delete(k); }
    (rows||[]).forEach(r=>{
      const cid=Number(r.character_id||0), sid=String(r.skin_id||'');
      if(cid && sid && getSkin(cid,sid)) state.publicEquipped.set(uidLower+':'+cid, sid);
    });
    publicFetchedAt.set(uidLower, Date.now());
  }

  async function preloadPublicEquipped(userIds){
    const sb=client();
    const ids=Array.from(new Set((userIds||[]).map(v=>String(v||'').trim()).filter(Boolean)));
    if(!sb || !ids.length || publicRpcMissing) return false;
    const need=ids.filter(id=>{ const t=publicFetchedAt.get(id.toLowerCase()); return !t || Date.now()-t>PUBLIC_TTL; });
    if(!need.length) return true;
    try{
      const res=await sb.rpc('get_public_equipped_skins',{ p_user_ids: need });
      if(res && res.error) throw res.error;
      const byUser=new Map();
      (res && res.data || []).forEach(r=>{
        const u=String(r.user_id||'').trim().toLowerCase();
        if(!byUser.has(u)) byUser.set(u,[]);
        byUser.get(u).push(r);
      });
      need.forEach(id=>{ const u=id.toLowerCase(); putPublic(u, byUser.get(u)||[]); });
      return true;
    }catch(err){
      const msg=String(err && (err.message||err.code) || err);
      if(/PGRST202|does not exist|Could not find the function/i.test(msg)) publicRpcMissing=true;
      console.warn('[CharacterSkins] public skins rpc skipped',msg);
      return false;
    }
  }

  async function getPublicEquippedSkinId(userId, characterId){
    const rawUid=String(userId||'').trim();
    const uid=rawUid.toLowerCase();
    const charId=Number(characterId||0);
    if(!uid || !charId) return 'default';

    if(uid===currentUserId()) return getEquippedSkinId(charId);

    const cacheKey=uid+':'+charId;
    const fetchedAt=publicFetchedAt.get(uid);
    const fresh=fetchedAt && Date.now()-fetchedAt<=PUBLIC_TTL;
    if(fresh) return state.publicEquipped.get(cacheKey) || 'default';

    if(await preloadPublicEquipped([rawUid])) return state.publicEquipped.get(cacheKey) || 'default';

    const sb=client();
    if(!sb) return 'default';
    try{
      const res=await sb.from('player_equipped_character_skins')
        .select('character_id,skin_id')
        .eq('user_id',rawUid);
      if(res && res.error) throw res.error;
      putPublic(uid, res && res.data || []);
      return state.publicEquipped.get(cacheKey) || 'default';
    }catch(err){
      console.warn('[CharacterSkins] public skin load skipped',err&&err.message||err);
      return 'default';
    }
  }

  async function getPublicPanelImage(userId, characterId, fallback){
    const charId=Number(characterId||0);
    const skinId=await getPublicEquippedSkinId(userId,charId);
    const skin=getSkin(charId,skinId);
    return skin ? skin.panel : defaultPanel(charId,fallback);
  }

  // build1464: フレンドのキャラ詳細用。相手が装備中の衣装のホーム用画像（home）を返す。未装備なら fallback。
  async function getPublicHomeImage(userId, characterId, fallback){
    const charId=Number(characterId||0);
    const skinId=await getPublicEquippedSkinId(userId,charId);
    const skin=getSkin(charId,skinId);
    return skin ? skin.home : String(fallback||'');
  }

  // build1465: キャラ詳細の立ち絵。衣装の立ち絵（img: chara_XX_b.webp）を優先し、無ければ home。未装備なら fallback。
  async function getPublicPortraitImage(userId, characterId, fallback){
    const charId=Number(characterId||0);
    const skinId=await getPublicEquippedSkinId(userId,charId);
    const skin=getSkin(charId,skinId);
    return skin ? (skin.img || skin.home) : String(fallback||'');
  }

  function notifySkinAcquired(characterId, skinId){
    const charId=Number(characterId||0);
    const id=String(skinId||'');
    if(charId && getSkin(charId,id)){
      state.owned.add(key(charId,id));
      state.loaded=true;
      try{window.dispatchEvent(new CustomEvent('zeraphia:skins-loaded'));}catch(_){}
    }
  }

  window.CharacterSkins = {
    MASTER:SKIN_MASTER,
    loadMySkins,
    reloadMySkins:()=>loadMySkins(true),
    hasSkins,
    isOwned,
    getSkin,
    getSkins,
    getEquippedSkinId,
    getHomeImage,
    getPanelImage,
    getPortraitImage,
    getBattleImage,
    getCutinImage,
    getBattleObjectImage,
    getPublicPanelImage,
    getPublicHomeImage,
    getPublicPortraitImage,
    getPublicEquippedSkinId,
    preloadPublicEquipped,
    buildSelectorHTML,
    buildFullscreenControlsHTML,
    equip,
    notifySkinAcquired,
    isCharacterOwned,
    // build2147: 所持している衣装の一覧（キャラ未所持の衣装も含む）。アイテム画面の「衣装」用
    listOwnedSkins:()=>{
      const out=[];
      Object.keys(SKIN_MASTER).forEach(cid=>{
        Object.values(SKIN_MASTER[cid]||{}).forEach(skin=>{
          if(state.owned.has(key(cid,skin.id))) out.push({characterId:Number(cid),skin});
        });
      });
      return out;
    },
    isLoaded:()=>state.loaded
  };

  function boot(attempt){
    if(currentUserId() && client()){
      loadMySkins(true);
      return;
    }
    if((attempt||0)<20) setTimeout(()=>boot((attempt||0)+1),250);
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',()=>boot(0),{once:true});
  }else{
    boot(0);
  }
})();
