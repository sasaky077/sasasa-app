// Zeraphia Shooting - standalone stage master
// Strategy stages.js is NOT referenced.
// CHAPTER 01 foundation: 01-03 normal mission stages / 04 boss.
(function () {
  'use strict';

  if (!window.ShootingEnemies) {
    throw new Error('shooting_stages.js requires shooting_enemies.js');
  }

  const { SHOOTING_ENEMY_ID } = window.ShootingEnemies;

  const SHOOTING_MISSION_TYPE = Object.freeze({
    COLLECT_ITEM: 'collect_item',
    CLEAR_TIME: 'clear_time',
    MAX_HITS_TAKEN: 'max_hits_taken',
    BOSS_CLEAR: 'boss_clear',
    DEFEAT_ALL: 'defeat_all',

    // Future mission types reserved for later chapters.
    MAX_COMBO: 'max_combo',
    MIN_ULT_USE: 'min_ult_use',
    MIN_SWITCH_COUNT: 'min_switch_count',
    NO_DOWN: 'no_down',
    SCORE: 'score',
    SURVIVE_TIME: 'survive_time',
  });

  const SHOOTING_CHAPTER_TITLES = {
    get 1() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch01_01']?.chapterTitle || '白の戦線'; },
    get 2() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch02_01']?.chapterTitle || '残骸'; },
    get 3() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch03_01']?.chapterTitle || '魂との邂逅'; },
    get 4() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch04_01']?.chapterTitle || '水音'; },
    get 5() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch05_01']?.chapterTitle || '円環'; },
    get 6() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch06_01']?.chapterTitle || '来訪者'; },
    get 7() { const s=window.ZERAPHIA_STORY_SCENARIO||{}; return s.shooting_ch07_01?.chapterTitle || s.shooting_ch07_03?.chapterTitle || '未定'; },
    get 8() { return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch08_01?.chapterTitle || '七つの塔'; }
  };

  const SHOOTING_STAGE_ID = Object.freeze({
    GACHA_TRIAL: 'shooting_gacha_trial', // 勧誘画面専用・非保存の無限試遊
    CH01_01: 'shooting_ch01_01',
    CH01_02: 'shooting_ch01_02',
    CH01_03: 'shooting_ch01_03',
    CH01_04: 'shooting_ch01_04',

    CH02_01: 'shooting_ch02_01',
    CH02_02: 'shooting_ch02_02',
    CH02_03: 'shooting_ch02_03',
    CH02_04: 'shooting_ch02_04',

    CH03_01: 'shooting_ch03_01',
    CH03_02: 'shooting_ch03_02',
    CH03_03: 'shooting_ch03_03',
    CH03_04: 'shooting_ch03_04',

    CH04_01: 'shooting_ch04_01',
    CH04_02: 'shooting_ch04_02',
    CH04_03: 'shooting_ch04_03',
    CH04_04: 'shooting_ch04_04',

    CH05_01: 'shooting_ch05_01',
    CH05_02: 'shooting_ch05_02',
    CH05_03: 'shooting_ch05_03',
    CH05_04: 'shooting_ch05_04',

    CH06_01: 'shooting_ch06_01',
    CH06_02: 'shooting_ch06_02',
    CH06_03: 'shooting_ch06_03',
    CH06_04: 'shooting_ch06_04',

    CH07_01: 'shooting_ch07_01',
    CH07_02: 'shooting_ch07_02',
    CH07_03: 'shooting_ch07_03',
    CH07_04: 'shooting_ch07_04',

    CH08_01: 'shooting_ch08_01',
    CH08_02: 'shooting_ch08_02',
    CH08_03: 'shooting_ch08_03',
    CH08_04: 'shooting_ch08_04',

    DAILY_MON_INTERMEDIATE: 'shooting_daily_mon_intermediate',
    DAILY_MON_ADVANCED: 'shooting_daily_mon_advanced',
    DAILY_TUE_INTERMEDIATE: 'shooting_daily_tue_intermediate',
    DAILY_TUE_ADVANCED: 'shooting_daily_tue_advanced',
    DAILY_WED_INTERMEDIATE: 'shooting_daily_wed_intermediate',
    DAILY_WED_ADVANCED: 'shooting_daily_wed_advanced',
    DAILY_THU_INTERMEDIATE: 'shooting_daily_thu_intermediate',
    DAILY_THU_ADVANCED: 'shooting_daily_thu_advanced',
    DAILY_FRI_INTERMEDIATE: 'shooting_daily_fri_intermediate',
    DAILY_FRI_ADVANCED: 'shooting_daily_fri_advanced',
    DAILY_SAT_INTERMEDIATE: 'shooting_daily_sat_intermediate',
    DAILY_SAT_ADVANCED: 'shooting_daily_sat_advanced',
    DAILY_SUN_INTERMEDIATE: 'shooting_daily_sun_intermediate',
    DAILY_SUN_ADVANCED: 'shooting_daily_sun_advanced',
    DAILY_EXP_INTERMEDIATE: 'shooting_daily_exp_intermediate',
    DAILY_EXP_ADVANCED: 'shooting_daily_exp_advanced',

    FACELESS_ADVANCED: 'shooting_event_faceless_advanced',
    FACELESS_SUPER: 'shooting_event_faceless_super',
    RAID_TEST: 'shooting_raid_test',
    BULLET_HELL_TEST: 'shooting_event_bullet_hell_test',
    SCORE_ATTACK_NORMAL: 'shooting_score_attack_normal',
    SCORE_ATTACK_HARD: 'shooting_score_attack_hard',
    OVERSEER_AMBUSH: 'shooting_event_overseer_ambush',
  });

  // ============================================================
  // CHAPTER 01
  // ============================================================
  //
  // 01 朝:
  //   収集を覚えるステージ
  //
  // 02 呼吸:
  //   攻撃効率 / キャラ交代を意識するタイムアタック
  //
  // 03 邂逅:
  //   赤コアを意識して避ける被弾管理
  //
  // 04 旅立ち:
  //   竜型レムナントBOSS
  //
  function makeDailyStage(config) {
    const level = config.level === 'advanced' ? 'advanced' : 'intermediate';
    const rewardCount = level === 'advanced' ? 2 : 1;
    return Object.freeze({
      id: config.id,
      chapter: 0,
      stageNo: 0,
      name: config.name,
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze(Array.from(config.enemyIds || [])),
      normalBattle: Object.freeze({
        totalEnemies: Math.max(1, Number(config.totalEnemies || (level === 'advanced' ? 8 : 5))),
        maxActive: Math.max(1, Number(config.maxActive || (level === 'advanced' ? 3 : 2))),
        spawnIntervalMs: Math.max(500, Number(config.spawnIntervalMs || (level === 'advanced' ? 1050 : 1250))),
      }),
      mission: Object.freeze(config.mission || { type: SHOOTING_MISSION_TYPE.DEFEAT_ALL, text: '敵をすべて撃破' }),
      dailyQuest: Object.freeze({
        weekday: config.weekday || '',
        level,
        questType: config.questType || 'weekday',
        runLevel: config.runLevel || level,
        rewardId: config.rewardId || '',
        rewardPool: Object.freeze(Array.from(config.rewardPool || [])),
        rewardCount: Math.max(1, Number(config.rewardCount || rewardCount)),
      }),
      playable: true,
    });
  }


  // build1417 — 残響の塔：10層は既存シューティングの敵AIを再利用する。
  // 進行とキャラ封印はSupabaseでのみ確定。ここには付与型の報酬を設定しない。
  const TOWER_ENEMY_POOLS = [
    [SHOOTING_ENEMY_ID.MINI_01],
    [SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT],
    [SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT],
    [SHOOTING_ENEMY_ID.MINI_02],
    [SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT],
    [SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER, SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT],
    [SHOOTING_ENEMY_ID.ZAKO_WOOD_LASER, SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT],
    [SHOOTING_ENEMY_ID.MINI_03],
    [SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER, SHOOTING_ENEMY_ID.ZAKO_DARK_LASER],
  ];
  function makeResonanceTowerStage(floor) {
    const difficult = floor === 3 || floor === 6 || floor === 9;
    // build1473 — 11F–15F. All effects use existing Canvas / elemental barriers / CH06 walls.
    if (floor === 11) return Object.freeze({
      id:'shooting_tower_11',chapter:0,stageNo:11,eventId:'resonance_tower',eventTitle:'残響の塔',
      difficultyLabel:'11F / 超弾幕',name:'第十一層',type:'normal',background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT]),
      normalBattle:Object.freeze({totalEnemies:5,maxActive:3,spawnIntervalMs:1550,enemyHp:3400,
        enemyBulletDamage:185,enemyBulletSpeed:188,enemyFireRate:1280,tower11Spread:true,itemDropRate:0}),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'5属性の超弾幕を突破'}),playable:true
    });
    if (floor === 12) return Object.freeze({
      id:'shooting_tower_12',chapter:0,stageNo:12,eventId:'resonance_tower',eventTitle:'残響の塔',
      difficultyLabel:'12F / 属性試練',name:'第十二層',type:'normal',background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT]),
      normalBattle:Object.freeze({totalEnemies:8,maxActive:2,spawnIntervalMs:1320,enemyHp:3800,
        enemyBulletDamage:180,enemyBulletSpeed:210,enemyFireRate:1160,enemyElementSequence:Object.freeze(['dark','light']),itemDropRate:0}),
      weaknessOnlyEnemies:true,towerLethalVolley:Object.freeze({intervalMs:2900,shotsPerEnemy:2,maxEnemyCount:2}),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'光・闇のバリアと即死弾を突破'}),playable:true
    });
    if (floor === 13) return Object.freeze({
      id:'shooting_tower_13',chapter:0,stageNo:13,eventId:'resonance_tower',eventTitle:'残響の塔',
      difficultyLabel:'13F / 群生',name:'第十三層',type:'normal',background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.SWARM_SPIDER_LARGE,SHOOTING_ENEMY_ID.STRONG_CH07_02]),
      normalBattle:Object.freeze({totalEnemies:3,maxActive:3,spawnIntervalMs:1300,itemDropRate:0}),
      // 13F: 大蜘蛛2体＋上部で5WAYを撃つ三頭狼1体が撃破ノルマ。
      // 蜘蛛の移動・産卵は従来どおり。三頭狼のみ専用AIで群れから分離する。
      swarmBattle:Object.freeze({largeCount:2,largeEnemyId:SHOOTING_ENEMY_ID.SWARM_SPIDER_LARGE,
        smallEnemyId:SHOOTING_ENEMY_ID.SWARM_SPIDER_SMALL,broodIntervalMs:5200,broodMaxPerLarge:2,
        guardEnemyId:SHOOTING_ENEMY_ID.STRONG_CH07_02,guardHp:7200,
        guardAi:'tower13_upper_spread5',guardShotIntervalMs:2000,guardSpreadAngleRad:.23,
        guardBulletSpeed:235,guardBulletDamage:120,guardMoveAngularSpeed:.92,
        guardMoveAmplitudeRate:.24,guardTopYRate:.20}),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'群がる蜘蛛と強敵を撃破'}),playable:true
    });
    if (floor === 14) return Object.freeze({
      id:'shooting_tower_14',chapter:0,stageNo:14,eventId:'resonance_tower',eventTitle:'残響の塔',
      difficultyLabel:'14F / 守護者',name:'第十四層',type:'boss',background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.REMNANT_03]),towerLiviaBoss:true,
      bossGaugeHps:Object.freeze([6750,6750,6750]),bossVisualScale:1.03,
      chapter6Barriers:Object.freeze([Object.freeze({xRate:.5,yRate:.47,widthRate:.62,height:23,
        moveRangeRate:.08,moveSpeed:.28,contactDamage:100})]),
      towerTimedWall:Object.freeze({firstAtMs:20000,intervalMs:20000,durationMs:10000}),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.BOSS_CLEAR,text:'強化リヴィアを撃破'}),playable:true
    });
    if (floor === 15) return Object.freeze({
      id:'shooting_tower_15',chapter:0,stageNo:15,eventId:'resonance_tower',eventTitle:'残響の塔',
      difficultyLabel:'15F / 最深部',name:'第十五層',type:'boss',background:'images/battle_bg_01.webp',
      // build1485: 15Fは専用BOSS（1体のみ）。PHASE2構成。
      //   WARNING（即死弾）が常に3つ浮遊し壁で反射し続ける。
      //   定期的に「暗転」：弾幕と自キャラ以外が見えなくなる。
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.TOWER15_BOSS]),
      // build1520: トワのバトル表示だけ自キャラ画像と同程度の横幅へ縮小。
      // 128px基準 × 1.1(uiScale) × 0.62 = 約87px（元は約141px）。
      bossElement:'dark',enemyElement:'dark',bossVisualScale:0.62,
      introImage:'images/tower15_boss_battle_start.webp',
      tower15Echo:Object.freeze({
        warningCount:3, warningSpeed:118, warningRespawnMs:2200,
        blackout:Object.freeze({
          firstAtMs:9000,
          1:Object.freeze({everyMs:16000, durationMs:4000}),
          2:Object.freeze({everyMs:11000, durationMs:5200})
        })
      }),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.BOSS_CLEAR,text:'トワを撃破'}),playable:true
    });
    if (floor === 10) return Object.freeze({
      id:'shooting_tower_10', chapter:0, stageNo:10,
      eventId:'resonance_tower', eventTitle:'残響の塔', difficultyLabel:'10F / 最深部',
      name:'第十層', type:'boss', background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.REMNANT_05]),
      bossVisualScale:1.0,
      tower10ReverseControls:Object.freeze({phases:Object.freeze([2,3]),triggerHpRatio:0.5,durationMs:5000}),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.BOSS_CLEAR,text:'最深部の守護者を撃破'}),
      playable:true
    });
    const totalEnemies=[5,6,7,7,8,8,9,9,10][floor-1];
    const battle={
      totalEnemies,
      // Tower08: keep its high-difficulty 2-enemy encounter, rendered via Canvas.
      maxActive:difficult?3:2,
      spawnIntervalMs:difficult?1100:1350,
      enemyHp:Math.round(520+floor*255+(difficult?350:0)),
      enemyBulletDamage:Math.round(65+floor*11),
      enemyBulletSpeed:145+floor*8,
      // Tower08: restore strong 7/9/12-shot volleys, keep Canvas bullet rendering.
      enemyFireRate:Math.max(920,1920-floor*80),
      barrageLevel:Math.min(5,1+Math.floor(floor/2)),itemDropRate:0
    };
    // Tower04: fixed visible obstruction; Tower06: original mobile obstruction.
    // Existing Chapter06 barrier collision logic handles projectile blocking.
    const barriers=floor===4?Object.freeze([Object.freeze({
      xRate:.5,yRate:.43,widthRate:.67,height:23,moveRangeRate:0,moveSpeed:0,contactDamage:80
    })]):floor===6?Object.freeze([Object.freeze({
      xRate:.5,yRate:.44,widthRate:.58,height:22,moveRangeRate:.12,moveSpeed:.25,contactDamage:80
    })]):null;
    return Object.freeze({
      id:'shooting_tower_'+String(floor).padStart(2,'0'),chapter:0,stageNo:floor,
      eventId:'resonance_tower',eventTitle:'残響の塔',
      difficultyLabel:String(floor).padStart(2,'0')+'F'+(difficult?' / 難関':''),
      name:'第'+floor+'層',type:'normal',background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze(TOWER_ENEMY_POOLS[floor-1]),
      normalBattle:Object.freeze(floor===9?{...battle,enemyElementSequence:Object.freeze(['fire','aqua'])}:battle),
      ...(floor===9?{weaknessOnlyEnemies:true}:{}),
      ...(barriers?{chapter6Barriers:barriers}:{}),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'敵をすべて撃破'}),
      playable:true
    });
  }

  const SHOOTING_STAGES = Object.freeze({
    ...Object.fromEntries(Array.from({length:15},(_,i)=>{const n=i+1;return ['shooting_tower_'+String(n).padStart(2,'0'),makeResonanceTowerStage(n)];})),
    // 本編の敵・ショット・ULT・操作系を共用するが、通常ステージには登録しない試遊専用ステージ。
    [SHOOTING_STAGE_ID.GACHA_TRIAL]: Object.freeze({
      id: SHOOTING_STAGE_ID.GACHA_TRIAL,
      chapter: 0, stageNo: 0, name: 'TRIAL BATTLE', type: 'normal',
      eventId: 'gacha_trial', background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.MINI_03]),
      normalBattle: Object.freeze({
        infiniteEnemies: true, maxActive: 4, spawnIntervalMs: 750,
        itemDropRate: 0, enemyHp: 900, enemyBulletDamage: 55,
        enemyBulletSpeed: 170, enemyFireRate: 1600, barrageLevel: 1,
      }),
      // 制限時間ゼロのSURVIVE_TIMEではミッション達成が発生しない。
      mission: Object.freeze({ type: SHOOTING_MISSION_TYPE.SURVIVE_TIME, targetSeconds: 0, text: '何度でも試せます' }),
      playable: false,
    }),
    [SHOOTING_STAGE_ID.CH01_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH01_01,
      chapter: 1,
      stageNo: 1,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch01_01']?.stageTitle || '朝'; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_01,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 7,
        maxActive: 2,
        spawnIntervalMs: 950,

        // build1162: CH01-01〜03はLv1前提のまま、敵HPをbuild1157比3倍・ATK(被弾ダメージ)を100へ統一。
        enemyHp: 255,
        enemyBulletDamage: 100,
        enemyBulletSpeed: 135,
        enemyFireRate: 1900,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 3,
        text: 'アイテムを3個拾ってクリア',
      }),

      // Normal Stage battle logic is the next implementation step.
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH01_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH01_02,
      chapter: 1,
      stageNo: 2,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch01_02']?.stageTitle || '呼吸'; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_01,
      ]),
      normalBattle: Object.freeze({
        // build1157: エリ→ジグのキャラチェンジ＋レーザー貫通チュートリアル。
        // 3体はcore側で縦一列に固定配置するため、通常スポーンは使用しない。
        totalEnemies: 3,
        maxActive: 3,
        spawnIntervalMs: 999999,
        enemyImage: 'images/remnant_01_zako.webp',
        // build1163: CH01-02も他の序盤ステージに合わせ、HPを225へ統一寄せ。
        enemyHp: 225,
        enemyBulletDamage: 100,
        enemyBulletSpeed: 120,
        enemyFireRate: 2200,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '敵を3体すべて撃破',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH01_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH01_03,
      chapter: 1,
      stageNo: 3,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch01_03']?.stageTitle || '邂逅'; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_01,
      ]),
      normalBattle: Object.freeze({
        // build1141: レムナント雑魚を無限湧き。3個回収するまで戦闘継続。
        infiniteEnemies: true,
        maxActive: 3,
        spawnIntervalMs: 720,
        enemyImage: 'images/remnant_01_zako.webp',
        itemDropRate: 1,

        // build1162: CH01-03もHP3倍・ATK(被弾ダメージ)100へ調整。
        enemyHp: 225,
        enemyBulletDamage: 100,
        enemyBulletSpeed: 130,
        enemyFireRate: 1900,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 3,
        itemImage: 'images/item_memory_mini.webp',
        text: 'レムナントの残骸を3つ入手する',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH01_04]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH01_04,
      chapter: 1,
      stageNo: 4,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch01_04']?.stageTitle || '旅立ち'; },
      type: 'boss',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.REMNANT_01,
      ]),

      // build1415: このステージだけ戦闘用BOSS画像を差し替え。AI / HP / 弾幕は従来通り。
      bossBattleImage: 'images/enemy_mini_03_battle.webp',
      introImage: 'images/remnant_01_battle_start.webp',
      // build1416: build1415比で約16%小さく表示（BOSS行動・HPは変更しない）。
      bossVisualScale: 1.30,

      // build1168: 負けイベント～アルノ戦まで最初から2ゲージ設計。
      bossGauges: 2,

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: '竜型レムナントを撃破',
      }),

      playable: true,
    }),

    // ============================================================
    // CHAPTER 02 - 暴力
    // 数ではなく、一体一体の圧力でプレイヤーを追い詰める章。
    // ============================================================
    [SHOOTING_STAGE_ID.CH02_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH02_01,
      chapter: 2,
      stageNo: 1,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch02_01']?.stageTitle || '圧'; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH02は属性解説前のため、敵属性は全ステージLIGHTで統一。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 3,
        maxActive: 1,
        spawnIntervalMs: 1300,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '強敵をすべて撃破',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH02_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH02_02,
      chapter: 2,
      stageNo: 2,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch02_02']?.stageTitle || '蹂躙'; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ]),

      // build1242:
      // 属性相性を実戦で覚えるステージ。
      // 1体ずつ DARK -> WOOD -> AQUA の順で出現し、
      // エリ(LIGHT) -> アルノ(FIRE) -> アウラ(WOOD)へ切り替えて突破する。
      weaknessOnlyEnemies: true,
      normalBattle: Object.freeze({
        totalEnemies: 3,
        maxActive: 1,
        spawnIntervalMs: 900,
        itemDropRate: 0,

        enemyVariants: Object.freeze(['normal', 'normal', 'normal']),
        enemyElementSequence: Object.freeze(['dark', 'wood', 'aqua']),

        // Lv1想定のエリ/アウラは短め、Lv40想定のアルノ担当だけ高耐久。
        // 1: DARK -> エリ(LIGHT)
        // 2: WOOD -> アルノ(FIRE)
        // 3: AQUA -> アウラ(WOOD)
        enemyHpSequence: Object.freeze([900, 2700, 900]),
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '敵をすべて撃破',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH02_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH02_03,
      chapter: 2,
      stageNo: 3,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch02_03']?.stageTitle || '威圧'; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH02はLIGHT属性で統一。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 3,
        maxActive: 2,
        spawnIntervalMs: 1450,
        // build1189: CH02雑魚は2種のみ。normal=遠隔弾 / atack=突進。
        enemyVariants: Object.freeze(['normal', 'atack', 'normal']),
        // CH02-3だけ突進を少し見切りやすくする。
        chargeSpeed: 470,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '敵をすべて撃破',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH02_04]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH02_04,
      chapter: 2,
      stageNo: 4,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch02_04']?.stageTitle || '暴力'; },
      type: 'boss',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.REMNANT_02,
      ]),

      // build1415: BOSS画像だけ置換し、ボス戦闘ロジックは変更しない。
      bossBattleImage: 'images/enemy_remmaster.webp',
      introImage: 'images/remnant_02_battle_start.webp',
      // build1416: build1415比で16%小さく表示（BOSS行動・HPは変更しない）。
      bossVisualScale: 1.05,

      // build1190: CH02-04 boss battle uses two HP gauges.
      bossGauges: 2,

      // CH02-04の援軍もLIGHT属性で統一。
      bossAdds: Object.freeze({
        enemyIds: Object.freeze([
          SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
        ]),
        // build1415: LIGHT属性の遠隔1体と突進1体を各1回のみ出現させる。
        // 合計2体上限なので、撃破後に蘇生・補充されない。
        enemyVariants: Object.freeze(['normal', 'atack']),
        totalEnemies: 2,
        maxActive: 2,
        startDelayMs: 3500,
        spawnIntervalMs: 2500,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: '白い影を撃破',
      }),

      // ボス画像 images/remnant_02_battle.webp を配置すればそのまま遊べる。
      playable: true,
    }),

    // ============================================================
    // CHAPTER 03 - 弾幕
    // アイテムを拾いながら、濃い弾幕を抜けて進む章。
    // 01-03は収集、04は本格的な弾幕ボス戦。
    // ============================================================
    [SHOOTING_STAGE_ID.CH03_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH03_01,
      chapter: 3,
      stageNo: 1,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch03_01']?.stageTitle || '羽音'; },
      type: 'normal',
      element: 'aqua',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_03,
      ]),
      normalBattle: Object.freeze({
        infiniteEnemies: true,
        maxActive: 2,
        spawnIntervalMs: 980,
        itemDropRate: 0.80,

        // CH03-01: 弱
        enemyHp: 900,
        enemyBulletDamage: 75,
        enemyBulletSpeed: 190,
        enemyFireRate: 1450,
        barrageLevel: 1,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 3,
        text: 'アイテムを3個拾ってクリア',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH03_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH03_02,
      chapter: 3,
      stageNo: 2,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch03_02']?.stageTitle || '星雨'; },
      type: 'normal',
      element: 'aqua',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_03,
      ]),
      normalBattle: Object.freeze({
        // build1216: アイテム収集を廃止。3体を全滅させたらクリア。
        totalEnemies: 3,
        maxActive: 2,
        spawnIntervalMs: 850,
        itemDropRate: 0,

        // CH03-02: 中
        enemyHp: 1200,
        enemyBulletDamage: 95,
        enemyBulletSpeed: 215,
        enemyFireRate: 1230,
        barrageLevel: 2,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '敵をすべて撃破',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH03_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH03_03,
      chapter: 3,
      stageNo: 3,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch03_03']?.stageTitle || '交差'; },
      type: 'normal',
      element: 'aqua',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_03,
      ]),
      normalBattle: Object.freeze({
        // build1216: アイテム収集を廃止。5体を全滅させたらクリア。
        totalEnemies: 5,
        maxActive: 3,
        spawnIntervalMs: 760,
        itemDropRate: 0,

        // build1241: 5体を5属性で1体ずつ出現させる。
        // 出現順: 木 → 火 → 水 → 闇 → 光
        enemyElementSequence: Object.freeze(['wood', 'fire', 'aqua', 'dark', 'light']),

        // CH03-03: 強
        enemyHp: 1500,
        enemyBulletDamage: 115,
        enemyBulletSpeed: 235,
        enemyFireRate: 1080,
        barrageLevel: 3,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '敵をすべて撃破',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH03_04]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH03_04,
      chapter: 3,
      stageNo: 4,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch03_04']?.stageTitle || '雨冠'; },
      type: 'boss',
      element: 'aqua',
      background: 'images/battle_bg_01.webp',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.REMNANT_03,
      ]),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'リヴィアを撃破',
      }),

      playable: true,
    }),


    // ============================================================
    // CHAPTER 04 - 美しい弾幕
    // 密度で押すCH03とは分離し、規則性・軌跡・余白の美しさを主役にする。
    // 01: 螺旋 / 02: 波 / 03: 螺旋と波の複合 / 04: BOSS予約枠
    // ============================================================
    // ============================================================
    // CHAPTER 04 - 呼び声
    // 最新シナリオ準拠:
    // 01 余波: 通常戦
    // 02 異質: 木 / 水 属性バリア
    // 03 炎壁: 火属性バリア。リュネ登場イベントまで水属性以外IMMUNE
    // 04 リュネ: 大量レムナントとの通常戦。クリア後リュネ正式加入
    // ============================================================
    [SHOOTING_STAGE_ID.CH04_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH04_01,
      chapter: 4,
      stageNo: 1,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch04_01']?.stageTitle || '予感'; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.MINI_03]),
      normalBattle: Object.freeze({
        totalEnemies: 5,
        maxActive: 2,
        spawnIntervalMs: 760,
        itemDropRate: 0,
        enemyImage: 'images/zako_enemy_01_normal_light.webp',
        enemyElementSequence: Object.freeze(['light', 'light', 'dark', 'light', 'wood']),
        enemyHp: 1550,
        enemyBulletDamage: 110,
        enemyBulletSpeed: 230,
        enemyFireRate: 1120,
        barrageLevel: 2,
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '強化個体をすべて撃破',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH04_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH04_02,
      chapter: 4,
      stageNo: 2,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch04_02']?.stageTitle || ''; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.MINI_03]),
      weaknessOnlyEnemies: true,
      normalBattle: Object.freeze({
        totalEnemies: 2,
        maxActive: 2,
        spawnAllAtStart: true,
        spawnIntervalMs: 500,
        itemDropRate: 0,
        enemyImage: 'images/zako_enemy_01_normal_light.webp',
        enemyElementSequence: Object.freeze(['wood', 'aqua']),
        enemyHpSequence: Object.freeze([1850, 1850]),
        enemyBulletDamage: 115,
        enemyBulletSpeed: 235,
        enemyFireRate: 1080,
        barrageLevel: 2,
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '強化個体をすべて撃破',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH04_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH04_03,
      chapter: 4,
      stageNo: 3,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch04_03']?.stageTitle || '火を纏う壁'; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.MINI_03]),
      weaknessOnlyEnemies: true,
      ch04StrictFireBarrier: true,
      normalBattle: Object.freeze({
        totalEnemies: 2,
        maxActive: 2,
        spawnAllAtStart: true,
        spawnIntervalMs: 500,
        itemDropRate: 0,
        enemyImage: 'images/zako_enemy_01_normal_light.webp',
        enemyElementSequence: Object.freeze(['fire', 'fire']),
        enemyHpSequence: Object.freeze([2000, 2000]),
        enemyBulletDamage: 120,
        enemyBulletSpeed: 240,
        enemyFireRate: 1050,
        barrageLevel: 3,
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '強化個体をすべて撃破',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH04_04]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH04_04,
      chapter: 4,
      stageNo: 4,
      get name() { return window.ZERAPHIA_STORY_SCENARIO?.['shooting_ch04_04']?.stageTitle || '忘却の川'; },
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.MINI_03]),
      normalBattle: Object.freeze({
        totalEnemies: 3,
        maxActive: 5,
        spawnIntervalMs: 5000,
        itemDropRate: 0,
        enemyImage: 'images/zako_enemy_01_normal_light.webp',
        enemyElementSequence: Object.freeze(['aqua', 'fire', 'light']),
        enemyHp: 1800,
        enemyBulletDamage: 120,
        enemyBulletSpeed: 240,
        enemyFireRate: 1030,
        barrageLevel: 3,
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '強化個体をすべて撃破',
      }),
      playable: true,
    }),

    // ============================================================
    // CHAPTER 05 — 円環
    [SHOOTING_STAGE_ID.CH05_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH05_01, chapter:5, stageNo:1,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch05_01?.stageTitle || '沈黙する円盤';},
      type:'normal', background:'images/battle_bg_01.webp', enemyIds:Object.freeze([]),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'物語を読む'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH05_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH05_02, chapter:5, stageNo:2,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch05_02?.stageTitle || 'ずれた輪';},
      type:'normal', background:'images/battle_bg_01.webp', enemyIds:Object.freeze([]),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'三つの輪の紋様をつなぐ'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH05_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH05_03, chapter:5, stageNo:3,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch05_03?.stageTitle || 'もう一つの円環';},
      type:'normal', background:'images/battle_bg_01.webp', enemyIds:Object.freeze([]),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'四つの輪の紋様をつなぐ'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH05_04]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH05_04, chapter:5, stageNo:4,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch05_04?.stageTitle || '二人きりの巡回';},
      type:'normal', background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.MINI_05]),
      normalBattle:Object.freeze({totalEnemies:3,maxActive:3,spawnIntervalMs:0,spawnAllAtStart:true,
        itemDropRate:0,enemyElementSequence:Object.freeze(['dark','dark','dark']),
        enemyHp:1600,enemyBulletDamage:115,enemyBulletSpeed:250,enemyFireRate:780,barrageLevel:4}),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'闇属性レムナント3体を撃破'}),
      // build1468: Sランククリアのたびに追加でもらえる報酬（通常モードのみ）
      sRankBonusRewards:Object.freeze([
        Object.freeze({ id:'level_exp_large', name:'強化素材・金', image:'images/item_exp_gold.webp', count:1, rewardType:'level_exp' })
      ]),
      playable:true
    }),

    // ============================================================
    // CHAPTER 06 — 来訪者（物語 → 隠密ゲーム → 属性バリア戦 → 紙のパズル）
    // ============================================================
    [SHOOTING_STAGE_ID.CH06_01]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH06_01, chapter:6, stageNo:1,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch06_01?.stageTitle || '気配';},
      type:'normal', background:'images/battle_bg_01.webp', enemyIds:Object.freeze([]),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'物語を読む'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH06_02]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH06_02, chapter:6, stageNo:2,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch06_02?.stageTitle || '吉か凶か';},
      type:'normal', background:'images/battle_bg_01.webp', enemyIds:Object.freeze([]),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'隠密ミニゲームを2戦クリア'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH06_03]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH06_03, chapter:6, stageNo:3,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch06_03?.stageTitle || '火を払う水';},
      type:'normal', background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.MINI_03]),
      weaknessOnlyEnemies:true,
      normalBattle:Object.freeze({
        totalEnemies:3, maxActive:3, spawnAllAtStart:true, spawnIntervalMs:500,
        itemDropRate:0, enemyImage:'images/zako_enemy_01_normal_light.webp',
        enemyElementSequence:Object.freeze(['fire','fire','wood']),
        enemyHpSequence:Object.freeze([2200,2200,2200]),
        enemyBulletDamage:125, enemyBulletSpeed:250, enemyFireRate:1000, barrageLevel:4
      }),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'火2体・木1体の強化個体を撃破'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH06_04]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH06_04, chapter:6, stageNo:4,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch06_04?.stageTitle || '道しるべ';},
      type:'normal', background:'images/battle_bg_01.webp', enemyIds:Object.freeze([]),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'2枚の紙の紋様をつなぐ'}),playable:true
    }),

    // ============================================================
    // CHAPTER 07 — 灰路（仮）：9人で東の「輪をまとった光」の塔へ向かう道中
    // 7-1 出発（物語） / 7-2 空の聖堂 / 7-3 灰の丘 / 7-4 夜明け（灰から湧き上がる小蜘蛛の大群を突破）
    // ============================================================
    [SHOOTING_STAGE_ID.CH07_01]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH07_01, chapter:7, stageNo:1,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch07_01?.stageTitle || '出発';},
      type:'normal', background:'images/battle_bg_01.webp', enemyIds:Object.freeze([]),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'物語を読む'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH07_02]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH07_02, chapter:7, stageNo:2,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch07_02?.stageTitle || '空の聖堂';},
      type:'normal', background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.STRONG_CH07_02]),
      // 弱点バリアなし（weaknessOnlyEnemies を付けない）。遮断壁が左右にゆっくり動き、射線を切る。
      chapter6Barriers:Object.freeze([
        Object.freeze({ xRate:.50, yRate:.47, widthRate:.56, height:23, moveRangeRate:.18, moveSpeed:.34, contactDamage:85 }),
      ]),
      normalBattle:Object.freeze({
        totalEnemies:1, maxActive:1, spawnAllAtStart:true, spawnIntervalMs:500, itemDropRate:0,
        enemyBulletDamage:120, enemyBulletSpeed:235, enemyFireRate:1100, barrageLevel:4
      }),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'出口をふさぐ強化個体を撃破'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH07_03]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH07_03, chapter:7, stageNo:3,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch07_03?.stageTitle || '灰の丘';},
      type:'normal', background:'images/battle_bg_ch07_03.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.SWARM_SPIDER_LARGE]),
      swarmBattle:Object.freeze({
        largeEnemyId:SHOOTING_ENEMY_ID.SWARM_SPIDER_LARGE,
        smallEnemyId:SHOOTING_ENEMY_ID.SWARM_SPIDER_SMALL,
        largeCount:3,              // 勝利条件：この数の大を撃破
        broodIntervalMs:5000,      // 大1体あたり、5秒に1体ずつ小を生む
        broodMaxPerLarge:3,        // 大1体あたり、小は同時3体まで
        largeTrapHitsToKill:3,     // TRAP爆発3回で大を撃破
        largeMaxYRate:.58,         // 大は画面の58%より下へは降りない（逃げ場を残す）
        objectContactDps:60,       // デコイへ群がったときの毎秒ダメージ（1体あたり）
      }),
      normalBattle:Object.freeze({
        totalEnemies:3, maxActive:99, itemDropRate:0,
      }),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'群れを生む強化個体3体を撃破'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH07_04]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH07_04, chapter:7, stageNo:4,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch07_04?.stageTitle || '夜明け';},
      type:'normal', background:'images/battle_bg_ch07_03.webp',
      // 小蜘蛛だけが灰の中から次々と現れる。射撃弾は使用しない。
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.SWARM_SPIDER_SMALL]),
      spiderHorde:Object.freeze({
        smallEnemyId:SHOOTING_ENEMY_ID.SWARM_SPIDER_SMALL,
        totalEnemies:42, maxActive:14, batchSize:3, spawnIntervalMs:1000,
        moveSpeedMultiplier:1.75, surroundRadius:61,
        groupMinCount:3, groupHitIntervalMs:420,
        groupDamageHpRate:0.16, // 群がられ続けると概ね3秒で1キャラKO
      }),
      normalBattle:Object.freeze({
        totalEnemies:42, maxActive:14, spawnIntervalMs:1000, itemDropRate:0
      }),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'押し寄せる小蜘蛛42体を退け、灰の丘を越える'}),playable:true
    }),

    // ============================================================
    // CHAPTER 08 — 七つの塔
    // 全4ステージ：探索戦 → 壁＋属性戦 → 迎撃戦 → 守護者BOSS
    // ノア幹部の正体は明かさない。第7章「……呼んでる。」の直後から。
    // ============================================================
    [SHOOTING_STAGE_ID.CH08_01]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH08_01, chapter:8, stageNo:1,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch08_01?.stageTitle || '塔の麓';},
      type:'normal', background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.MINI_05, SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT]),
      normalBattle:Object.freeze({
        totalEnemies:5,maxActive:3,spawnIntervalMs:1700,itemDropRate:0,
        enemyElementSequence:Object.freeze(['light','dark','light','dark','light']),
        enemyHp:2200,enemyBulletDamage:125,enemyBulletSpeed:248,enemyFireRate:980,barrageLevel:4
      }),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'塔の入口を守るレムナント5体を撃破'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH08_02]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH08_02, chapter:8, stageNo:2,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch08_02?.stageTitle || '七方向の印';},
      type:'normal', background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT]),
      chapter6Barriers:Object.freeze([
        Object.freeze({xRate:.50,yRate:.47,widthRate:.52,height:20,moveRangeRate:.14,moveSpeed:.31,contactDamage:90})
      ]),
      normalBattle:Object.freeze({
        totalEnemies:6,maxActive:3,spawnIntervalMs:1750,itemDropRate:0,
        enemyElementSequence:Object.freeze(['dark','light','dark','light','dark','light']),
        enemyHp:2350,enemyBulletDamage:130,enemyBulletSpeed:253,enemyFireRate:1030,barrageLevel:4
      }),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'遮断壁を越えて守護個体6体を撃破'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH08_03]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH08_03, chapter:8, stageNo:3,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch08_03?.stageTitle || '観測';},
      type:'normal', background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.MINI_05,SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT]),
      normalBattle:Object.freeze({
        totalEnemies:7,maxActive:3,spawnIntervalMs:1300,itemDropRate:0,
        enemyElementSequence:Object.freeze(['aqua','wood','dark','light','aqua','wood','dark']),
        enemyHp:2600,enemyBulletDamage:135,enemyBulletSpeed:262,enemyFireRate:900,barrageLevel:4
      }),
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.DEFEAT_ALL,text:'塔の内壁に現れた観測個体7体を撃破'}),playable:true
    }),
    [SHOOTING_STAGE_ID.CH08_04]: Object.freeze({
      id:SHOOTING_STAGE_ID.CH08_04, chapter:8, stageNo:4,
      get name(){return window.ZERAPHIA_STORY_SCENARIO?.shooting_ch08_04?.stageTitle || '応答';},
      type:'boss', background:'images/battle_bg_01.webp',
      enemyIds:Object.freeze([SHOOTING_ENEMY_ID.CH08_GUARDIAN]),
      bossGauges:2,
      bossGaugeHps:Object.freeze([9500,12500]),
      // 専用イラストが未提供のため、既存のレムナント画像を一時的に共用。
      bossBattleImage:'images/remnant_03_battle.webp',
      bossVisualScale:1.03,
      mission:Object.freeze({type:SHOOTING_MISSION_TYPE.BOSS_CLEAR,text:'塔の守護者を撃破し、円盤への道を開く'}),playable:true
    }),

    // ============================================================
        // SPECIAL EVENT - 無貌の天使
    // 「照射◯秒」は現行プレイ感の基準DPSを約190としてHP化。
    // wave1: 約40秒 → 7,600 / wave2: 約100秒 → 19,000
    // object: 約5秒 → 950
    // ============================================================
    // ============================================================
    // DAILY QUEST
    // 中級1個 / 上級2個。日曜のみ敵・報酬とも全属性ミックス。
    // ============================================================
    [SHOOTING_STAGE_ID.DAILY_MON_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_MON_INTERMEDIATE, weekday: 'Mon', level: 'intermediate', name: '月曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT], rewardId: 'soul_vessel_dark',
    }),
    [SHOOTING_STAGE_ID.DAILY_MON_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_MON_ADVANCED, weekday: 'Mon', level: 'advanced', name: '月曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_DARK_LASER], rewardId: 'soul_vessel_dark',
    }),
    [SHOOTING_STAGE_ID.DAILY_TUE_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_TUE_INTERMEDIATE, weekday: 'Tue', level: 'intermediate', name: '火曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE], rewardId: 'soul_vessel_fire',
    }),
    [SHOOTING_STAGE_ID.DAILY_TUE_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_TUE_ADVANCED, weekday: 'Tue', level: 'advanced', name: '火曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER, SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE],
      rewardId: 'soul_vessel_fire',
    }),
    [SHOOTING_STAGE_ID.DAILY_WED_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_WED_INTERMEDIATE, weekday: 'Wed', level: 'intermediate', name: '水曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT], rewardId: 'soul_vessel_aqua',
    }),
    [SHOOTING_STAGE_ID.DAILY_WED_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_WED_ADVANCED, weekday: 'Wed', level: 'advanced', name: '水曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER], rewardId: 'soul_vessel_aqua',
    }),
    [SHOOTING_STAGE_ID.DAILY_THU_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_THU_INTERMEDIATE, weekday: 'Thu', level: 'intermediate', name: '木曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT], rewardId: 'soul_vessel_wood',
    }),
    [SHOOTING_STAGE_ID.DAILY_THU_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_THU_ADVANCED, weekday: 'Thu', level: 'advanced', name: '木曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_LASER], rewardId: 'soul_vessel_wood',
    }),
    [SHOOTING_STAGE_ID.DAILY_FRI_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_FRI_INTERMEDIATE, weekday: 'Fri', level: 'intermediate', name: '金曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT], rewardId: 'soul_vessel_light',
    }),
    [SHOOTING_STAGE_ID.DAILY_FRI_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_FRI_ADVANCED, weekday: 'Fri', level: 'advanced', name: '金曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER], rewardId: 'soul_vessel_light',
    }),
    [SHOOTING_STAGE_ID.DAILY_SAT_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_SAT_INTERMEDIATE, weekday: 'Sat', level: 'intermediate', name: '土曜巡行・中級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ],
      rewardId: 'kyoumei_stone', totalEnemies: 5,
    }),
    [SHOOTING_STAGE_ID.DAILY_SAT_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_SAT_ADVANCED, weekday: 'Sat', level: 'advanced', name: '土曜巡行・上級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER, SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER, SHOOTING_ENEMY_ID.ZAKO_WOOD_LASER,
        SHOOTING_ENEMY_ID.ZAKO_DARK_LASER, SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER,
      ],
      rewardId: 'kyoumei_stone',
    }),
    [SHOOTING_STAGE_ID.DAILY_SUN_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_SUN_INTERMEDIATE, weekday: 'Sun', level: 'intermediate', name: '日曜巡行・中級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ],
      rewardPool: ['kyoumei_stone','soul_vessel_fire','soul_vessel_aqua','soul_vessel_wood','soul_vessel_dark','soul_vessel_light'],
      totalEnemies: 6,
    }),
    [SHOOTING_STAGE_ID.DAILY_SUN_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_SUN_ADVANCED, weekday: 'Sun', level: 'advanced', name: '日曜巡行・上級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER, SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER,
        SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_LASER,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_DARK_LASER,
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER,
      ],
      rewardPool: ['kyoumei_stone','soul_vessel_fire','soul_vessel_aqua','soul_vessel_wood','soul_vessel_dark','soul_vessel_light'],
      totalEnemies: 10, maxActive: 3, spawnIntervalMs: 950,
    }),


    // 経験値素材DAILY。敵撃破で素材アイコンが落ち、合計10個取得でクリア。
    [SHOOTING_STAGE_ID.DAILY_EXP_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_EXP_INTERMEDIATE,
      level: 'intermediate',
      questType: 'exp',
      runLevel: 'exp_intermediate',
      name: '経験値素材・中級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ],
      totalEnemies: 10,
      maxActive: 2,
      spawnIntervalMs: 1050,
      rewardCount: 10,
      mission: {
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 10,
        itemImage: 'images/item_exp_bronze.webp',
        text: '経験値素材を合計10個獲得',
      },
    }),
    [SHOOTING_STAGE_ID.DAILY_EXP_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_EXP_ADVANCED,
      level: 'advanced',
      questType: 'exp',
      runLevel: 'exp_advanced',
      name: '経験値素材・上級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER,
        SHOOTING_ENEMY_ID.ZAKO_WOOD_LASER,
        SHOOTING_ENEMY_ID.ZAKO_DARK_LASER,
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER,
        SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE,
      ],
      totalEnemies: 10,
      maxActive: 3,
      spawnIntervalMs: 900,
      rewardCount: 10,
      mission: {
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 10,
        itemImage: 'images/item_exp_gold.webp',
        text: '経験値素材を合計10個獲得',
      },
    }),

    [SHOOTING_STAGE_ID.FACELESS_ADVANCED]: Object.freeze({
      id: SHOOTING_STAGE_ID.FACELESS_ADVANCED,
      chapter: 0,
      stageNo: 1,
      eventId: 'faceless',
      eventTitle: '無貌の天使',
      difficultyLabel: '上級',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/enemy_faceless_battle_start.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.FACELESS]),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'フェイスレスを撃破',
      }),
      faceless: Object.freeze({
        difficulty: 'advanced',
        waveHp: Object.freeze([7600, 19000]),
        waveBarrage: Object.freeze(['light', 'medium']),
        objectHp: 950,
        objectWays: 2,
        waveObjectCount: Object.freeze([1, 2]),
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.FACELESS_SUPER]: Object.freeze({
      id: SHOOTING_STAGE_ID.FACELESS_SUPER,
      chapter: 0,
      stageNo: 2,
      eventId: 'faceless',
      eventTitle: '無貌の天使',
      difficultyLabel: '最上級',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/enemy_faceless_battle_start.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.FACELESS]),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'フェイスレスを撃破',
      }),
      faceless: Object.freeze({
        difficulty: 'super',
        waveHp: Object.freeze([7600, 19000]),
        waveBarrage: Object.freeze(['medium', 'dense']),
        objectHp: 950,
        objectWays: 3,
        waveObjectCount: Object.freeze([1, 2]),
      }),
      playable: true,
    }),


    // ============================================================
    // SPECIAL STAGE - 理想郷 -ノア-
    // パフォーマンス検証用のストレステストステージ。
    // 見た目は極限まで簡素化(装飾なし)。WAVE1から高密度、WAVE3でさらに濃く。
    // 1発被弾での即死はなし(4発被弾で撃破される想定のダメージ値)。
    // ============================================================
    [SHOOTING_STAGE_ID.BULLET_HELL_TEST]: Object.freeze({
      id: SHOOTING_STAGE_ID.BULLET_HELL_TEST,
      chapter: 0,
      stageNo: 3,
      eventId: 'bullet_hell_test',
      eventTitle: '理想郷 -ノア-',
      // 戦闘開始時にSPECIAL STAGE TICKETを1枚消費。
      specialTicketCost: 1,
      difficultyLabel: 'STRESS TEST',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.NOAH]),
      bossElement: 'light',
      enemyElement: 'light',
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: '理想郷 -ノア-を耐えきれ',
      }),
      playable: true,
    }),


    // ============================================================
    // SCORE ATTACK - すこあた！
    // 60秒固定タイムライン。同じ難易度では毎回同じ弾幕。
    // NORMAL / HARD は弾道構成を共通にし、速度・被ダメージだけ変更。
    // ============================================================
    [SHOOTING_STAGE_ID.SCORE_ATTACK_NORMAL]: Object.freeze({
      id: SHOOTING_STAGE_ID.SCORE_ATTACK_NORMAL,
      chapter: 0,
      stageNo: 20,
      eventId: 'score_attack',
      eventTitle: 'すこあた！',
      difficultyLabel: 'NORMAL',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.BULLET_HELL_TEST]),
      survivalBoss: true,
      bossTotalHp: 100000,
      bossGaugeHp: 100000,
      bossGauges: 1,
      timeLimitSeconds: 60,
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.SURVIVE_TIME,
        targetSeconds: 60,
        text: '60秒間でハイスコアを目指せ',
      }),
      scoreAttack: Object.freeze({
        difficulty: 'normal',
        bulletSpeedMultiplier: 0.92,
        bulletDamage: 105,
        volleyIntervalMs: 880,
        maxEnemyBullets: 100,
        recoverEnemyBulletsTo: 76,
        maxPlayerBullets: 72,
        recoverPlayerBulletsTo: 54,
        warningDamageMultiplier: 2.0,
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.SCORE_ATTACK_HARD]: Object.freeze({
      id: SHOOTING_STAGE_ID.SCORE_ATTACK_HARD,
      chapter: 0,
      stageNo: 21,
      eventId: 'score_attack',
      eventTitle: 'すこあた！',
      difficultyLabel: 'HARD',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.BULLET_HELL_TEST]),
      survivalBoss: true,
      bossTotalHp: 100000,
      bossGaugeHp: 100000,
      bossGauges: 1,
      timeLimitSeconds: 60,
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.SURVIVE_TIME,
        targetSeconds: 60,
        text: '60秒間でハイスコアを目指せ',
      }),
      scoreAttack: Object.freeze({
        difficulty: 'hard',
        bulletSpeedMultiplier: 1.22,
        bulletDamage: 165,
        volleyIntervalMs: 880,
        maxEnemyBullets: 100,
        recoverEnemyBulletsTo: 76,
        maxPlayerBullets: 72,
        recoverPlayerBulletsTo: 54,
        warningDamageMultiplier: 2.0,
      }),
      playable: true,
    }),


    // ============================================================
    // DAILY RAID - SIGMA-IX
    // 共有HP 100,000 / 最大4人 / 1日1回。
    // 実際の残HPはSupabaseのraidContextからshooting_core側で上書きする。
    // ============================================================
    [SHOOTING_STAGE_ID.RAID_TEST]: Object.freeze({
      id: SHOOTING_STAGE_ID.RAID_TEST,
      chapter: 0,
      stageNo: 1,
      eventId: 'raid',
      eventTitle: 'SIGMA-IX',
      difficultyLabel: 'DAILY RAID',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.RAID_TEST]),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: '共有HPを削れ',
      }),
      raid: Object.freeze({
        bossId: 'the_test',
        maxHp: 100000,
        maxPlayers: 4,
        attemptsPerDay: 1,
        timeLimitSeconds: 180,
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.OVERSEER_AMBUSH]: Object.freeze({
      id: SHOOTING_STAGE_ID.OVERSEER_AMBUSH,
      chapter: 0,
      stageNo: 0,
      name: '緊急遭遇',
      type: 'boss',
      eventId: 'random_ambush',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/remnant_01_blk_battle_start.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.OVERSEER_AMBUSH]),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'オーバーシア（亜種）を撃破',
      }),
      guaranteedRewards: Object.freeze([
        Object.freeze({
          type: 'material',
          id: 'overseer_blk_core',
          name: 'オーバーシア亜種の心核',
          image: 'images/item_overseer_blk_core.webp',
          count: 1,
          detail: '特殊強化素材',
        }),
      ]),
      ambush: Object.freeze({
        enabled: false,
        triggerRate: 0.00,
        waveHp: Object.freeze([5000, 8000]),
        waveDamage: Object.freeze([350, 600]),
        warningEveryMs: 4000,
        warningWave1Bounces: 4,
        minionHp: Object.freeze([800, 1500]),
        minionFireEveryMs: 5000,
        minionBulletSpeed: 108,
        laserTriggerRatio: 0.10,
        laserWarningMs: 1300,
        laserDurationMs: 5000,
        laserWidthRatio: 0.50,
      }),
      playable: true,
    }),

  });

  function toBeginnerStageId(stageId) {
    const id = String(stageId || '');
    if (!id) return '';
    if (id.startsWith('shooting_beginner_')) return id;
    return id.replace(/^shooting_/, 'shooting_beginner_');
  }

  function fromBeginnerStageId(stageId) {
    return String(stageId || '').replace(/^shooting_beginner_/, 'shooting_');
  }

  function makeBeginnerStage(baseStage) {
    if (!baseStage || !baseStage.id || !Number(baseStage.chapter)) return null;
    const reduceBullets =
      Number(baseStage.chapter) !== 5 && (
        Number(baseStage.chapter) > 3 ||
        (Number(baseStage.chapter) === 3 && Number(baseStage.stageNo || 0) >= 4)
      );

    return Object.freeze({
      ...baseStage,
      id: toBeginnerStageId(baseStage.id),
      beginnerMode: true,
      baseStageId: baseStage.id,
      bulletQuantityMultiplier: reduceBullets ? 0.60 : 1.0,
    });
  }

  function getShootingStage(stageId) {
    const id = String(stageId || '');
    if (id.startsWith('shooting_beginner_')) {
      return makeBeginnerStage(SHOOTING_STAGES[fromBeginnerStageId(id)] || null);
    }
    return SHOOTING_STAGES[id] || null;
  }

  function getShootingStagesByChapter(chapter) {
    const ch = Number(chapter);
    return Object.values(SHOOTING_STAGES)
      .filter(stage => stage && Number(stage.chapter) === ch)
      .sort((a, b) => a.stageNo - b.stageNo);
  }

  function getBeginnerShootingStagesByChapter(chapter) {
    return getShootingStagesByChapter(chapter)
      .map(makeBeginnerStage)
      .filter(Boolean);
  }

  function getShootingChapter01Stages() {
    return getShootingStagesByChapter(1);
  }

  function getShootingStagePrimaryEnemy(stageId) {
    const stage = getShootingStage(stageId);
    if (!stage || !Array.isArray(stage.enemyIds) || !stage.enemyIds.length) return null;
    return window.ShootingEnemies.getShootingEnemy(stage.enemyIds[0]);
  }

  window.ShootingStages = Object.freeze({
    SHOOTING_MISSION_TYPE,
    SHOOTING_CHAPTER_TITLES,
    SHOOTING_STAGE_ID,
    SHOOTING_STAGES,
    getShootingStage,
    getShootingStagesByChapter,
    getBeginnerShootingStagesByChapter,
    toBeginnerStageId,
    fromBeginnerStageId,
    getShootingChapter01Stages,
    getShootingStagePrimaryEnemy,
  });
})();
