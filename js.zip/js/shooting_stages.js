// Zeraphia Shooting - standalone stage master
// Strategy stages.js is NOT referenced.
// CHAPTER 01 foundation: 01-03 normal mission stages / 04 boss.
(function () {
  'use strict';

  if (!window.ShootingEnemies) {
    throw new Error('shooting_stages.js requires shooting_enemies.js');
  }

  const { SHOOTING_ENEMY_ID } = window.ShootingEnemies;

  const SHOOTING_MISSION_TYPE = Object.freeze({
    COLLECT_ITEM: 'collect_item',
    CLEAR_TIME: 'clear_time',
    MAX_HITS_TAKEN: 'max_hits_taken',
    BOSS_CLEAR: 'boss_clear',
    DEFEAT_ALL: 'defeat_all',

    // Future mission types reserved for later chapters.
    MAX_COMBO: 'max_combo',
    MIN_ULT_USE: 'min_ult_use',
    MIN_SWITCH_COUNT: 'min_switch_count',
    NO_DOWN: 'no_down',
    SCORE: 'score',
    SURVIVE_TIME: 'survive_time',
  });

  const SHOOTING_STAGE_ID = Object.freeze({
    CH01_01: 'shooting_ch01_01',
    CH01_02: 'shooting_ch01_02',
    CH01_03: 'shooting_ch01_03',
    CH01_04: 'shooting_ch01_04',

    CH02_01: 'shooting_ch02_01',
    CH02_02: 'shooting_ch02_02',
    CH02_03: 'shooting_ch02_03',
    CH02_04: 'shooting_ch02_04',

    CH03_01: 'shooting_ch03_01',
    CH03_02: 'shooting_ch03_02',
    CH03_03: 'shooting_ch03_03',
    CH03_04: 'shooting_ch03_04',

    CH04_01: 'shooting_ch04_01',
    CH04_02: 'shooting_ch04_02',
    CH04_03: 'shooting_ch04_03',
    CH04_04: 'shooting_ch04_04',

    CH05_01: 'shooting_ch05_01',
    CH05_02: 'shooting_ch05_02',
    CH05_03: 'shooting_ch05_03',

    CH06_01: 'shooting_ch06_01',
    CH06_02: 'shooting_ch06_02',
    CH06_03: 'shooting_ch06_03',

    CH07_01: 'shooting_ch07_01',
    CH07_02: 'shooting_ch07_02',
    CH07_03: 'shooting_ch07_03',

    DAILY_MON_INTERMEDIATE: 'shooting_daily_mon_intermediate',
    DAILY_MON_ADVANCED: 'shooting_daily_mon_advanced',
    DAILY_TUE_INTERMEDIATE: 'shooting_daily_tue_intermediate',
    DAILY_TUE_ADVANCED: 'shooting_daily_tue_advanced',
    DAILY_WED_INTERMEDIATE: 'shooting_daily_wed_intermediate',
    DAILY_WED_ADVANCED: 'shooting_daily_wed_advanced',
    DAILY_THU_INTERMEDIATE: 'shooting_daily_thu_intermediate',
    DAILY_THU_ADVANCED: 'shooting_daily_thu_advanced',
    DAILY_FRI_INTERMEDIATE: 'shooting_daily_fri_intermediate',
    DAILY_FRI_ADVANCED: 'shooting_daily_fri_advanced',
    DAILY_SAT_INTERMEDIATE: 'shooting_daily_sat_intermediate',
    DAILY_SAT_ADVANCED: 'shooting_daily_sat_advanced',
    DAILY_SUN_INTERMEDIATE: 'shooting_daily_sun_intermediate',
    DAILY_SUN_ADVANCED: 'shooting_daily_sun_advanced',
    DAILY_EXP_INTERMEDIATE: 'shooting_daily_exp_intermediate',
    DAILY_EXP_ADVANCED: 'shooting_daily_exp_advanced',

    FACELESS_ADVANCED: 'shooting_event_faceless_advanced',
    FACELESS_SUPER: 'shooting_event_faceless_super',
    RAID_TEST: 'shooting_raid_test',
    BULLET_HELL_TEST: 'shooting_event_bullet_hell_test',
    SCORE_ATTACK_NORMAL: 'shooting_score_attack_normal',
    SCORE_ATTACK_HARD: 'shooting_score_attack_hard',
    OVERSEER_AMBUSH: 'shooting_event_overseer_ambush',
  });

  // ============================================================
  // CHAPTER 01
  // ============================================================
  //
  // 01 朝:
  //   収集を覚えるステージ
  //
  // 02 呼吸:
  //   攻撃効率 / キャラ交代を意識するタイムアタック
  //
  // 03 邂逅:
  //   赤コアを意識して避ける被弾管理
  //
  // 04 旅立ち:
  //   オーバーシアBOSS
  //
  function makeDailyStage(config) {
    const level = config.level === 'advanced' ? 'advanced' : 'intermediate';
    const questType = config.questType === 'exp' ? 'exp' : 'weekday';
    const rewardCount = Math.max(1, Number(config.rewardCount || (level === 'advanced' ? 2 : 1)));
    const advancedGimmick = level === 'advanced' && config.advancedGimmick !== false;
    return Object.freeze({
      id: config.id,
      chapter: 0,
      stageNo: 0,
      name: config.name,
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze(Array.from(config.enemyIds || [])),

      // build549: DAILY上級はCH06と同系統の「遮断壁＋弱点属性限定」ギミック。
      // 敵ごとの属性はそのまま使うため、土日など複数属性が混在しても
      // 各個体の弱点属性だけが有効になる。
      weaknessOnlyEnemies: advancedGimmick,
      chapter6Barriers: advancedGimmick
        ? Object.freeze([
            Object.freeze({ xRate:.50, yRate:.49, widthRate:.70, height:23, moveRangeRate:.10, moveSpeed:.30, contactDamage:85 })
          ])
        : Object.freeze([]),

      normalBattle: Object.freeze({
        totalEnemies: Math.max(1, Number(config.totalEnemies || (level === 'advanced' ? 8 : 5))),
        maxActive: Math.max(1, Number(config.maxActive || (level === 'advanced' ? 3 : 2))),
        spawnIntervalMs: Math.max(500, Number(config.spawnIntervalMs || (level === 'advanced' ? 1050 : 1250))),
      }),
      mission: Object.freeze({ type: SHOOTING_MISSION_TYPE.DEFEAT_ALL, text: '敵をすべて撃破' }),
      dailyQuest: Object.freeze({
        weekday: config.weekday || '',
        level,
        questType,
        runLevel: questType === 'exp' ? `exp_${level}` : level,
        rewardId: config.rewardId || '',
        rewardPool: Object.freeze(Array.from(config.rewardPool || [])),
        rewardCount,
      }),
      stageInfoWeekday: config.stageInfoWeekday || '',
      playable: true,
    });
  }

  const SHOOTING_STAGES = Object.freeze({
    [SHOOTING_STAGE_ID.CH01_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH01_01,
      chapter: 1,
      stageNo: 1,
      name: '朝',
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH01 main = LIGHT. 5/7 LIGHT, AQUA/WOODを少量混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_01,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 7,
        maxActive: 2,
        spawnIntervalMs: 950,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.MINI_01,
        ]),
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 3,
        text: '生命エネルギーを取得しろ',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH01_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH01_02,
      chapter: 1,
      stageNo: 2,
      name: '呼吸',
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH01 main = LIGHT. LIGHTを主成分にAQUA/WOOD/DARKを混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_01,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 9,
        maxActive: 3,
        spawnIntervalMs: 820,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.MINI_01,
        ]),
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.CLEAR_TIME,
        targetSeconds: 90,
        text: '90秒以内にクリア',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH01_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH01_03,
      chapter: 1,
      stageNo: 3,
      name: '邂逅',
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH01 main = LIGHT. 7/11 LIGHT、DARKを次点にFIRE/WOODを少量混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_01,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_LASER,
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 11,
        maxActive: 3,
        spawnIntervalMs: 720,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.ZAKO_DARK_LASER,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
          SHOOTING_ENEMY_ID.MINI_01,
          SHOOTING_ENEMY_ID.MINI_01,
        ]),
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.MAX_HITS_TAKEN,
        maxHits: 3,
        text: '被弾3回以内でクリア',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH01_04]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH01_04,
      chapter: 1,
      stageNo: 4,
      name: '旅立ち',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      bossElement: 'light',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.REMNANT_01,
      ]),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'オーバーシアを撃破',
      }),

      playable: true,
    }),

    // ============================================================
    // CHAPTER 02 - 暴力
    // 数ではなく、一体一体の圧力でプレイヤーを追い詰める章。
    // ============================================================
    [SHOOTING_STAGE_ID.CH02_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH02_01,
      chapter: 2,
      stageNo: 1,
      name: '圧',
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH02 main = FIRE. 2/3 FIRE、WOODを少量混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 3,
        maxActive: 1,
        spawnIntervalMs: 1300,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
        ]),
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '強敵をすべて撃破',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH02_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH02_02,
      chapter: 2,
      stageNo: 2,
      name: '蹂躙',
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH02 main = FIRE. 3/4 FIRE、LIGHTを少量混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE,
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 4,
        maxActive: 2,
        spawnIntervalMs: 1500,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE,
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
        ]),
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.CLEAR_TIME,
        targetSeconds: 150,
        text: '150秒以内に強敵を撃破',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH02_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH02_03,
      chapter: 2,
      stageNo: 3,
      name: '威圧',
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH02 main = FIRE. FIREのSHOT/LASERを主軸にAQUAを混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 3,
        maxActive: 2,
        spawnIntervalMs: 1450,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER,
        ]),
        chargeSpeed: 470,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.MAX_HITS_TAKEN,
        maxHits: 3,
        text: '被弾3回以内でクリア',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH02_04]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH02_04,
      chapter: 2,
      stageNo: 4,
      name: '暴力',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      bossElement: 'fire',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.REMNANT_02,
      ]),

      // BOSS戦ではFIRE主体の援軍にLIGHTを少量混ぜる。
      // 4体中3体FIRE / 1体LIGHT = 75% / 25%。
      bossAdds: Object.freeze({
        enemyIds: Object.freeze([
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE,
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
        ]),
        totalEnemies: 4,
        maxActive: 1,
        startDelayMs: 4500,
        spawnIntervalMs: 7000,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'REMNANT 02「暴力」を浄化',
      }),

      // ボス画像 images/remnant_02_battle.webp を配置すればそのまま遊べる。
      playable: true,
    }),

    // ============================================================
    // CHAPTER 03 - 弾幕
    // アイテムを拾いながら、濃い弾幕を抜けて進む章。
    // 01-03は収集、04は本格的な弾幕ボス戦。
    // ============================================================
    [SHOOTING_STAGE_ID.CH03_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH03_01,
      chapter: 3,
      stageNo: 1,
      name: '羽音',
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH03 main = WOOD. 7/10 WOODを基準に他属性を混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_03,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ]),
      normalBattle: Object.freeze({
        infiniteEnemies: true,
        maxActive: 2,
        spawnIntervalMs: 980,
        itemDropRate: 0.80,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
        ]),

        enemyHp: 900,
        enemyBulletDamage: 75,
        enemyBulletSpeed: 190,
        enemyFireRate: 1450,
        barrageLevel: 1,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 3,
        text: '生命エネルギーを取得しろ',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH03_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH03_02,
      chapter: 3,
      stageNo: 2,
      name: '星雨',
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH03 main = WOOD. 7/10 WOODを基準に他属性を混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_03,
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,
      ]),
      normalBattle: Object.freeze({
        infiniteEnemies: true,
        maxActive: 2,
        spawnIntervalMs: 850,
        itemDropRate: 0.80,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT,
        ]),

        enemyHp: 1200,
        enemyBulletDamage: 95,
        enemyBulletSpeed: 215,
        enemyFireRate: 1230,
        barrageLevel: 2,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 3,
        text: '生命エネルギーを取得しろ',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH03_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH03_03,
      chapter: 3,
      stageNo: 3,
      name: '交差',
      type: 'normal',
      background: 'images/battle_bg_01.webp',

      // CH03 main = WOOD. 7/10 WOODを基準に他属性を混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_03,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_LASER,
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER,
      ]),
      normalBattle: Object.freeze({
        infiniteEnemies: true,
        maxActive: 3,
        spawnIntervalMs: 760,
        itemDropRate: 0.80,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.MINI_03,
          SHOOTING_ENEMY_ID.ZAKO_DARK_LASER,
        ]),

        enemyHp: 1500,
        enemyBulletDamage: 115,
        enemyBulletSpeed: 235,
        enemyFireRate: 1080,
        barrageLevel: 3,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 3,
        text: '生命エネルギーを取得しろ',
      }),

      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH03_04]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH03_04,
      chapter: 3,
      stageNo: 4,
      name: '雨冠',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      bossElement: 'wood',

      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.REMNANT_03,
      ]),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'REMNANT 03「天墜」を浄化',
      }),

      playable: true,
    }),


    // ============================================================
    // CHAPTER 04 - 美しい弾幕
    // 密度で押すCH03とは分離し、規則性・軌跡・余白の美しさを主役にする。
    // 01: 螺旋 / 02: 波 / 03: 螺旋と波の複合 / 04: BOSS予約枠
    // ============================================================
    [SHOOTING_STAGE_ID.CH04_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH04_01,
      chapter: 4,
      stageNo: 1,
      name: '棘雨',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      bossElement: 'light',
      timeLimitSeconds: 60,
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.REMNANT_04]),
      chapter4Curtain: Object.freeze({
        intervalMs: 650,
        speed: 116,
        gap: 36,
        rowGapY: 23,
        columnsTop: 9,
        columnsBottom: 8,
      }),
      finalItem: Object.freeze({ timeoutSeconds: 10 }),
      eriOnly: true,
      survivalBoss: true,
      dangerEveryMs: 10000,
      dangerWays: 2,
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.SURVIVE_TIME,
        targetSeconds: 60,
        text: '60秒生存後、10秒以内に出現アイテムを取得せよ',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH04_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH04_02,
      chapter: 4,
      stageNo: 2,
      name: '狭界',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      bossElement: 'light',
      timeLimitSeconds: 60,
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.REMNANT_04]),
      chapter4Curtain: Object.freeze({
        intervalMs: 610,
        speed: 122,
        gap: 34,
        rowGapY: 22,
        columnsTop: 9,
        columnsBottom: 8,
      }),
      shrinkWalls: Object.freeze({
        startAtSeconds: 10,
        endAtSeconds: 60,
        minWidthRatio: 0.5,
      }),
      finalItem: Object.freeze({ timeoutSeconds: 10 }),
      eriOnly: true,
      survivalBoss: true,
      dangerEveryMs: 10000,
      dangerWays: 2,
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.SURVIVE_TIME,
        targetSeconds: 60,
        text: '60秒生存後、10秒以内に出現アイテムを取得せよ',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH04_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH04_03,
      chapter: 4,
      stageNo: 3,
      name: 'サキエル',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      bossElement: 'light',
      introImage: 'images/enemy_sakiel_battle.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.REMNANT_04]),
      chapter4Curtain: Object.freeze({
        intervalMs: 570,
        speed: 132,
        gap: 32,
        rowGapY: 21,
        columnsTop: 10,
        columnsBottom: 9,
      }),
      // build1042: 通常ボス戦 + 記憶のかけら3段階ゲート。
      // 75% / 50% / 25%でHPが止まり、対応するかけらを拾うまで以降のダメージを通さない。
      memoryFragments: Object.freeze({
        thresholds: Object.freeze([0.75, 0.50, 0.25]),
        count: 3,
      }),
      dangerEveryMs: 10000,
      dangerWays: 2,
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: '記憶のかけらを集め、サキエルを撃破せよ',
      }),
      playable: true,
    }),

    // ============================================================
    // CHAPTER 05 - 境界のマリオネット
    // 全ステージ共通：左右操作反転。
    // HARDを基準仕様とし、NORMALも同一仕様で提供する。
    // ============================================================
    [SHOOTING_STAGE_ID.CH05_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH05_01,
      chapter: 5,
      stageNo: 1,
      name: '境界のマリオネット',
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/remnant_05_battle_start.webp',
      reverseHorizontalControls: true,
      // CH05 main = DARK. 7/10 DARK、LIGHTを次点にAQUAを少量混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_05,
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 6,
        maxActive: 3,
        spawnIntervalMs: 760,
        infiniteEnemies: true,
        enemyHp: 1100,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.MINI_05,
          SHOOTING_ENEMY_ID.MINI_05,
          SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
          SHOOTING_ENEMY_ID.MINI_05,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
          SHOOTING_ENEMY_ID.MINI_05,
          SHOOTING_ENEMY_ID.MINI_05,
          SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
          SHOOTING_ENEMY_ID.MINI_05,
          SHOOTING_ENEMY_ID.MINI_05,
        ]),
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.COLLECT_ITEM,
        target: 3,
        text: 'アイテムを3つ取得しろ',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH05_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH05_02,
      chapter: 5,
      stageNo: 2,
      name: '境界のマリオネット',
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/remnant_05_battle_start.webp',
      reverseHorizontalControls: true,
      // CH05 main = DARK. 2/3 DARK、LIGHTを混在。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.MINI_05,
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 3,
        maxActive: 3,
        spawnIntervalMs: 0,
        spawnAllAtStart: true,
        enemyHp: 1400,
        enemyFireRate: 940,
        enemyBulletSpeed: 245,
        enemyBulletDamage: 125,
        mirageWarningEveryMs: 5200,
        mirageWarningTelegraphMs: 700,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.MINI_05,
          SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
          SHOOTING_ENEMY_ID.MINI_05,
        ]),
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.CLEAR_TIME,
        targetSeconds: 90,
        text: '90秒以内に敵を3体撃破しろ',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH05_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH05_03,
      chapter: 5,
      stageNo: 3,
      name: 'レムナント：ミラージュ',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      bossElement: 'dark',
      introImage: 'images/remnant_05_battle_start.webp',
      reverseHorizontalControls: true,
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.REMNANT_05]),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'レムナント：ミラージュを撃破しろ',
      }),
      playable: true,
    }),


    // ============================================================
    // CHAPTER 06 - 遮断領域（仮）
    // 共通ギミック：破壊不能の壁。通常弾を遮断し、Homingの優先標的になる。
    // Laser / Shotgun は貫通可能。
    // 強敵・ボスは弱点属性以外のダメージを完全無効化する。
    // ============================================================
    [SHOOTING_STAGE_ID.CH06_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH06_01,
      chapter: 6,
      stageNo: 1,
      name: '遮断領域',
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      // CH06 main = AQUA. FIRE強敵は属性バリア教材として少数配置。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER,
        SHOOTING_ENEMY_ID.CH06_STRONG_FIRE,
      ]),
      weaknessOnlyElement: 'fire',
      chapter6Barriers: Object.freeze([
        Object.freeze({ xRate:.50, yRate:.47, widthRate:.78, height:24, moveRangeRate:.09, moveSpeed:.30, contactDamage:85 })
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 4,
        maxActive: 2,
        spawnIntervalMs: 900,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
          SHOOTING_ENEMY_ID.CH06_STRONG_FIRE,
        ]),
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '敵を退け、FIRE強敵を撃破しろ（AQUAのみ有効）',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH06_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH06_02,
      chapter: 6,
      stageNo: 2,
      name: '遮断領域',
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      // CH06 main = AQUA. DARK強敵は属性バリア教材として少数配置。
      enemyIds: Object.freeze([
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER,
        SHOOTING_ENEMY_ID.CH06_STRONG_DARK,
      ]),
      weaknessOnlyElement: 'dark',
      chapter6Barriers: Object.freeze([
        Object.freeze({ xRate:.50, yRate:.48, widthRate:.62, height:24, moveRangeRate:.12, moveSpeed:.32, contactDamage:85 })
      ]),
      normalBattle: Object.freeze({
        totalEnemies: 4,
        maxActive: 2,
        spawnIntervalMs: 850,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER,
          SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT,
          SHOOTING_ENEMY_ID.CH06_STRONG_DARK,
        ]),
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        text: '敵を退け、DARK強敵を撃破しろ（LIGHTのみ有効）',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH06_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH06_03,
      chapter: 6,
      stageNo: 3,
      name: 'レムナント06',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/remnant_06_battle_start.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.REMNANT_06]),
      weaknessOnlyElement: 'aqua',
      bossElement: 'aqua',
      // build1015: 弾幕の発射間隔倍率(barrage_v1 専用)。0.85 = 間隔15%短縮 ≒ 弾量+18%。
      // BEGINNER版では core 側で無視する(従来どおり)。
      bossBarrageIntervalMultiplier: 0.85,
      chapter6Barriers: Object.freeze([
        Object.freeze({ xRate:.34, yRate:.43, widthRate:.68, height:22, moveRangeRate:.08, moveSpeed:.28, phase:0, contactDamage:95 }),
        Object.freeze({ xRate:.67, yRate:.54, widthRate:.68, height:22, moveRangeRate:.08, moveSpeed:.32, phase:2.2, contactDamage:95 }),
      ]),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'AQUAボスを撃破しろ（WOODのみ有効）',
      }),
      playable: true,
    }),

    // ============================================================
    // SPECIAL EVENT - 無貌の天使
    // 「照射◯秒」は現行プレイ感の基準DPSを約190としてHP化。
    // wave1: 約40秒 → 7,600 / wave2: 約100秒 → 19,000
    // object: 約5秒 → 950
    // ============================================================
    // ============================================================
    // DAILY QUEST
    // 中級1個 / 上級2個。日曜のみ敵・報酬とも全属性ミックス。
    // ============================================================

    // ============================================================
    // CHAPTER 07 — FACELESS / REMNANT 07
    // 「属性」＋「手数」＋「操作」を要求する持ち物検査章。
    // 仮面OBJECTは通常HPではなく必要HIT数で破壊する。
    // ============================================================

    [SHOOTING_STAGE_ID.CH07_01]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH07_01,
      chapter: 7,
      stageNo: 1,
      name: '無貌Ⅰ',
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.FACELESS_MINI]),
      weaknessOnlyEnemies: true,
      normalBattle: Object.freeze({
        totalEnemies: 3,
        maxActive: 2,
        spawnIntervalMs: 1200,
        enemyHp: 2600,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.FACELESS_MINI,
          SHOOTING_ENEMY_ID.FACELESS_MINI,
          SHOOTING_ENEMY_ID.FACELESS_MINI,
        ]),
      }),
      ch07: Object.freeze({
        maskHitCount: 12,
        maskWays: 2,
        maskSpawnDelayMs: 750,
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        target: 3,
        text: 'FACELESSをすべて撃破',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH07_02]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH07_02,
      chapter: 7,
      stageNo: 2,
      name: '無貌Ⅱ',
      type: 'normal',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.FACELESS_MINI]),
      weaknessOnlyEnemies: true,
      normalBattle: Object.freeze({
        totalEnemies: 5,
        maxActive: 3,
        spawnIntervalMs: 980,
        enemyHp: 3400,
        enemySequence: Object.freeze([
          SHOOTING_ENEMY_ID.FACELESS_MINI,
          SHOOTING_ENEMY_ID.FACELESS_MINI,
          SHOOTING_ENEMY_ID.FACELESS_MINI,
          SHOOTING_ENEMY_ID.FACELESS_MINI,
          SHOOTING_ENEMY_ID.FACELESS_MINI,
        ]),
      }),
      ch07: Object.freeze({
        maskHitCount: 18,
        maskWays: 3,
        maskSpawnDelayMs: 620,
      }),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.DEFEAT_ALL,
        target: 5,
        text: 'FACELESSをすべて撃破',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.CH07_03]: Object.freeze({
      id: SHOOTING_STAGE_ID.CH07_03,
      chapter: 7,
      stageNo: 3,
      name: 'REMNANT 07',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/remnant_07_battle_start.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.REMNANT_07]),
      bossElement: 'dark',

      // REMNANT07本体はDARK属性バリア。
      // DARKに対して弱点となる属性、またはNEUTRALだけが通る。
      weaknessOnlyElement: 'dark',

      // 開幕はFACELESSを倒すまで完全シールド。
      bossAdds: Object.freeze({
        enemyIds: Object.freeze([SHOOTING_ENEMY_ID.FACELESS_MINI]),
        totalEnemies: 2,
        maxActive: 2,
        spawnIntervalMs: 260,
        startDelayMs: 0,
      }),

      ch07: Object.freeze({
        maskHitCount: 20,
        maskWays: 3,
        maskSpawnDelayMs: 520,

        // 突進
        dashIntervalMs: 6000,
        dashWarningMs: 700,
        dashTravelMs: 430,
        dashReturnMs: 480,

        // 透明化。鳥居を時間内に破壊できないと7秒ロス。
        vanishIntervalMs: 10500,
        toriiHitCount: 24,
        toriiBreakWindowMs: 2800,
        invisibleMs: 7000,

        // HP50%でREMNANT07が増殖。
        cloneTriggerRatio: 0.50,
        cloneCount: 2,
        cloneHp: 5200,
      }),

      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'REMNANT 07を撃破',
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.DAILY_MON_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_MON_INTERMEDIATE, weekday: 'Mon', level: 'intermediate', name: '月曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT], rewardId: 'soul_vessel_dark',
    }),
    [SHOOTING_STAGE_ID.DAILY_MON_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_MON_ADVANCED, weekday: 'Mon', level: 'advanced', name: '月曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_DARK_LASER], rewardId: 'soul_vessel_dark',
    }),
    [SHOOTING_STAGE_ID.DAILY_TUE_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_TUE_INTERMEDIATE, weekday: 'Tue', level: 'intermediate', name: '火曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE], rewardId: 'soul_vessel_fire',
    }),
    [SHOOTING_STAGE_ID.DAILY_TUE_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_TUE_ADVANCED, weekday: 'Tue', level: 'advanced', name: '火曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER, SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE],
      rewardId: 'soul_vessel_fire',
    }),
    [SHOOTING_STAGE_ID.DAILY_WED_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_WED_INTERMEDIATE, weekday: 'Wed', level: 'intermediate', name: '水曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT], rewardId: 'soul_vessel_aqua',
    }),
    [SHOOTING_STAGE_ID.DAILY_WED_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_WED_ADVANCED, weekday: 'Wed', level: 'advanced', name: '水曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER], rewardId: 'soul_vessel_aqua',
    }),
    [SHOOTING_STAGE_ID.DAILY_THU_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_THU_INTERMEDIATE, weekday: 'Thu', level: 'intermediate', name: '木曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT], rewardId: 'soul_vessel_wood',
    }),
    [SHOOTING_STAGE_ID.DAILY_THU_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_THU_ADVANCED, weekday: 'Thu', level: 'advanced', name: '木曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_LASER], rewardId: 'soul_vessel_wood',
    }),
    [SHOOTING_STAGE_ID.DAILY_FRI_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_FRI_INTERMEDIATE, weekday: 'Fri', level: 'intermediate', name: '金曜巡行・中級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT], rewardId: 'soul_vessel_light',
    }),
    [SHOOTING_STAGE_ID.DAILY_FRI_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_FRI_ADVANCED, weekday: 'Fri', level: 'advanced', name: '金曜巡行・上級',
      enemyIds: [SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER], rewardId: 'soul_vessel_light',
    }),
    [SHOOTING_STAGE_ID.DAILY_SAT_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_SAT_INTERMEDIATE, weekday: 'Sat', level: 'intermediate', name: '土曜巡行・中級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ],
      rewardId: 'kyoumei_stone', totalEnemies: 5,
    }),
    [SHOOTING_STAGE_ID.DAILY_SAT_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_SAT_ADVANCED, weekday: 'Sat', level: 'advanced', name: '土曜巡行・上級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER, SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER, SHOOTING_ENEMY_ID.ZAKO_WOOD_LASER,
        SHOOTING_ENEMY_ID.ZAKO_DARK_LASER, SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER,
      ],
      rewardId: 'kyoumei_stone',
    }),
    [SHOOTING_STAGE_ID.DAILY_SUN_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_SUN_INTERMEDIATE, weekday: 'Sun', level: 'intermediate', name: '日曜巡行・中級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ],
      rewardPool: ['kyoumei_stone','soul_vessel_fire','soul_vessel_aqua','soul_vessel_wood','soul_vessel_dark','soul_vessel_light'],
      totalEnemies: 6,
    }),
    [SHOOTING_STAGE_ID.DAILY_SUN_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_SUN_ADVANCED, weekday: 'Sun', level: 'advanced', name: '日曜巡行・上級',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER, SHOOTING_ENEMY_ID.ZAKO_FIRE_CHARGE,
        SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER,
        SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_LASER,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_DARK_LASER,
        SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER,
      ],
      rewardPool: ['kyoumei_stone','soul_vessel_fire','soul_vessel_aqua','soul_vessel_wood','soul_vessel_dark','soul_vessel_light'],
      totalEnemies: 10, maxActive: 3, spawnIntervalMs: 950,
    }),

    // build1026: 経験値素材専用DAILY。
    // 中級/上級とも報酬は10個。実際の抽選率と付与はSupabase側を正本とする。
    [SHOOTING_STAGE_ID.DAILY_EXP_INTERMEDIATE]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_EXP_INTERMEDIATE,
      questType: 'exp', level: 'intermediate', name: '経験値素材巡行・中級', stageInfoWeekday: '経験値素材',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_SHOT, SHOOTING_ENEMY_ID.ZAKO_AQUA_SHOT, SHOOTING_ENEMY_ID.ZAKO_WOOD_SHOT,
        SHOOTING_ENEMY_ID.ZAKO_DARK_SHOT, SHOOTING_ENEMY_ID.ZAKO_LIGHT_SHOT,
      ],
      rewardPool: ['level_exp_small','level_exp_medium','level_exp_large'],
      rewardCount: 10,
      totalEnemies: 6, maxActive: 2, spawnIntervalMs: 1150,
    }),
    [SHOOTING_STAGE_ID.DAILY_EXP_ADVANCED]: makeDailyStage({
      id: SHOOTING_STAGE_ID.DAILY_EXP_ADVANCED,
      questType: 'exp', level: 'advanced', name: '経験値素材巡行・上級', stageInfoWeekday: '経験値素材',
      enemyIds: [
        SHOOTING_ENEMY_ID.ZAKO_FIRE_LASER, SHOOTING_ENEMY_ID.ZAKO_AQUA_LASER, SHOOTING_ENEMY_ID.ZAKO_WOOD_LASER,
        SHOOTING_ENEMY_ID.ZAKO_DARK_LASER, SHOOTING_ENEMY_ID.ZAKO_LIGHT_LASER,
      ],
      rewardPool: ['level_exp_medium','level_exp_large'],
      rewardCount: 10,
      totalEnemies: 10, maxActive: 3, spawnIntervalMs: 950,
    }),

    [SHOOTING_STAGE_ID.FACELESS_ADVANCED]: Object.freeze({
      id: SHOOTING_STAGE_ID.FACELESS_ADVANCED,
      chapter: 0,
      stageNo: 1,
      eventId: 'faceless',
      eventTitle: '無貌の天使',
      stageInfoName: '無貌の残神',
      difficultyLabel: '上級',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/enemy_faceless_battle_start.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.FACELESS]),
      bossElement: 'dark',
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'フェイスレスを撃破',
      }),
      faceless: Object.freeze({
        difficulty: 'advanced',
        waveHp: Object.freeze([7600, 19000]),
        waveBarrage: Object.freeze(['light', 'medium']),
        objectHp: 950,
        objectWays: 2,
        waveObjectCount: Object.freeze([1, 2]),
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.FACELESS_SUPER]: Object.freeze({
      id: SHOOTING_STAGE_ID.FACELESS_SUPER,
      chapter: 0,
      stageNo: 2,
      eventId: 'faceless',
      eventTitle: '無貌の天使',
      stageInfoName: '無貌の残神',
      difficultyLabel: '最上級',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/enemy_faceless_battle_start.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.FACELESS]),
      bossElement: 'dark',
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: 'フェイスレスを撃破',
      }),
      faceless: Object.freeze({
        difficulty: 'super',
        waveHp: Object.freeze([7600, 19000]),
        waveBarrage: Object.freeze(['medium', 'dense']),
        objectHp: 950,
        objectWays: 3,
        waveObjectCount: Object.freeze([1, 2]),
      }),
      playable: true,
    }),


    // ============================================================
    // SPECIAL STAGE - 理想郷 -ノア-
    // パフォーマンス検証用のストレステストステージ。
    // 見た目は極限まで簡素化(装飾なし)。WAVE1から高密度、WAVE3でさらに濃く。
    // 1発被弾での即死はなし(4発被弾で撃破される想定のダメージ値)。
    // ============================================================
    [SHOOTING_STAGE_ID.BULLET_HELL_TEST]: Object.freeze({
      id: SHOOTING_STAGE_ID.BULLET_HELL_TEST,
      chapter: 0,
      stageNo: 3,
      eventId: 'bullet_hell_test',
      eventTitle: '理想郷 -ノア-',
      stageInfoName: '理想郷 -ノア-',
      // 戦闘開始時にSPECIAL STAGE TICKETを1枚消費。
      specialTicketCost: 1,
      difficultyLabel: 'STRESS TEST',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.NOAH]),
      // build1036: ノア固有ギミック。
      // 短い移動壁を上下2段に配置。WAVE2以降かつHP50%未満で出現し、左右へ独立して往復する。
      chapter6Barriers: Object.freeze([
        Object.freeze({
          xRate: .34,
          yRate: .42,
          widthRate: .25,
          height: 22,
          moveRangeRate: .19,
          moveSpeed: .36,
          phase: 0,
          contactDamage: 95
        }),
        Object.freeze({
          xRate: .66,
          yRate: .58,
          widthRate: .25,
          height: 22,
          moveRangeRate: .19,
          moveSpeed: .42,
          phase: 2.4,
          contactDamage: 95
        }),
      ]),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: '理想郷 -ノア-を耐えきれ',
      }),
      playable: true,
    }),


    // ============================================================
    // SCORE ATTACK - すこあた！
    // 60秒固定タイムライン。同じ難易度では毎回同じ弾幕。
    // NORMAL / HARD は弾道構成を共通にし、速度・被ダメージだけ変更。
    // ============================================================
    [SHOOTING_STAGE_ID.SCORE_ATTACK_NORMAL]: Object.freeze({
      id: SHOOTING_STAGE_ID.SCORE_ATTACK_NORMAL,
      chapter: 0,
      stageNo: 20,
      eventId: 'score_attack',
      eventTitle: 'スコアアタック',
      stageInfoBossName: 'すこあちゃん',
      difficultyLabel: 'NORMAL',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.BULLET_HELL_TEST]),
      survivalBoss: true,
      timeLimitSeconds: 60,
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.SURVIVE_TIME,
        targetSeconds: 60,
        text: '60秒間でハイスコアを目指せ',
      }),
      scoreAttack: Object.freeze({
        difficulty: 'normal',
        bulletSpeedMultiplier: 0.92,
        bulletDamage: 105,
        volleyIntervalMs: 880,
        maxEnemyBullets: 100,
        recoverEnemyBulletsTo: 76,
        maxPlayerBullets: 72,
        recoverPlayerBulletsTo: 54,
        warningDamageMultiplier: 2.0,
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.SCORE_ATTACK_HARD]: Object.freeze({
      id: SHOOTING_STAGE_ID.SCORE_ATTACK_HARD,
      chapter: 0,
      stageNo: 21,
      eventId: 'score_attack',
      eventTitle: 'スコアアタック',
      stageInfoBossName: 'すこあちゃん',
      difficultyLabel: 'HARD',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.BULLET_HELL_TEST]),
      survivalBoss: true,
      timeLimitSeconds: 60,
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.SURVIVE_TIME,
        targetSeconds: 60,
        text: '60秒間でハイスコアを目指せ',
      }),
      scoreAttack: Object.freeze({
        difficulty: 'hard',
        bulletSpeedMultiplier: 1.22,
        bulletDamage: 165,
        volleyIntervalMs: 880,
        maxEnemyBullets: 100,
        recoverEnemyBulletsTo: 76,
        maxPlayerBullets: 72,
        recoverPlayerBulletsTo: 54,
        warningDamageMultiplier: 2.0,
      }),
      playable: true,
    }),


    // ============================================================
    // DAILY RAID - ザ・テスト
    // 共有HP 100,000 / 最大4人 / 1日1回。
    // 実際の残HPはSupabaseのraidContextからshooting_core側で上書きする。
    // ============================================================
    [SHOOTING_STAGE_ID.RAID_TEST]: Object.freeze({
      id: SHOOTING_STAGE_ID.RAID_TEST,
      chapter: 0,
      stageNo: 1,
      eventId: 'raid',
      eventTitle: 'ザ・テスト',
      stageInfoBossName: 'SIGMA-IX',
      difficultyLabel: 'DAILY RAID',
      type: 'boss',
      background: 'images/battle_bg_01.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.RAID_TEST]),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: '共有HPを削れ',
      }),
      raid: Object.freeze({
        bossId: 'the_test',
        maxHp: 100000,
        maxPlayers: 4,
        attemptsPerDay: 1,
        timeLimitSeconds: 180,
      }),
      playable: true,
    }),

    [SHOOTING_STAGE_ID.OVERSEER_AMBUSH]: Object.freeze({
      id: SHOOTING_STAGE_ID.OVERSEER_AMBUSH,
      chapter: 0,
      stageNo: 0,
      name: '緊急遭遇',
      type: 'boss',
      eventId: 'random_ambush',
      background: 'images/battle_bg_01.webp',
      introImage: 'images/remnant_01_blk_battle_start.webp',
      enemyIds: Object.freeze([SHOOTING_ENEMY_ID.OVERSEER_AMBUSH]),
      mission: Object.freeze({
        type: SHOOTING_MISSION_TYPE.BOSS_CLEAR,
        text: '???を撃破',
      }),
      guaranteedRewards: Object.freeze([
        Object.freeze({
          type: 'material',
          id: 'overseer_blk_core',
          name: '???の心核',
          image: 'images/item_overseer_blk_core.webp',
          count: 1,
          detail: '特殊強化素材',
        }),
      ]),
      ambush: Object.freeze({
        triggerRate: 0.10,
        waveHp: Object.freeze([5000, 8000]),
        waveDamage: Object.freeze([350, 600]),
        warningEveryMs: 4000,
        warningWave1Bounces: 4,
        minionHp: Object.freeze([800, 1500]),
        minionFireEveryMs: 5000,
        minionBulletSpeed: 108,
        laserTriggerRatio: 0.10,
        laserWarningMs: 1300,
        laserDurationMs: 5000,
        laserWidthRatio: 0.50,
      }),
      playable: true,
    }),

  });

  function toBeginnerStageId(stageId) {
    const id = String(stageId || '');
    if (!id) return '';
    if (id.startsWith('shooting_beginner_')) return id;
    return id.replace(/^shooting_/, 'shooting_beginner_');
  }

  function fromBeginnerStageId(stageId) {
    return String(stageId || '').replace(/^shooting_beginner_/, 'shooting_');
  }

  function makeBeginnerStage(baseStage) {
    if (!baseStage || !baseStage.id || !Number(baseStage.chapter)) return null;
    const reduceBullets =
      Number(baseStage.chapter) !== 5 && (
        Number(baseStage.chapter) > 3 ||
        (Number(baseStage.chapter) === 3 && Number(baseStage.stageNo || 0) >= 4)
      );

    return Object.freeze({
      ...baseStage,
      id: toBeginnerStageId(baseStage.id),
      beginnerMode: true,
      baseStageId: baseStage.id,
      bulletQuantityMultiplier: reduceBullets ? 0.60 : 1.0,
    });
  }

  function getShootingStage(stageId) {
    const id = String(stageId || '');
    if (id.startsWith('shooting_beginner_')) {
      return makeBeginnerStage(SHOOTING_STAGES[fromBeginnerStageId(id)] || null);
    }
    return SHOOTING_STAGES[id] || null;
  }

  function getShootingStagesByChapter(chapter) {
    const ch = Number(chapter);
    return Object.values(SHOOTING_STAGES)
      .filter(stage => stage && Number(stage.chapter) === ch)
      .sort((a, b) => a.stageNo - b.stageNo);
  }

  function getBeginnerShootingStagesByChapter(chapter) {
    return getShootingStagesByChapter(chapter)
      .map(makeBeginnerStage)
      .filter(Boolean);
  }

  function getShootingChapter01Stages() {
    return getShootingStagesByChapter(1);
  }

  function getShootingStagePrimaryEnemy(stageId) {
    const stage = getShootingStage(stageId);
    if (!stage || !Array.isArray(stage.enemyIds) || !stage.enemyIds.length) return null;
    return window.ShootingEnemies.getShootingEnemy(stage.enemyIds[0]);
  }

  window.ShootingStages = Object.freeze({
    SHOOTING_MISSION_TYPE,
    SHOOTING_STAGE_ID,
    SHOOTING_STAGES,
    getShootingStage,
    getShootingStagesByChapter,
    getBeginnerShootingStagesByChapter,
    toBeginnerStageId,
    fromBeginnerStageId,
    getShootingChapter01Stages,
    getShootingStagePrimaryEnemy,
  });
})();
