// shinju.js
// ZERAPHIA: 神樹 / ゼラフィア創世進捗
// 依存: なし
// 使い方:
//   openShinjuScreen()                         : 神樹画面を開く
//   ShinjuProgress.grantBossItemFromRoguelite(): ボス撃破アイテムを付与
//   ShinjuProgress.getState()                  : 現在状態を取得

(function () {
  'use strict';

  const STORAGE_KEY = 'zeraphia_shinju_progress_v1';
  const CLOUD_STORAGE_KEY = 'zeraphia_shinju_v1';
  const EVENT_NAME = 'shinju-progress-updated';
  const MAX_STAGE = 5;
  // build1785: 射速（rate）・耐性（resist）SLOTを追加。神樹EXP（木の成長）には数えない（サーバー側で hp/atk/ult のみ合計）。
  const BLESSING_SLOTS = Object.freeze(['hp', 'atk', 'ult', 'rate', 'resist']);
  const BLESSING_LABELS = Object.freeze({ hp: 'HP SLOT', atk: 'ATK SLOT', ult: 'ULT SLOT', rate: 'RATE SLOT', resist: 'GUARD SLOT' });
  // build896: Supabase is the authority. localStorage is display/offline cache only.
  let authoritativeState = null;
  let shinjuServerReady = false;
  let shinjuRefreshPromise = null;

  // stage 1 = shinju_01.webp（芽） / stage 5 = shinju_05.webp（大木）
  // build1605: 聖樹の息吹1個=1。Lv5(MAX)まで累計500個。1段ごとの必要数 50→90→140→220（サーバー _shinju_level_for と揃える）
  // build1610: 神樹EXP ＝ 3SLOTに注いだ創世ptの合計。Lv5(MAX)＝全SLOT Lv10（456pt）
  const STAGE_EXP = [0, 50, 140, 280, 456];
  const COMPLETE_EXP = 456;
  // SLOT育成（サーバー _shinju_slot_cost と揃える）。効果はLvごとに HP/ATK +2.5%、ULT還元 +2%
  const SLOT_MAX_LEVEL = 10;
  const SLOT_COSTS = Object.freeze([5, 6, 8, 10, 12, 15, 18, 22, 26, 30]);
  // rate：ショットの発射数 +3.3%/Lv（Lv10で+33%＝発射間隔÷1.33） / resist：状態異常（吸収・燃焼・出血）のダメージ -5%/Lv（Lv10で50%カット）
  const SLOT_RATE_PER_LEVEL = Object.freeze({ hp: 0.025, atk: 0.025, ult: 0.02, rate: 0.033, resist: 0.05 });
  const STAGE_LABELS = [
    '萌芽',
    '若芽',
    '幼樹',
    '聖樹',
    '神樹',
  ];

  // 神聖樹の加護。段階1→5で最終 HP/ATK +25%、ULT還元20%。
  const BLESSING_RATE_BY_STAGE = Object.freeze({
    1: Object.freeze({ hp: 0.05, atk: 0.05, ult: 0.04 }),
    2: Object.freeze({ hp: 0.10, atk: 0.10, ult: 0.08 }),
    3: Object.freeze({ hp: 0.15, atk: 0.15, ult: 0.12 }),
    4: Object.freeze({ hp: 0.20, atk: 0.20, ult: 0.16 }),
    5: Object.freeze({ hp: 0.25, atk: 0.25, ult: 0.20 }),
  });

  const DEFAULT_BOSS_ITEM_EXP = 120;
  // build1608: 加護SLOTの差し替え・解除に必要な創世pt（サーバー set_shinju_blessing_secure と揃える）
  // build1610: 加護キャラの入れ替えは無料 → build1790で有料（10pt）に変更
  // build1790: キャラの配置・交換は創世pt 10（サーバー set_shinju_blessing_secure で減算）。同じキャラの再選択・解除は無料。
  const SLOT_CHANGE_COST = 10;
  const RUN_REWARD_MASTER = {
    default: {
      bossId: 'enemy_01',
      bossName: '竜型レムナント',
      itemName: '白糸の創世片',
      itemDesc: '白糸の残響から剥離した創世資源。入手すると自動で神樹の創世ptになる。',
      exp: 140,
    },
    sakiel: {
      bossId: 'enemy_sakiel_roguelite',
      bossName: '大天使 サキエル',
      itemName: '天使核・サキエル',
      itemDesc: 'サキエルの残響から得た創世核。入手すると自動で神樹の創世ptになる。',
      exp: 180,
    },
  };

  function clamp(n, min, max) {
    return Math.max(min, Math.min(max, Number(n || 0)));
  }

  function uid(prefix) {
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  }

  function safeParse(raw) {
    try { return raw ? JSON.parse(raw) : null; } catch (_) { return null; }
  }

  function stateTimestamp(state) {
    const t = Date.parse(state && state.updatedAt || '');
    return Number.isFinite(t) ? t : 0;
  }

  function readState() {
    if (authoritativeState) return normalizeState(authoritativeState);
    try {
      const legacy = safeParse(localStorage.getItem(STORAGE_KEY));
      const cloud = safeParse(localStorage.getItem(CLOUD_STORAGE_KEY));
      const selected = stateTimestamp(cloud) > stateTimestamp(legacy) ? cloud : (legacy || cloud);
      return normalizeState(selected || createInitialState());
    } catch (err) {
      console.warn('[ShinjuProgress] cache load failed:', err);
      return createInitialState();
    }
  }

  function applyServerPayload(payload) {
    const raw = payload && payload.state && typeof payload.state === 'object'
      ? payload.state
      : payload;
    const state = normalizeState(raw || createInitialState());
    authoritativeState = state;
    shinjuServerReady = true;
    writeStateLocal(state);
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: getViewState(state) }));
    scheduleAutoConvert();
    return getViewState(state);
  }

  // ------------------------------------------------------------
  // build1643: 「奉納」アクションを廃止。
  //  聖樹の息吹（神聖樹の資源）はサーバーで受け取り待ちに入った時点で、自動で創世ptへ変換する。
  //  変換そのものは従来の奉納RPC（offer_all_shinju_secure）をそのまま使うため、サーバー側の変更は不要。
  //  受け取り待ちが見つかるたび（起動時・報酬獲得後の同期・クラウド復元後）に、画面操作なしで実行する。
  // ------------------------------------------------------------
  let autoConvertBusy = false;
  let autoConvertTimer = 0;
  let autoConvertBlockedUntil = 0;
  function scheduleAutoConvert() {
    if (autoConvertTimer || autoConvertBusy) return;
    const s = authoritativeState;
    if (!s || !Array.isArray(s.inventory) || !s.inventory.length) return;
    if (Date.now() < autoConvertBlockedUntil) return;
    autoConvertTimer = setTimeout(() => { autoConvertTimer = 0; void autoConvertPending(); }, 120);
  }
  async function autoConvertPending() {
    if (autoConvertBusy) return null;
    const before = getViewState(readState());
    if (!before.inventory.length) return null;
    const sb = window.zsSupabase;
    if (!sb || typeof sb.rpc !== 'function') return null;
    autoConvertBusy = true;
    try {
      const res = await sb.rpc('offer_all_shinju_secure');
      if (res && res.error) throw res.error;
      let data = res ? res.data : null;
      if (typeof data === 'string') {
        try { data = JSON.parse(data); } catch (_) {}
      }
      const convertedCount = Math.max(0, Number(data && data.offered_count_now || 0));
      const gainedPt = Math.max(0, Number(data && data.offered_exp || 0));
      // 変換できなかった（サーバー側で対象なし等）場合は、同じ受け取り待ちで繰り返し呼ばないよう少し待つ
      if (!convertedCount) autoConvertBlockedUntil = Date.now() + 60000;
      autoConvertBusy = false;
      const after = applyServerPayload(data);
      const ov = document.getElementById('shinju-overlay');
      if (ov && ov.classList.contains('active')) renderOverlay();
      renderHomeEntry();
      if (convertedCount) {
        if (after.isMax && !before.isMax) setTimeout(showGameClearOverlay, 260);
        else if (after.stage > before.stage) showTinyToast(`神樹が成長した：${after.stage} / 5`);
        else if (gainedPt > 0) showTinyToast(`聖樹の息吹が神聖樹に還った　創世pt +${gainedPt}`);
      }
      return after;
    } catch (err) {
      autoConvertBusy = false;
      autoConvertBlockedUntil = Date.now() + 30000; // 通信失敗時は30秒後以降の同期で再試行
      console.warn('[ShinjuProgress] auto convert failed:', err && (err.message || err));
      return null;
    }
  }

  async function refreshFromServer() {
    if (shinjuRefreshPromise) return shinjuRefreshPromise;
    const sb = window.zsSupabase;
    if (!sb || typeof sb.rpc !== 'function') return getViewState(readState());

    shinjuRefreshPromise = (async () => {
      const res = await sb.rpc('get_shinju_state_secure');
      if (res && res.error) throw res.error;
      let data = res ? res.data : null;
      if (typeof data === 'string') {
        try { data = JSON.parse(data); } catch (_) {}
      }
      if (!data || data.ok === false) throw new Error('神聖樹データを取得できませんでした');
      return applyServerPayload(data);
    })().catch(err => {
      console.warn('[ShinjuProgress] secure refresh failed:', err && (err.message || err));
      return getViewState(readState());
    }).finally(() => {
      shinjuRefreshPromise = null;
    });

    return shinjuRefreshPromise;
  }

  function createInitialState() {
    return {
      exp: 0,
      inventory: [],
      offeredItems: [],
      gameClearSeen: false,
      blessings: { hp: null, atk: null, ult: null, rate: null, resist: null },
      updatedAt: new Date().toISOString(),
    };
  }

  function normalizeCharacterId(value) {
    const id = Number(value);
    return Number.isInteger(id) && id > 0 ? id : null;
  }

  function normalizeBlessings(value) {
    const src = value && typeof value === 'object' ? value : {};
    const normalized = {
      hp: normalizeCharacterId(src.hp),
      atk: normalizeCharacterId(src.atk),
      ult: normalizeCharacterId(src.ult),
      rate: normalizeCharacterId(src.rate),
      resist: normalizeCharacterId(src.resist),
    };

    // 同一キャラの重複加護は不可。古い/壊れた保存値も読み込み時に安全化する。
    const seen = new Set();
    BLESSING_SLOTS.forEach(slot => {
      const id = normalized[slot];
      if (id == null) return;
      if (seen.has(id)) normalized[slot] = null;
      else seen.add(id);
    });
    return normalized;
  }

  function normalizeSlots(value) {
    const src = value && typeof value === 'object' ? value : {};
    const lv = v => Math.max(0, Math.min(SLOT_MAX_LEVEL, Math.floor(Number(v || 0))));
    return { hp: lv(src.hp), atk: lv(src.atk), ult: lv(src.ult), rate: lv(src.rate), resist: lv(src.resist) };
  }
  function slotRates(slots) {
    const s = normalizeSlots(slots);
    const out = {};
    BLESSING_SLOTS.forEach(k => { out[k] = Math.round(s[k] * SLOT_RATE_PER_LEVEL[k] * 1000) / 1000; });
    return out;
  }
  function slotNextCost(level) {
    const lv = Math.floor(Number(level || 0));
    return lv >= SLOT_MAX_LEVEL ? null : SLOT_COSTS[lv];
  }
  function fmtPct(rate) {
    const v = Math.round(Number(rate || 0) * 1000) / 10;
    return (Number.isInteger(v) ? String(v) : v.toFixed(1)) + '%';
  }
  function normalizeState(state) {
    const s = state && typeof state === 'object' ? state : createInitialState();
    return {
      exp: Math.max(0, Number(s.exp || 0)),
      pt: Math.max(0, Number(s.pt || 0)),
      slots: normalizeSlots(s.slots),
      inventory: Array.isArray(s.inventory) ? s.inventory.filter(Boolean) : [],
      offeredItems: Array.isArray(s.offeredItems) ? s.offeredItems.filter(Boolean) : [],
      gameClearSeen: !!s.gameClearSeen,
      blessings: normalizeBlessings(s.blessings || s.blessingSlots || s.slots),
      updatedAt: s.updatedAt || new Date().toISOString(),
    };
  }

  let cloudSaveTimer = 0;
  function queueCloudSave() {
    // build896: direct client upsert is intentionally disabled.
    // Authoritative mutations use dedicated SECURITY DEFINER RPCs.
  }

  function writeStateLocal(state) {
    const s = normalizeState(state);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
    localStorage.setItem(CLOUD_STORAGE_KEY, JSON.stringify(s));
    return s;
  }

  function saveState(state, options) {
    // Cache-only helper. Never treats local data as authoritative.
    const s = normalizeState(state);
    s.updatedAt = new Date().toISOString();
    writeStateLocal(s);
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: getViewState(s) }));
    return s;
  }

  function getBlessingRates(stage) {
    const n = clamp(Math.floor(Number(stage || 1)), 1, MAX_STAGE);
    return Object.assign({}, BLESSING_RATE_BY_STAGE[n] || BLESSING_RATE_BY_STAGE[1]);
  }

  function getBlessingForCharacter(characterId, stateOverride) {
    const id = normalizeCharacterId(characterId);

    // Combat bonuses are disabled until a server-confirmed snapshot has loaded.
    // This prevents localStorage edits from becoming battle buffs.
    if (!shinjuServerReady || !authoritativeState) {
      return { characterId:id, stage:1, hpRate:0, atkRate:0, ultRefundRate:0, fireRateRate:0, statusResistRate:0 };
    }

    const view = getViewState(authoritativeState);
    const slots = view.blessings || {};
    const rates = view.blessingRates || slotRates(view.slots);
    return {
      characterId: id,
      stage: view.stage,
      hpRate: id != null && Number(slots.hp) === id ? Number(rates.hp || 0) : 0,
      atkRate: id != null && Number(slots.atk) === id ? Number(rates.atk || 0) : 0,
      ultRefundRate: id != null && Number(slots.ult) === id ? Number(rates.ult || 0) : 0,
      fireRateRate: id != null && Number(slots.rate) === id ? Number(rates.rate || 0) : 0,
      statusResistRate: id != null && Number(slots.resist) === id ? Math.min(0.5, Number(rates.resist || 0)) : 0,
    };
  }

  function applyBlessingToProfile(profile, characterId) {
    if (!profile || typeof profile !== 'object') return profile;
    const blessing = getBlessingForCharacter(characterId);
    if (!blessing.hpRate && !blessing.atkRate && !blessing.fireRateRate && !blessing.statusResistRate) return profile;
    const next = Object.assign({}, profile);
    if (blessing.hpRate) next.hp = Math.max(1, Math.round(Number(profile.hp || 1) * (1 + blessing.hpRate)));
    if (blessing.atkRate) next.atk = Math.max(0, Math.round(Number(profile.atk || 0) * (1 + blessing.atkRate)));
    // build1785: 射速。発射間隔を ÷(1+率)（Lv10で発射数1.33倍）。レーザーは1tickの間隔が縮むのでHIT数も増える。
    if (blessing.fireRateRate && Number(profile.fireRate) > 0) {
      next.fireRate = Math.max(30, Math.round(Number(profile.fireRate) / (1 + blessing.fireRateRate)));
    }
    next.shinjuBlessing = blessing;
    return next;
  }

  function getStageByExp(exp) {
    const value = Math.max(0, Number(exp || 0));
    let stage = 1;
    for (let i = 0; i < STAGE_EXP.length; i++) {
      if (value >= STAGE_EXP[i]) stage = i + 1;
    }
    return clamp(stage, 1, MAX_STAGE);
  }

  function getViewState(state) {
    const s = normalizeState(state || readState());
    const stage = getStageByExp(s.exp);
    const currentMin = STAGE_EXP[stage - 1] || 0;
    const nextNeed = stage >= MAX_STAGE ? COMPLETE_EXP : STAGE_EXP[stage];
    const isMax = s.exp >= COMPLETE_EXP;
    const intoStage = Math.max(0, s.exp - currentMin);
    const stageSpan = Math.max(1, nextNeed - currentMin);
    const progress = isMax ? 100 : clamp((intoStage / stageSpan) * 100, 0, 100);

    return Object.assign({}, s, {
      stage,
      maxStage: MAX_STAGE,
      stageLabel: STAGE_LABELS[stage - 1] || '神樹',
      progress,
      currentStageExp: currentMin,
      nextStageExp: isMax ? null : nextNeed,
      totalRequiredExp: COMPLETE_EXP,
      isMax,
      pendingItemCount: s.inventory.length,
      // build1605: 奉納待ちの「栄養の個数」（1行に複数個入ることがある）
      pendingNutrition: (s.inventory || []).reduce((sum, item) => sum + Math.max(0, Number(item && item.exp || 0)), 0),
      blessingRates: slotRates(s.slots),
      imageSrc: `images/shinju_${String(stage).padStart(2, '0')}.webp?v=1609`,
    });
  }

  async function setGameClearSeen(value) {
    const sb = window.zsSupabase;
    if (!sb || typeof sb.rpc !== 'function') return false;
    try {
      const res = await sb.rpc('set_shinju_game_clear_seen_secure', { p_seen: !!value });
      if (res && res.error) throw res.error;
      let data = res ? res.data : null;
      if (typeof data === 'string') {
        try { data = JSON.parse(data); } catch (_) {}
      }
      applyServerPayload(data);
      return true;
    } catch (err) {
      console.warn('[ShinjuProgress] clear-seen update failed:', err && (err.message || err));
      return false;
    }
  }

  function grantBossItem(opts) {
    // build896: reward creation is server-side.
    console.warn('[ShinjuProgress] client reward grant ignored; server-authoritative mode');
    void refreshFromServer();
    return { ok:false, reason:'server_authoritative' };
  }

  function grantBossItemFromRoguelite(payload) {
    // Reserved until the roguelite reward source is server-finalized.
    console.warn('[ShinjuProgress] roguelite client reward grant ignored in secure mode');
    void refreshFromServer();
    return { ok:false, reason:'server_authoritative' };
  }

  function offerItem(itemId) {
    return { ok:false, reason:'server_authoritative', state:getViewState(readState()) };
  }

  function offerAllItems() {
    return { ok:false, reason:'server_authoritative', state:getViewState(readState()) };
  }

  function escapeHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function ensureOverlay() {
    let ov = document.getElementById('shinju-overlay');
    if (ov) return ov;

    ov = document.createElement('div');
    ov.id = 'shinju-overlay';
    ov.innerHTML = `
      <div class="shinju-panel" role="dialog" aria-modal="true" aria-label="ゼラフィア創世進捗">
        <button class="shinju-close" type="button" onclick="closeShinjuScreen()">＜戻る</button>
        <div class="shinju-visual-wrap">
          <img class="shinju-visual" id="shinju-visual" src="images/shinju_01.webp?v=1609" alt="神樹">
          <div class="shinju-visual-glow"></div>
          <div class="shinju-aura-field" id="shinju-aura-field" aria-hidden="true"></div>
          <div class="shinju-hero-info" aria-label="神樹の成長情報">
            <div class="shinju-stage" id="shinju-stage"></div>
            <div class="shinju-progress-box">
              <div class="shinju-progress-head">
                <span id="shinju-exp-label"></span>
                <span id="shinju-exp-percent"></span>
              </div>
              <div class="shinju-progress-bg"><div class="shinju-progress-fill" id="shinju-progress-fill"></div></div>
            </div>
          </div>
        </div>
        <div class="shinju-content">
          <div class="shinju-lore" id="shinju-lore"></div>
          <section class="shinju-blessing-section" aria-label="神聖樹の加護">
            <div class="shinju-blessing-head">
              <strong>神聖樹の加護</strong>
              <span class="shinju-pt-chip" title="加護SLOTの変更に使う創世pt">創世pt <b id="shinju-pt-balance">0</b></span>
              <button type="button" class="shinju-help-btn" aria-label="加護の段階一覧" onclick="ShinjuProgress.openBlessingHelp()">?</button>
            </div>
            <div class="shinju-blessing-tabs" id="shinju-blessing-tabs" role="tablist">
              <button type="button" role="tab" data-blessing-tab="basic" onclick="ShinjuProgress.setBlessingTab('basic')">基本<small>HP / ATK / ULT</small></button>
              <button type="button" role="tab" data-blessing-tab="tactics" onclick="ShinjuProgress.setBlessingTab('tactics')">戦術<small>射速 / 耐性</small></button>
            </div>
            <div class="shinju-blessing-slots" id="shinju-blessing-slots"></div>
          </section>
          <p class="shinju-auto-note">聖樹の息吹は手に入れると自動で創世ptになります</p>
        </div>
      </div>
    `;
    ov.addEventListener('click', function (e) {
      if (e.target === ov) closeShinjuScreen();
    });
    document.body.appendChild(ov);
    return ov;
  }

  function renderHomeEntry() {
    const box = document.getElementById('shinju-home-entry');
    if (!box) return;
    const s = getViewState();

    // build522:
    // ホーム入口は「神聖樹」のテキストロゴをbutton側(data-home-head/rest)で描画する。
    // 旧ホーム画像は廃止済みのため、画像DOMを生成しない。
    box.innerHTML = `
      <span class="shinju-home-entry-badge" id="shinju-home-entry-badge" aria-hidden="true"></span>
    `;

    const label = s.isMax ? '創世完了' : `成長度 ${s.stage}/5`;
    // build1643: 奉納を廃止（聖樹の息吹は自動で創世ptになる）ため、「奉納待ち」バッジは出さない
    const itemText = `創世pt ${Math.max(0, Number(s.pt || 0))}`;
    box.setAttribute('aria-label', `神樹へ移動。${label}。${itemText}`);
    box.title = `神樹へ / ${label} / ${itemText}`;
    const badge = box.querySelector('.shinju-home-entry-badge');
    if (badge) {
      badge.textContent = '';
      badge.setAttribute('aria-hidden', 'true');
    }
    box.classList.remove('has-items');
    box.classList.toggle('is-clear', s.isMax);
  }

  const SHINJU_AURA_POSITIONS = [
    { x: 19, y: 18, s: .58, d: 0.0 },
    { x: 73, y: 21, s: .50, d: .7 },
    { x: 35, y: 29, s: .42, d: 1.1 },
    { x: 83, y: 36, s: .38, d: .3 },
    { x: 14, y: 39, s: .40, d: 1.5 },
    { x: 58, y: 14, s: .34, d: 1.9 },
    { x: 54, y: 34, s: .30, d: .9 },
  ];

  function renderAuraField(ov, state) {
    const field = ov.querySelector('#shinju-aura-field');
    if (!field) return;

    // build1643: 受け取り待ちは自動変換されるので、通常は0（変換までの一瞬だけ光が漂う）
    const count = Math.min(SHINJU_AURA_POSITIONS.length, Math.max(0, Number(state.pendingItemCount || 0)));
    field.classList.toggle('is-empty', count === 0);

    field.innerHTML = SHINJU_AURA_POSITIONS.slice(0, count).map((pos, index) => `
      <span class="shinju-aura-orb" data-aura-index="${index}"
        style="--aura-x:${pos.x}%;--aura-y:${pos.y}%;--aura-scale:${pos.s};--aura-delay:${pos.d}s">
        <img src="images/shinju_aura.webp" alt="">
      </span>
    `).join('');
  }

  function updateOfferingMeta(ov, state) {
    const count = ov.querySelector('#shinju-pending-count');
    const exp = ov.querySelector('#shinju-pending-exp');
    const btn = ov.querySelector('#shinju-offer-all');
    const totalExp = (state.inventory || []).reduce((sum, item) => sum + Math.max(0, Number(item && item.exp || 0)), 0);

    if (count) count.textContent = totalExp > 0 ? `×${totalExp}` : 'なし';
    if (exp) exp.textContent = '';
    if (btn) {
      btn.disabled = state.pendingItemCount <= 0 || !!ov.dataset.offering;
      btn.textContent = state.pendingItemCount > 0 ? 'すべて奉納' : '奉納する資源なし';
    }
  }

  function animateAuraOffering(ov) {
    const auras = Array.from(ov.querySelectorAll('.shinju-aura-orb'));
    const target = ov.querySelector('.shinju-progress-bg');
    if (!auras.length || !target) return Promise.resolve();

    const targetRect = target.getBoundingClientRect();
    const targetX = targetRect.left + targetRect.width * .5;
    const targetY = targetRect.top + targetRect.height * .5;

    ov.classList.add('is-offering');

    auras.forEach((aura, index) => {
      const rect = aura.getBoundingClientRect();
      const x = targetX - (rect.left + rect.width * .5);
      const y = targetY - (rect.top + rect.height * .5);
      aura.style.setProperty('--offer-x', `${x}px`);
      aura.style.setProperty('--offer-y', `${y}px`);
      aura.style.setProperty('--offer-delay', `${index * 90}ms`);
      void aura.offsetWidth;
      aura.classList.add('is-offering');
    });

    const totalMs = 760 + Math.max(0, auras.length - 1) * 90;
    return new Promise(resolve => setTimeout(resolve, totalMs));
  }

  function getCharacterModule() {
    return window.ShootingCharacters || null;
  }

  function getCharacterInfo(characterId) {
    const module = getCharacterModule();
    const id = normalizeCharacterId(characterId);
    const c = module && module.SHOOTING_CHARACTERS && module.SHOOTING_CHARACTERS[id];
    if (!c) return null;
    return {
      id,
      name: c.name || `CHARACTER ${id}`,
      image: pfPanelImage(c), // build1743: 装備中の衣装
      owned: typeof module.isShootingCharacterOwned === 'function' ? !!module.isShootingCharacterOwned(id) : true,
    };
  }

  function getOwnedBlessingCharacters() {
    const module = getCharacterModule();
    if (!module || !module.SHOOTING_CHARACTERS) return [];
    return Object.values(module.SHOOTING_CHARACTERS)
      .filter(Boolean)
      .filter(c => typeof module.isShootingCharacterOwned !== 'function' || module.isShootingCharacterOwned(c.id))
      .sort((a, b) => Number(a.id || 0) - Number(b.id || 0));
  }

  function blessingRateLabel(slot, rate) {
    const pct = fmtPct(Math.max(0, Number(rate || 0)));
    if (slot === 'hp') return `HP +${pct}`;
    if (slot === 'atk') return `ATK +${pct}`;
    if (slot === 'rate') return `射速 +${pct}`;
    if (slot === 'resist') return `耐性 ${pct}`;
    return `ULT還元 ${pct}`;
  }

  async function setBlessingSlot(slot, characterId) {
    if (!BLESSING_SLOTS.includes(slot)) return { ok:false, reason:'invalid_slot' };
    const id = normalizeCharacterId(characterId);
    const sb = window.zsSupabase;
    if (!sb || typeof sb.rpc !== 'function') return { ok:false, reason:'offline' };

    const ptBefore = Math.max(0, Number(getViewState().pt || 0));
    try {
      const res = await sb.rpc('set_shinju_blessing_secure', {
        p_slot: slot,
        p_character_id: id
      });
      if (res && res.error) throw res.error;
      let data = res ? res.data : null;
      if (typeof data === 'string') {
        try { data = JSON.parse(data); } catch (_) {}
      }
      let view = applyServerPayload(data);
      // 戻り値に状態が無い場合も、サーバーの最新状態（pt残高・5SLOT）を取り直す
      if (!data || typeof data !== 'object' || (data.pt == null && !(data.state && data.state.pt != null))) {
        view = await refreshFromServer();
      }
      renderOverlay();
      renderHomeEntry();

      const spent = Math.max(0, Number(data && data.pt_spent || 0) || (ptBefore - Math.max(0, Number(getViewState().pt || 0))));
      const spentText = spent > 0 ? `（創世pt -${spent}）` : '';
      if (id == null) showTinyToast(`${BLESSING_LABELS[slot]}を解除した${spentText}`);
      else {
        const info = getCharacterInfo(id);
        showTinyToast(`${BLESSING_LABELS[slot]}：${info ? info.name : id}${spentText}`);
      }
      return { ok:true, state:view };
    } catch (err) {
      const message = String(err && err.message || '');
      if (message.includes('another shinju slot')) showTinyToast('このキャラは別スロットに設定済みです');
      else if (message.includes('not owned')) showTinyToast('未所持キャラは設定できません');
      else if (message.includes('not enough shinju pt')) showTinyToast(`創世ptが不足しています（必要：${SLOT_CHANGE_COST}pt）`);
      else if (message.includes('invalid shinju slot')) showTinyToast('このSLOTはまだ利用できません');
      else showTinyToast('加護の設定に失敗しました');
      // 失敗時は表示をサーバーの状態に合わせ直す
      void refreshFromServer().then(() => { renderOverlay(); renderHomeEntry(); }).catch(() => {});
      return { ok:false, reason:'server_rejected', error:err };
    }
  }

  // build1786: 加護SLOTはタブで切り替え（基本＝HP/ATK/ULT、戦術＝射速/耐性）。木を隠さないよう1段分の高さに収める。
  const BLESSING_TABS = Object.freeze({ basic: ['hp', 'atk', 'ult'], tactics: ['rate', 'resist'] });
  const BLESSING_TAB_KEY = 'zeraphia_shinju_blessing_tab';
  let blessingTab = (function () {
    try { const v = localStorage.getItem(BLESSING_TAB_KEY); return BLESSING_TABS[v] ? v : 'basic'; } catch (_) { return 'basic'; }
  })();
  function setBlessingTab(tab) {
    if (!BLESSING_TABS[tab] || tab === blessingTab) return;
    blessingTab = tab;
    try { localStorage.setItem(BLESSING_TAB_KEY, tab); } catch (_) {}
    const ov = document.getElementById('shinju-overlay');
    if (ov) renderBlessingSlots(ov, getViewState());
  }

  function renderBlessingSlots(ov, state) {
    const box = ov.querySelector('#shinju-blessing-slots');
    if (!box) return;
    box.dataset.tab = blessingTab;
    ov.querySelectorAll('[data-blessing-tab]').forEach(btn => {
      const on = btn.dataset.blessingTab === blessingTab;
      btn.classList.toggle('is-active', on);
      btn.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    const rates = state.blessingRates || slotRates(state.slots);
    const slots = normalizeSlots(state.slots);
    const pt = Math.max(0, Number(state.pt || 0));
    box.innerHTML = BLESSING_TABS[blessingTab].map(slot => {
      const id = state.blessings && state.blessings[slot];
      const info = getCharacterInfo(id);
      const assigned = !!info;
      const lv = slots[slot];
      const cost = slotNextCost(lv);
      const isMax = cost == null;
      const canPay = !isMax && pt >= cost;
      // build1610: キャラ配置（円をタップ）と SLOT 強化（下のボタン）を分ける
      return `
        <div class="shinju-blessing-slot ${assigned ? 'is-assigned' : 'is-empty'}" data-blessing-slot="${slot}">
          <span class="shinju-blessing-slot-kind">${BLESSING_LABELS[slot].replace(' SLOT', '<span class="shinju-slot-word"> SLOT</span>')}<i class="shinju-slot-lv">Lv${lv}</i></span>
          <button type="button" class="shinju-blessing-character-panel" aria-label="${BLESSING_LABELS[slot]}のキャラを選ぶ" onclick="ShinjuProgress.openBlessingPicker('${slot}')">
            ${assigned && info.image ? `<img src="${escapeHtml(info.image)}" alt="">` : '<span class="shinju-blessing-plus">＋</span>'}
          </button>
          <button type="button" class="shinju-blessing-slot-effect" aria-label="${BLESSING_LABELS[slot]}の説明" onclick="ShinjuProgress.openBlessingHelp('${slot}')">${blessingRateLabel(slot, rates[slot])}<i class="shinju-effect-info" aria-hidden="true">i</i></button>
          <button type="button" class="shinju-slot-invest ${isMax ? 'is-max' : (canPay ? '' : 'is-short')}" data-invest-slot="${slot}" ${isMax ? 'disabled' : ''}
            onclick="ShinjuProgress.investSlotFromUI('${slot}', this)">${isMax ? 'MAX' : `強化 <b>${cost}</b>pt`}</button>
        </div>`;
    }).join('');
  }

  // build1611: SLOT 強化。確認ポップアップ（〇〇SLOTを LvX⇒LvY に強化します（Npt消費））で「強化する」を押して確定
  function confirmInvest(slot, lv, cost, pt) {
    return new Promise(resolve => {
      let box = document.getElementById('shinju-invest-confirm');
      if (!box) {
        box = document.createElement('div');
        box.id = 'shinju-invest-confirm';
        box.className = 'shinju-invest-confirm';
        document.body.appendChild(box);
      }
      const rate = SLOT_RATE_PER_LEVEL[slot];
      box.innerHTML = `
        <div class="shinju-invest-confirm-card" role="dialog" aria-modal="true" aria-label="SLOT強化の確認">
          <button type="button" class="shinju-modal-x" data-act="no" aria-label="閉じる">×</button>
          <small>SLOT ENHANCE</small>
          <p class="shinju-invest-confirm-main">${BLESSING_LABELS[slot]}を<br><b>Lv${lv}</b> ⇒ <b>Lv${lv + 1}</b> に強化します</p>
          <p class="shinju-invest-confirm-cost">（創世pt <b>${cost}</b> を消費）</p>
          <div class="shinju-invest-confirm-detail">
            <span>${blessingRateLabel(slot, lv * rate)}</span><i>⇒</i><span class="is-up">${blessingRateLabel(slot, (lv + 1) * rate)}</span>
          </div>
          <div class="shinju-invest-confirm-pt">所持 創世pt ${pt} ⇒ ${pt - cost}</div>
          <div class="shinju-invest-confirm-actions">
            <button type="button" class="is-cancel" data-act="no">やめる</button>
            <button type="button" class="is-ok" data-act="yes">強化する</button>
          </div>
        </div>`;
      const done = ok => { box.classList.remove('active'); box.onclick = null; resolve(ok); };
      box.onclick = e => {
        const act = e.target && e.target.closest && e.target.closest('[data-act]');
        if (act) done(act.dataset.act === 'yes');
        else if (e.target === box) done(false);
      };
      box.classList.add('active');
    });
  }
  async function investSlotFromUI(slot, btn) {
    if (!BLESSING_SLOTS.includes(slot) || !btn) return;
    const s = getViewState();
    const lv = normalizeSlots(s.slots)[slot];
    const cost = slotNextCost(lv);
    if (cost == null) return;
    const pt = Number(s.pt || 0);
    if (pt < cost) { showTinyToast(`創世ptが足りません（あと ${cost - pt}pt）`); return; }
    if (!(await confirmInvest(slot, lv, cost, pt))) return;
    btn.disabled = true;
    const sb = window.zsSupabase;
    try {
      if (!sb || typeof sb.rpc !== 'function') throw new Error('offline');
      const res = await sb.rpc('invest_shinju_slot_secure', { p_slot: slot, p_levels: 1 });
      if (res && res.error) throw res.error;
      let data = res ? res.data : null;
      if (typeof data === 'string') { try { data = JSON.parse(data); } catch (_) {} }
      applyServerPayload(data);
      renderOverlay();
      renderHomeEntry();
      const after = getViewState();
      if (Number(data && data.stage_after) > Number(data && data.stage_before)) {
        showTinyToast(`神樹が成長した：${after.stageLabel} ${after.stage} / 5`);
      } else {
        showTinyToast(`${BLESSING_LABELS[slot]} Lv${data && data.slot_level}（創世pt -${data && data.pt_spent}）`);
      }
    } catch (err) {
      const message = String(err && err.message || '');
      if (message.includes('not enough shinju pt')) showTinyToast('創世ptが足りません');
      else if (message.includes('already max')) showTinyToast('このSLOTは最大です');
      else showTinyToast('強化に失敗しました');
      renderOverlay();
    }
  }

  function ensureBlessingPicker() {
    let picker = document.getElementById('shinju-blessing-picker');
    if (picker) return picker;
    picker = document.createElement('div');
    picker.id = 'shinju-blessing-picker';
    picker.className = 'shinju-blessing-picker';
    picker.innerHTML = `
      <div class="shinju-blessing-picker-card" role="dialog" aria-modal="true" aria-label="加護キャラクター選択">
        <div class="shinju-blessing-picker-head">
          <div class="shinju-blessing-picker-heading">
            <small>神聖樹の加護</small>
            <strong id="shinju-blessing-picker-title">SLOT</strong>
          </div>
          <button type="button" class="shinju-blessing-picker-close shinju-modal-x" aria-label="閉じる" onclick="ShinjuProgress.closeBlessingPicker()">×</button>
        </div>
        <div class="shinju-blessing-picker-cost" id="shinju-blessing-picker-cost"></div>
        <div class="zpf-filter-toolbar shinju-picker-toolbar" id="shinju-picker-toolbar">
          <label class="zpf-search" aria-label="キャラ名検索">
            <span class="zpf-search-icon" aria-hidden="true">⌕</span>
            <input type="search" placeholder="キャラ名で検索" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="キャラ名で検索">
            <button type="button" class="zpf-search-clear" aria-label="検索文字を消す" hidden>×</button>
          </label>
          <button type="button" class="zpf-filter-button" aria-label="絞り込みメニュー" aria-pressed="false">☷ 絞り込み</button>
          <span class="zpf-filter-count" aria-live="polite"></span>
        </div>
        <div class="shinju-blessing-picker-grid" id="shinju-blessing-picker-grid"></div>
        <div class="shinju-blessing-picker-confirm" id="shinju-blessing-picker-confirm" hidden>
          <p id="shinju-blessing-picker-confirm-text"></p>
          <div>
            <button type="button" class="is-cancel" id="shinju-blessing-picker-confirm-no">やめる</button>
            <button type="button" class="is-ok" id="shinju-blessing-picker-confirm-yes">変更する</button>
          </div>
        </div>
        <div class="shinju-blessing-picker-foot">
          <button type="button" class="shinju-blessing-picker-clear" id="shinju-blessing-picker-clear">このスロットを解除</button>
        </div>
      </div>`;
    const toolbar = picker.querySelector('#shinju-picker-toolbar');
    if (toolbar) {
      const input = toolbar.querySelector('input');
      input.addEventListener('input', e => { pickerFilter.query = e.target.value; syncPickerToolbar(); });
      toolbar.querySelector('.zpf-search-clear').addEventListener('click', () => {
        pickerFilter.query = ''; syncPickerToolbar(); input.focus();
      });
      toolbar.querySelector('.zpf-filter-button').addEventListener('click', openPickerFilterDialog);
    }
    picker.addEventListener('click', e => {
      if (e.target === picker) closeBlessingPicker();
    });
    document.body.appendChild(picker);
    return picker;
  }

  function openBlessingPicker(slot) {
    if (!BLESSING_SLOTS.includes(slot)) return;
    const picker = ensureBlessingPicker();
    const state = getViewState();
    const title = picker.querySelector('#shinju-blessing-picker-title');
    const grid = picker.querySelector('#shinju-blessing-picker-grid');
    const clear = picker.querySelector('#shinju-blessing-picker-clear');
    if (title) title.textContent = BLESSING_LABELS[slot];
    picker.dataset.slot = slot;
    // build1790: 配置（空き→キャラ）・交換（キャラ→別キャラ）は創世pt 10。同じキャラ・解除は無料。
    const currentId = Number(state.blessings && state.blessings[slot]) || 0;
    const ptNow = Math.max(0, Number(state.pt || 0));
    const canPay = ptNow >= SLOT_CHANGE_COST;
    const costBox = picker.querySelector('#shinju-blessing-picker-cost');
    if (costBox) {
      costBox.className = 'shinju-blessing-picker-cost' + (!canPay ? ' is-short' : '');
      costBox.innerHTML = `キャラの配置・交換：<b>創世pt ${SLOT_CHANGE_COST}</b>（解除は無料）<br>現在の創世pt：<b>${ptNow}</b> pt`
        + (!canPay ? `<br>創世ptが不足しています（必要：${SLOT_CHANGE_COST}pt）` : '');
    }
    const confirmBox = picker.querySelector('#shinju-blessing-picker-confirm');
    const confirmYes = confirmBox && confirmBox.querySelector('#shinju-blessing-picker-confirm-yes');
    if (confirmBox) confirmBox.hidden = true;
    const ask = (text, cost, okLabel, run) => {
      if (cost > 0 && ptNow < cost) { showTinyToast(`創世ptが不足しています（必要：${cost}pt）`); return; }
      if (!confirmBox) { run(); return; }
      const costLine = cost > 0
        ? `創世ptを${cost}pt消費します。<br>現在の創世pt：${ptNow} pt → ${ptNow - cost} pt`
        : '消費pt：0';
      confirmBox.querySelector('#shinju-blessing-picker-confirm-text').innerHTML = `${text}<br><small>${costLine}</small>`;
      if (confirmYes) confirmYes.textContent = okLabel;
      confirmBox.hidden = false;
      try { confirmBox.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (_) {}
      confirmBox.querySelector('#shinju-blessing-picker-confirm-no').onclick = () => { confirmBox.hidden = true; };
      confirmBox.querySelector('#shinju-blessing-picker-confirm-yes').onclick = () => { confirmBox.hidden = true; run(); };
    };

    const assignedElsewhere = new Map();
    BLESSING_SLOTS.forEach(other => {
      if (other === slot) return;
      const id = Number(state.blessings && state.blessings[other]);
      if (id > 0) assignedElsewhere.set(id, other);
    });

    const chars = getOwnedBlessingCharacters();
    if (grid) {
      grid.innerHTML = chars.length ? chars.map(c => {
        const id = Number(c.id);
        const selected = Number(state.blessings && state.blessings[slot]) === id;
        const otherSlot = assignedElsewhere.get(id);
        const disabled = !!otherSlot;
        const img = pfPanelImage(c); // build1743: 装備中の衣装
        const el = pfElem(c.element);
        const lv = pfLevel(id);
        return `
          <button type="button" class="shinju-blessing-picker-character ${selected ? 'is-selected' : ''} ${disabled ? 'is-used' : ''}"
                  data-character-id="${id}" ${disabled ? 'disabled' : ''}>
            <span class="shinju-blessing-picker-portrait">${img ? `<img src="${escapeHtml(img)}" alt="" loading="lazy">` : ''}
              <img class="shinju-picker-element" src="images/type_${el}.webp" alt="" aria-hidden="true" draggable="false" onerror="this.style.visibility='hidden'">
              ${lv > 0 ? `<i class="shinju-picker-level">Lv.${lv}</i>` : ''}</span>
            <span class="shinju-blessing-picker-meta">
              <b>${escapeHtml(c.name || `CHARACTER ${id}`)}</b>
              ${selected ? '<em class="shinju-picker-placed">配置中</em>' : (disabled ? `<em class="shinju-picker-placed is-other">${escapeHtml(String(BLESSING_LABELS[otherSlot] || '').replace(' SLOT', ''))}に配置中</em>` : '')}
            </span>
          </button>`;
      }).join('') : '<div class="shinju-blessing-picker-empty">所持キャラクターがありません</div>';

      grid.querySelectorAll('.shinju-blessing-picker-character:not(:disabled)').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = Number(btn.dataset.characterId);
          if (id === currentId) { closeBlessingPicker(); return; } // 同じキャラの再選択はpt消費なし
          const name = (btn.querySelector('b') && btn.querySelector('b').textContent) || '';
          const text = currentId > 0
            ? `${BLESSING_LABELS[slot]}を「${escapeHtml(name)}」に交換しますか？`
            : `「${escapeHtml(name)}」を${BLESSING_LABELS[slot]}に配置しますか？`;
          ask(text, SLOT_CHANGE_COST, currentId > 0 ? '交換する' : '配置する', async () => {
            btn.disabled = true;
            const result = await setBlessingSlot(slot, id);
            if (result && result.ok) closeBlessingPicker();
            else btn.disabled = false;
          });
        });
      });
    }
    if (clear) {
      clear.disabled = !(state.blessings && state.blessings[slot]);
      clear.onclick = () => {
        ask('このキャラクターの加護を解除しますか？', 0, '解除する', async () => {
          clear.disabled = true;
          const result = await setBlessingSlot(slot, null);
          if (result && result.ok) closeBlessingPicker();
          else clear.disabled = false;
        });
      };
    }
    resetPickerFilter();
    picker.classList.add('active');
  }

  // ============================================================
  // build1736: 加護キャラ選択の検索・絞り込み・並び順
  //  パーティ編成（shooting_party_filter.js）と同じ見た目・同じ選択肢。表示だけの処理で、
  //  加護の設定・コスト・使用中判定には触らない。ボタンは並べ替え（移動）するだけで作り直さない。
  // ============================================================
  const pickerFilter = { query:'', elements:[], rarities:[], shotTypes:[], pierce:'all', sort:'id' }; // build1741: pierce='all'|'yes'|'no'
  function pfPierces(id) { const m = getCharacterModule(); return !!(m && typeof m.isShootingCharacterPiercing === 'function' && m.isShootingCharacterPiercing(id)); }
  const PF_ELEMENTS = ['fire','aqua','wood','light','dark'];
  const PF_ELEMENT_LABELS = { fire:'FIRE', aqua:'AQUA', wood:'WOOD', light:'LIGHT', dark:'DARK' };
  const PF_SHOTS = ['parallel','homing','cluster','bomb','spread','laser','piercing','orbit','charge','lightning','strike','conjure','trap'];
  const PF_SHOT_LABELS = { parallel:'PARALLEL', homing:'HOMING', cluster:'CLUSTER', bomb:'BOMB', spread:'SPREAD', laser:'LASER', piercing:'PIERCING', orbit:'ORBIT', charge:'CHARGE', lightning:'PLASMA', strike:'STRIKE', conjure:'SUMMON', trap:'TRAP' };
  const PF_SHOT_ALIASES = { plasma:'lightning', orbit_forward:'orbit', charge_release:'charge', precision:'piercing', shotgun:'piercing', splash:'bomb', melee_slash:'strike', wolf_j_homing:'homing', rose_seed_splash:'spread', noah_hybrid:'laser' };
  function pfNormalize(v) {
    let t = String(v == null ? '' : v);
    try { t = t.normalize('NFKC'); } catch (_) {}
    return t.toLowerCase().replace(/[\s　]+/g, '').replace(/[\u30a1-\u30f6]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0x60));
  }
  function pfElem(v) { const k = String((Array.isArray(v) ? v[0] : v) || 'neutral').toLowerCase(); return PF_ELEMENTS.includes(k) ? k : 'neutral'; }
  function pfRarity(v) { return String(v || 'r').toLowerCase() === 'sr' ? 'sr' : 'r'; }
  function pfShot(v) { const k = String(v || '').toLowerCase(); return PF_SHOT_ALIASES[k] || k; }
  function pfPanelImage(c) {
    const m = getCharacterModule();
    if (m && typeof m.getShootingSkinPanelImage === 'function') return m.getShootingSkinPanelImage(c);
    return String((c && (c.panelImage || c.image)) || '');
  }
  function pfChar(id) { const m = getCharacterModule(); return (m && m.SHOOTING_CHARACTERS && m.SHOOTING_CHARACTERS[id]) || {}; }
  function pfLevel(id) {
    const m = getCharacterModule();
    const d = m && typeof m.getOwnedShootingInstance === 'function' ? m.getOwnedShootingInstance(id) : null;
    return Math.max(0, Number(d && (d.characterLevel ?? d.character_level)) || 0);
  }
  function pfRank(id) { const m = getCharacterModule(); return (m && typeof m.getShootingBaseOrderRank === 'function') ? m.getShootingBaseOrderRank(id) : id; }
  function pfActive() { return !!(pickerFilter.query.trim() || pickerFilter.elements.length || pickerFilter.rarities.length || pickerFilter.shotTypes.length || pickerFilter.pierce !== 'all' || pickerFilter.sort !== 'id'); }

  function applyPickerFilter() {
    const grid = document.getElementById('shinju-blessing-picker-grid');
    const toolbar = document.getElementById('shinju-picker-toolbar');
    if (!grid || !toolbar) return;
    const q = pfNormalize(pickerFilter.query);
    const entries = [];
    let visible = 0;
    grid.querySelectorAll('.shinju-blessing-picker-character').forEach(btn => {
      const id = Number(btn.dataset.characterId), c = pfChar(id);
      const ok = (!q || pfNormalize(c.name || '').includes(q)) &&
        (!pickerFilter.elements.length || pickerFilter.elements.includes(pfElem(c.element))) &&
        (!pickerFilter.rarities.length || pickerFilter.rarities.includes(pfRarity(c.rarity))) &&
        (!pickerFilter.shotTypes.length || pickerFilter.shotTypes.includes(pfShot(c.shotType || (c.mainShot && c.mainShot.type)))) &&
        (pickerFilter.pierce === 'all' || (pickerFilter.pierce === 'yes') === pfPierces(id));
      btn.classList.toggle('zpf-filtered-out', !ok);
      btn.setAttribute('aria-hidden', ok ? 'false' : 'true');
      if (ok) visible++;
      entries.push({ btn, id, c });
    });
    entries.sort((a, b) => {
      if (pickerFilter.sort === 'level') {
        const d = pfLevel(b.id) - pfLevel(a.id); if (d) return d;
      } else if (pickerFilter.sort === 'element') {
        const d = PF_ELEMENTS.indexOf(pfElem(a.c.element)) - PF_ELEMENTS.indexOf(pfElem(b.c.element)); if (d) return d;
        const r = (pfRarity(a.c.rarity) === 'sr' ? 0 : 1) - (pfRarity(b.c.rarity) === 'sr' ? 0 : 1); if (r) return r;
      } else if (pickerFilter.sort === 'rarity') {
        const d = (pfRarity(a.c.rarity) === 'sr' ? 0 : 1) - (pfRarity(b.c.rarity) === 'sr' ? 0 : 1); if (d) return d;
        const e = PF_ELEMENTS.indexOf(pfElem(a.c.element)) - PF_ELEMENTS.indexOf(pfElem(b.c.element)); if (e) return e;
      }
      return (pfRank(a.id) - pfRank(b.id)) || (a.id - b.id);
    });
    entries.forEach(({ btn }) => grid.appendChild(btn));
    let empty = grid.querySelector('.zpf-filter-empty');
    if (entries.length) {
      if (!empty) { empty = document.createElement('p'); empty.className = 'zpf-filter-empty'; empty.textContent = '条件に一致するキャラクターはいません'; }
      grid.appendChild(empty);
      empty.hidden = visible > 0;
    }
    const count = toolbar.querySelector('.zpf-filter-count'); if (count) count.textContent = visible + '人';
    const fb = toolbar.querySelector('.zpf-filter-button');
    if (fb) { fb.classList.toggle('is-filtered', pfActive()); fb.setAttribute('aria-pressed', pfActive() ? 'true' : 'false'); }
  }
  function syncPickerToolbar() {
    const toolbar = document.getElementById('shinju-picker-toolbar'); if (!toolbar) return;
    const input = toolbar.querySelector('input'); if (input && input.value !== pickerFilter.query) input.value = pickerFilter.query;
    const clear = toolbar.querySelector('.zpf-search-clear'); if (clear) clear.hidden = !pickerFilter.query;
    applyPickerFilter();
  }
  function resetPickerFilter() {
    closePickerFilterDialog();
    pickerFilter.query = ''; pickerFilter.elements = []; pickerFilter.rarities = []; pickerFilter.shotTypes = []; pickerFilter.pierce = 'all'; pickerFilter.sort = 'id';
    syncPickerToolbar();
  }
  function pfChip(group, key, label, img) {
    const selected = key === 'all' ? !pickerFilter[group].length : pickerFilter[group].includes(key);
    const iconClass = group === 'elements' ? 'zcf-attribute-icon' : 'zcf-shot-icon';
    const size = group === 'elements' ? 22 : 24;
    const icon = img ? `<img class="${iconClass}" src="${escapeHtml(img)}" width="${size}" height="${size}" alt="" decoding="async" draggable="false" onerror="this.style.visibility='hidden'">` : '';
    return `<button type="button" class="zcf-choice${selected ? ' is-selected' : ''}" aria-pressed="${selected}" data-group="${group}" data-key="${key}">${icon}<span class="zcf-choice-label">${escapeHtml(label)}</span></button>`;
  }
  function openPickerFilterDialog() {
    closePickerFilterDialog();
    const layer = document.createElement('div');
    layer.id = 'shinju-filter-layer';
    layer.className = 'zcf-overlay';
    const attrTop = ['all','fire','aqua','wood'].map(k => pfChip('elements', k, k === 'all' ? 'すべて' : PF_ELEMENT_LABELS[k], k === 'all' ? '' : 'images/type_' + k + '.webp')).join('');
    const attrBottom = ['light','dark'].map(k => pfChip('elements', k, PF_ELEMENT_LABELS[k], 'images/type_' + k + '.webp')).join('');
    const rarities = ['all','sr','r'].map(k => pfChip('rarities', k, k === 'all' ? 'すべて' : k.toUpperCase())).join('');
    const shots = ['all', ...PF_SHOTS].map(k => pfChip('shotTypes', k, k === 'all' ? 'すべて' : PF_SHOT_LABELS[k], k === 'all' ? '' : 'images/shot_' + (k === 'lightning' ? 'plasma' : k) + '.webp')).join('');
    const pierceChips = ['all','yes','no'].map(k => `<button type="button" class="zcf-choice${pickerFilter.pierce === k ? ' is-selected' : ''}" data-pierce="${k}" aria-pressed="${pickerFilter.pierce === k}"><span class="zcf-choice-label">${{ all:'すべて', yes:'貫通あり', no:'貫通なし' }[k]}</span></button>`).join('');
    const sorts = ['id','element','rarity','level'].map(k => {
      const label = { id:'ID', element:'属性', rarity:'レアリティ', level:'レベル' }[k];
      return `<button type="button" class="zcf-choice${pickerFilter.sort === k ? ' is-selected' : ''}" data-sort="${k}" aria-pressed="${pickerFilter.sort === k}"><span class="zcf-choice-label">${label}</span></button>`;
    }).join('');
    layer.innerHTML = `<section class="zcf-dialog" role="dialog" aria-modal="true" aria-label="加護キャラクターの絞り込み">
      <header class="zcf-header"><h2 class="zcf-title">絞り込み</h2><span class="zcf-heading-rule" aria-hidden="true">✦</span>
      <button type="button" class="zcf-close" data-close aria-label="閉じる"><img src="images/button_close.webp" alt=""></button></header>
      <div class="zcf-scroll">
        <section class="zcf-section"><h3 class="zcf-section-title">属性</h3><div class="zcf-grid zcf-grid-attr-top">${attrTop}</div><div class="zcf-grid zcf-grid-attr-bottom">${attrBottom}</div></section>
        <section class="zcf-section"><h3 class="zcf-section-title">レアリティ</h3><div class="zcf-grid zcf-grid-rarity">${rarities}</div></section>
        <section class="zcf-section"><h3 class="zcf-section-title">ショットタイプ</h3><div class="zcf-grid zcf-grid-shots">${shots}</div></section>
        <section class="zcf-section"><h3 class="zcf-section-title">貫通</h3><div class="zcf-grid zcf-grid-pierce">${pierceChips}</div></section>
        <section class="zcf-section"><h3 class="zcf-section-title">並び順</h3><div class="zcf-grid zcf-grid-sort">${sorts}</div></section>
      </div><footer class="zcf-footer"><button type="button" class="zcf-footer-button zcf-reset" data-reset>リセット</button><button type="button" class="zcf-footer-button zcf-apply" data-close>決定</button></footer>
    </section>`;
    layer.addEventListener('click', event => {
      const target = event.target.closest('button');
      if (event.target === layer || (target && target.hasAttribute('data-close'))) { closePickerFilterDialog(); return; }
      if (!target) return;
      if (target.hasAttribute('data-reset')) {
        pickerFilter.elements = []; pickerFilter.rarities = []; pickerFilter.shotTypes = []; pickerFilter.pierce = 'all'; pickerFilter.sort = 'id'; pickerFilter.query = '';
        syncPickerToolbar(); openPickerFilterDialog(); return;
      }
      const group = target.dataset.group, key = target.dataset.key;
      if (group && Object.prototype.hasOwnProperty.call(pickerFilter, group)) {
        const values = pickerFilter[group];
        if (key === 'all') pickerFilter[group] = [];
        else if (values.includes(key)) pickerFilter[group] = values.filter(v => v !== key);
        else pickerFilter[group] = values.concat(key);
      } else if (target.dataset.sort) pickerFilter.sort = target.dataset.sort;
      else if (target.dataset.pierce) { const v = target.dataset.pierce; pickerFilter.pierce = (v !== 'all' && pickerFilter.pierce === v) ? 'all' : v; }
      else return;
      layer.querySelectorAll('[data-group]').forEach(b => {
        const on = b.dataset.key === 'all' ? !pickerFilter[b.dataset.group].length : pickerFilter[b.dataset.group].includes(b.dataset.key);
        b.classList.toggle('is-selected', on); b.setAttribute('aria-pressed', String(on));
      });
      layer.querySelectorAll('[data-sort]').forEach(b => { const on = b.dataset.sort === pickerFilter.sort; b.classList.toggle('is-selected', on); b.setAttribute('aria-pressed', String(on)); });
      layer.querySelectorAll('[data-pierce]').forEach(b => { const on = b.dataset.pierce === pickerFilter.pierce; b.classList.toggle('is-selected', on); b.setAttribute('aria-pressed', String(on)); });
      syncPickerToolbar();
    });
    document.body.appendChild(layer);
    const close = layer.querySelector('.zcf-close'); if (close) close.focus({ preventScroll: true });
  }
  function closePickerFilterDialog() { const l = document.getElementById('shinju-filter-layer'); if (l) l.remove(); }
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && document.getElementById('shinju-filter-layer')) { e.stopPropagation(); closePickerFilterDialog(); }
  }, true);

  // build1608: 加護の段階一覧（？ボタン）。次の段階を目指したくなるよう、全段階の恩恵と必要ptを並べる。
  // build1787: 各SLOTの詳しい説明。SLOTの効果表示をタップすると、そのSLOTの説明へ飛ぶ。
  const SLOT_DETAILS = Object.freeze({
    hp: { tab: '基本', name: 'HP', body: 'SLOTに置いたキャラの最大HPが上がります。レベルや共鳴を反映した最終的なHPに加算されます。' },
    atk: { tab: '基本', name: 'ATK', body: 'SLOTに置いたキャラの攻撃力が上がります。レベルや共鳴を反映した最終的なATKに加算されます。ショットとULTの両方のダメージが上がります。' },
    ult: { tab: '基本', name: 'ULT還元', body: 'SLOTに置いたキャラがULTを撃った直後、ULTゲージの一部が戻ります。次のULTまでの時間が短くなります。' },
    rate: { tab: '戦術', name: '射速', body: 'SLOTに置いたキャラの通常ショットの発射間隔が短くなり、発射数が増えます。レーザーは1HITごとの間隔が短くなります。ULTには影響しません。' },
    resist: { tab: '戦術', name: '耐性', body: 'SLOTに置いたキャラが状態異常（吸収・燃焼・出血）で受ける継続ダメージを軽減します。敵の弾や攻撃そのもののダメージは軽減しません。' },
  });
  function setAcc(el, open) {
    if (!el) return;
    el.classList.toggle('is-open', !!open);
    const btn = el.querySelector(':scope > .shinju-acc-toggle');
    if (btn) btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  function slotMaxLabel(slot) {
    const max = SLOT_MAX_LEVEL * SLOT_RATE_PER_LEVEL[slot];
    const per = SLOT_RATE_PER_LEVEL[slot];
    if (slot === 'resist') return `1Lvごとに${fmtPct(per)}カット ／ Lv${SLOT_MAX_LEVEL}で<b>${fmtPct(max)}カット</b>`;
    if (slot === 'rate') return `1Lvごとに+${fmtPct(per)} ／ Lv${SLOT_MAX_LEVEL}で<b>+${fmtPct(max)}</b>（発射数 約${(1 + max).toFixed(2)}倍）`;
    if (slot === 'ult') return `1Lvごとに${fmtPct(per)} ／ Lv${SLOT_MAX_LEVEL}で<b>ゲージの${fmtPct(max)}が戻る</b>`;
    return `1Lvごとに+${fmtPct(per)} ／ Lv${SLOT_MAX_LEVEL}で<b>+${fmtPct(max)}</b>`;
  }

  function openBlessingHelp(focusSlot) {
    if (typeof focusSlot !== 'string' || !SLOT_DETAILS[focusSlot]) focusSlot = '';
    let help = document.getElementById('shinju-blessing-help');
    if (!help) {
      help = document.createElement('div');
      help.id = 'shinju-blessing-help';
      help.className = 'shinju-blessing-help';
      help.addEventListener('click', e => { if (e.target === help) closeBlessingHelp(); });
      document.body.appendChild(help);
    }
    const s = getViewState();
    const slots = normalizeSlots(s.slots);
    const slotRows = SLOT_COSTS.map((cost, i) => {
      const lv = i + 1;
      const mark = k => slots[k] >= lv ? ' is-done' : (slots[k] + 1 === lv ? ' is-next' : '');
      return `<tr><th>Lv${lv}</th><td>${cost}pt</td>
        <td class="${mark('hp')}">+${fmtPct(lv * SLOT_RATE_PER_LEVEL.hp)}</td>
        <td class="${mark('atk')}">+${fmtPct(lv * SLOT_RATE_PER_LEVEL.atk)}</td>
        <td class="${mark('ult')}">${fmtPct(lv * SLOT_RATE_PER_LEVEL.ult)}</td>
        <td class="${mark('rate')}">+${fmtPct(lv * SLOT_RATE_PER_LEVEL.rate)}</td>
        <td class="${mark('resist')}">${fmtPct(lv * SLOT_RATE_PER_LEVEL.resist)}</td></tr>`;
    }).join('');
    const helpSec = (key, title, sub) => `<section class="shinju-help-sec shinju-acc" data-help-sec="${key}"><button type="button" class="shinju-help-sub shinju-acc-toggle" aria-expanded="false"><span class="shinju-help-sec-title">${title}<small>${sub}</small></span><i class="shinju-acc-mark" aria-hidden="true"></i></button><div class="shinju-acc-body"><div class="shinju-acc-inner">`;
    const helpSecEnd = `</div></div></section>`;
    const slotDetailRows = BLESSING_SLOTS.map(slot => {
      const d = SLOT_DETAILS[slot];
      const info = getCharacterInfo(s.blessings && s.blessings[slot]);
      const now = `現在 Lv${slots[slot]}：${blessingRateLabel(slot, slots[slot] * SLOT_RATE_PER_LEVEL[slot])}${info ? `（${escapeHtml(info.name)}）` : '（未設定）'}`;
      return `<li data-help-slot="${slot}" class="shinju-acc"><button type="button" class="shinju-help-slot-head shinju-acc-toggle" aria-expanded="false"><em>${d.tab}</em><b>${escapeHtml(BLESSING_LABELS[slot].replace(' SLOT', ''))}</b>${d.name !== BLESSING_LABELS[slot].replace(' SLOT', '') ? `<span>${d.name}</span>` : ''}<i class="shinju-acc-mark" aria-hidden="true"></i></button>
        <div class="shinju-acc-body"><div class="shinju-acc-inner"><p>${d.body}</p><p class="shinju-help-slot-max">${slotMaxLabel(slot)}</p><p class="shinju-help-slot-now">${now}</p></div></div></li>`;
    }).join('');
    const treeRows = STAGE_LABELS.map((label, i) => {
      const stage = i + 1;
      const need = STAGE_EXP[i] || 0;
      const st = stage < s.stage ? 'is-done' : (stage === s.stage ? 'is-current' : (stage === s.stage + 1 ? 'is-next' : 'is-locked'));
      const tag = st === 'is-current' ? '<em>現在</em>' : (st === 'is-next' ? `<em>あと ${Math.max(0, need - s.exp)}pt</em>` : (st === 'is-done' ? '<em>到達済</em>' : ''));
      return `<li class="${st}"><div class="shinju-help-stage"><b>Lv${stage}</b><span>${escapeHtml(label)}</span>${tag}</div>
        <div class="shinju-help-need">${stage === 1 ? 'はじまり' : `神樹EXP ${need}`}</div></li>`;
    }).join('');
    help.innerHTML = `
      <div class="shinju-blessing-help-card" role="dialog" aria-modal="true" aria-label="神聖樹の加護">
        <button type="button" class="shinju-modal-x" aria-label="閉じる" onclick="ShinjuProgress.closeBlessingHelp()">×</button>
        <div class="shinju-blessing-help-head">
          <small>BLESSING OF THE SACRED TREE</small>
          <strong>神聖樹の加護</strong>
        </div>
        <p class="shinju-blessing-help-lead">創世ptをSLOTに注ぐと加護が強まり、注いだ分だけ神樹が育ちます。</p>
        ${helpSec('table', 'SLOT強化', 'Lvごとの必要ptと効果')}
        <div class="shinju-help-table-wrap"><table class="shinju-help-table">
          <thead><tr><th></th><th>必要</th><th>HP<small>Lv${slots.hp}</small></th><th>ATK<small>Lv${slots.atk}</small></th><th>ULT還元<small>Lv${slots.ult}</small></th><th>射速<small>Lv${slots.rate}</small></th><th>耐性<small>Lv${slots.resist}</small></th></tr></thead>
          <tbody>${slotRows}</tbody>
        </table></div>
        ${helpSecEnd}
        ${helpSec('slots', 'SLOTの効果', '5つのSLOTの詳しい説明')}
        <ul class="shinju-help-slot-list">${slotDetailRows}</ul>
        ${helpSecEnd}
        ${helpSec('tree', '神樹の成長', '萌芽から神樹までの段階')}
        <ol class="shinju-blessing-help-list">${treeRows}</ol>
        ${helpSecEnd}
        <ul class="shinju-blessing-help-notes">
          <li>聖樹の息吹は手に入れると自動で創世ptになります</li>
          <li>1人のキャラは1つのSLOTにだけ置けます</li>
          <li>キャラの配置・交換には創世pt ${SLOT_CHANGE_COST} を消費します（同じキャラの再選択・解除は無料）</li>
          <li>基本SLOT（HP / ATK / ULT）に注いだ創世ptだけが神樹の成長に数えられます</li>
        </ul>
      </div>`;
    help.classList.add('active');
    // build1788: 各項目はたたんだ状態で開く。見出しをタップすると展開。
    help.querySelectorAll('.shinju-acc-toggle').forEach(btn => {
      btn.addEventListener('click', () => setAcc(btn.closest('.shinju-acc'), !btn.closest('.shinju-acc').classList.contains('is-open')));
    });
    if (focusSlot) {
      const row = help.querySelector(`[data-help-slot="${focusSlot}"]`);
      if (row) {
        setAcc(help.querySelector('[data-help-sec="slots"]'), true);
        setAcc(row, true);
        row.classList.add('is-focus');
        setTimeout(() => { try { row.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (_) {} }, 260);
      }
    }
  }
  function closeBlessingHelp() {
    const help = document.getElementById('shinju-blessing-help');
    if (help) help.classList.remove('active');
  }

  function closeBlessingPicker() {
    closePickerFilterDialog();
    const picker = document.getElementById('shinju-blessing-picker');
    if (picker) picker.classList.remove('active');
  }

  function renderOverlay() {
    const ov = ensureOverlay();
    const s = getViewState();
    const img = ov.querySelector('#shinju-visual');
    const stage = ov.querySelector('#shinju-stage');
    const expLabel = ov.querySelector('#shinju-exp-label');
    const expPercent = ov.querySelector('#shinju-exp-percent');
    const fill = ov.querySelector('#shinju-progress-fill');
    const lore = ov.querySelector('#shinju-lore');

    if (img) {
      img.dataset.stage = String(s.stage);
      img.src = s.imageSrc;
      img.onerror = function () {
        this.onerror = null;
        this.src = 'images/shinju_05.webp?v=1609';
      };
    }
    if (stage) stage.innerHTML = `${escapeHtml(s.stageLabel)}<i class="shinju-stage-sep" aria-hidden="true">◆</i>${s.stage} / ${s.maxStage}`;
    if (expLabel) expLabel.textContent = s.isMax ? `神樹EXP ${s.exp} / ${s.totalRequiredExp}` : `神樹EXP ${s.exp} / ${s.nextStageExp}`;
    const ptEl = ov.querySelector('#shinju-pt-balance');
    if (ptEl) ptEl.textContent = String(s.pt || 0);
    if (expPercent) expPercent.textContent = s.isMax ? 'MAX' : `${Math.round(s.progress)}%`;
    if (fill) fill.style.width = `${s.progress}%`;
    if (lore) {
      lore.textContent = s.isMax
        ? '神樹は成長臨界点に到達した。'
        : '創世ptをSLOTに注ぐと、神樹が育つ。';
    }

    renderBlessingSlots(ov, s);
    renderAuraField(ov, s);
    updateOfferingMeta(ov, s);
  }

  function openShinjuScreen() {
    if (typeof window.requireChapter03ContentUnlock === 'function' && !window.requireChapter03ContentUnlock()) return false;
    renderOverlay();
    const ov = ensureOverlay();
    ov.classList.add('active');
    if (typeof window.setNavVisible === 'function') window.setNavVisible(false);

    // Show cached UI immediately, then replace it with the authoritative server snapshot.
    void refreshFromServer().then(() => {
      if (ov.classList.contains('active')) renderOverlay();
      renderHomeEntry();
    });
  }

  function closeShinjuScreen() {
    closeBlessingPicker();
    const ov = document.getElementById('shinju-overlay');
    if (ov) ov.classList.remove('active');
    if (typeof window.setNavVisible === 'function') window.setNavVisible(true);
    renderHomeEntry();
  }

  function showOfferFeedback(result) {
    if (!result || !result.ok) return;
    renderOverlay();
    renderHomeEntry();

    if (result.reachedMax) {
      setTimeout(showGameClearOverlay, 260);
      return;
    }
    if (result.levelUp) {
      showTinyToast(`神樹が成長した：${result.after.stage} / 5`);
      return;
    }
    showTinyToast(result.totalExp ? `聖樹の息吹を奉納した　創世pt +${result.totalExp}` : `${result.item.name}を奉納した`);
  }

  function showTinyToast(text) {
    const old = document.getElementById('shinju-toast');
    if (old) old.remove();
    const el = document.createElement('div');
    el.id = 'shinju-toast';
    el.textContent = text;
    document.body.appendChild(el);
    setTimeout(() => el.classList.add('show'), 20);
    setTimeout(() => {
      el.classList.remove('show');
      setTimeout(() => el.remove(), 280);
    }, 1500);
  }

  function showGameClearOverlay() {
    const old = document.getElementById('shinju-clear-overlay');
    if (old) old.remove();
    const ov = document.createElement('div');
    ov.id = 'shinju-clear-overlay';
    ov.innerHTML = `
      <div class="shinju-clear-card">
        <div class="shinju-clear-kicker">GENESIS COMPLETE</div>
        <div class="shinju-clear-title">創世完了</div>
        <div class="shinju-clear-body">神樹は成長の果てに開花し、ゼラフィアは新世界の核へ到達した。</div>
        <button class="shinju-clear-btn" type="button">閉じる</button>
      </div>
    `;
    ov.querySelector('.shinju-clear-btn').addEventListener('click', function () {
      setGameClearSeen(true);
      ov.remove();
      renderOverlay();
      renderHomeEntry();
    });
    document.body.appendChild(ov);
  }

  function offerFromUI(itemId) {
    const result = offerItem(itemId);
    showOfferFeedback(result);
    return result;
  }

  // build1643: 奉納ボタンは廃止。互換のため残し、受け取り待ちの自動変換を即時実行するだけ。
  async function offerAllFromUI() {
    await refreshFromServer();
    const after = await autoConvertPending();
    return after ? { ok:true, state:after } : { ok:false, reason:'empty', state:getViewState(readState()) };
  }

  function resetForDebug() {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(CLOUD_STORAGE_KEY);
    renderHomeEntry();
    renderOverlay();
  }

  window.openShinjuScreen = openShinjuScreen;
  window.closeShinjuScreen = closeShinjuScreen;
  window.ShinjuProgress = {
    getState: () => getViewState(),
    setBlessingTab,
    refreshFromServer,
    getBlessingForCharacter,
    applyBlessingToProfile,
    setBlessingSlot,
    openBlessingPicker,
    closeBlessingPicker,
    openBlessingHelp,
    investSlotFromUI,
    closeBlessingHelp,
    grantBossItem,
    grantBossItemFromRoguelite,
    offerItem,
    offerAllItems,
    offerFromUI,
    offerAllFromUI,
    renderHomeEntry,
    open: openShinjuScreen,
    close: closeShinjuScreen,
    resetForDebug,
  };

  document.addEventListener('DOMContentLoaded', function () {
    renderHomeEntry();
    void refreshFromServer();
  });
  window.addEventListener(EVENT_NAME, renderHomeEntry);
  window.addEventListener('pageshow', function () { void refreshFromServer(); });
  window.addEventListener('zeraphia:shinju-cloud-loaded', function (event) {
    try {
      authoritativeState = normalizeState(event && event.detail || {});
      shinjuServerReady = true;
      writeStateLocal(authoritativeState);
      renderHomeEntry();
      const ov = document.getElementById('shinju-overlay');
      if (ov && ov.classList.contains('active')) renderOverlay();
      scheduleAutoConvert(); // build1643: 受け取り待ちがあれば自動で創世ptへ
    } catch (err) {
      console.warn('[ShinjuProgress] cloud apply failed:', err);
    }
  });
})();
