// noah_piece.js
(function(){
  'use strict';

  const PIECE_KEY = 'sasaphia_noah_piece_count_v1'; // 表示キャッシュのみ
  const MAX_PIECES = 9;
  const STAGE_ID = 'shooting_event_bullet_hell_test';

  let serverPieceCount = null;
  let serverLap = 1;
  let lastRewardMessage = "";
  let finishPending = false;

  function clampPieceCount(value){
    const n = Math.floor(Number(value || 0));
    return Math.max(0, Math.min(MAX_PIECES, Number.isFinite(n) ? n : 0));
  }

  function getCachedPieceCount(){
    try { return clampPieceCount(localStorage.getItem(PIECE_KEY)); }
    catch (_) { return 0; }
  }

  function getNoahPieceCount(){
    return serverPieceCount == null ? getCachedPieceCount() : clampPieceCount(serverPieceCount);
  }

  function setDisplayPieceCount(value){
    const count = clampPieceCount(value);
    serverPieceCount = count;
    try { localStorage.setItem(PIECE_KEY, String(count)); } catch (_) {}
    renderNoahPiecePanel();
    return count;
  }

  async function refreshNoahProgress(){
    const sb = window.zsSupabase;
    if (!sb || typeof sb.rpc !== 'function') return getNoahPieceCount();

    try {
      const res = await sb.rpc('get_noah_progress_secure');
      if (res && res.error) throw res.error;
      let data = res ? res.data : null;
      if (typeof data === 'string') {
        try { data = JSON.parse(data); } catch (_) {}
      }
      if (!data || data.ok !== true || !Number.isInteger(Number(data.lap)) || Number(data.lap) < 1) throw new Error('invalid Noah progress');
      serverLap = Number(data.lap);
      window.__noahLap = serverLap;
      const stageLapLabel = document.getElementById('noah-stage-lap-label');
      if (stageLapLabel) {
        const grades = ['通常', '困難', '激戦', '極限・反射弾2', '最高難易度・反射弾3'];
        stageLapLabel.textContent = serverLap + '周目 ・ ' + grades[Math.min(serverLap, 5) - 1];
      }
      setDisplayPieceCount(data.piece_count);
    } catch (err) {
      console.warn('[NoahPiece] progress load failed:', err);
    }
    return getNoahPieceCount();
  }

  function getSpecialTicketCount(){
    const profileValue = Number(window.userProfile && window.userProfile.special_stage_ticket);
    if (Number.isFinite(profileValue)) return Math.max(0, Math.floor(profileValue));

    const el = document.getElementById('special-ticket-count');
    const domValue = Number(el && el.textContent);
    return Number.isFinite(domValue) ? Math.max(0, Math.floor(domValue)) : 0;
  }

  function buildPanel(){
    if (document.getElementById('noah-piece-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'noah-piece-overlay';
    overlay.className = 'noah-piece-overlay';
    overlay.setAttribute('aria-hidden','true');

    const pieceHtml = Array.from({length:9}, (_, i) => {
      const col = i % 3;
      const row = Math.floor(i / 3);
      const x = col * 50;
      const y = row * 50;
      return '<div class="noah-puzzle-piece locked" data-noah-piece="' + (i + 1) + '" ' +
        'style="background-position:' + x + '% ' + y + '%"></div>';
    }).join('');

    overlay.innerHTML =
      '<section class="noah-piece-screen" role="dialog" aria-modal="true" aria-labelledby="noah-piece-title">' +
        '<header class="noah-piece-head">' +
          '<button type="button" class="noah-piece-back" onclick="closeNoahPiecePanel()">‹ 戻る</button>' +
          '<div class="noah-piece-title">' +
            '<small>SPECIAL STAGE</small>' +
            '<strong id="noah-piece-title">楽園 -ノア-</strong>' +
          '</div>' +
          '<div class="noah-piece-ticket">所持枚数 <b id="noah-piece-ticket-count">0</b>枚</div>' +
        '</header>' +
        '<div class="noah-piece-body">' +
          '<div class="noah-piece-lead">' +
            '<div class="en">FRAGMENTS OF PARADISE</div>' +
            '<h2>失われた楽園を完成させる</h2>' +
            '<p>ノアを打ち破り、欠片を集める。<br>9つの欠片が揃ったとき、ひとつの姿が完成する。</p>' +
          '</div>' +
          // build1703: 「◯周目」は完成状況の行に入れると折り返して崩れるため、独立した1行にする
          '<div class="noah-piece-lap-row" style="text-align:center;margin:6px 0 -6px;font:600 13px/1.2 \'Noto Serif JP\',serif;letter-spacing:.18em;color:#8c6c48;text-shadow:0 0 6px #fff,0 0 2px #fff;white-space:nowrap">' +
            '<span style="font:600 10px/1 Cinzel,serif;letter-spacing:.24em;opacity:.8;margin-right:6px">LAP</span><b id="noah-piece-lap" style="font-weight:700">1周目</b>' +
          '</div>' +
          '<div class="noah-piece-progress">' +
            '<span class="noah-piece-progress-label" style="white-space:nowrap">完成状況</span>' +
            '<strong id="noah-piece-progress-now">0</strong><span style="white-space:nowrap">/ 9</span>' +
          '</div>' +
          '<div class="noah-puzzle-frame">' +
            '<div class="noah-puzzle-grid" id="noah-puzzle-grid">' + pieceHtml + '</div>' +
          '</div>' +
          '<div class="noah-piece-note">ステージクリアごとに、ノアの欠片を1つ獲得できます。</div>' +
        '</div>' +
        '<footer class="noah-piece-actions">' +
          '<button type="button" class="noah-piece-challenge" id="noah-piece-challenge" onclick="challengeNoahSpecialStage()">' +
            '<small>SPECIAL STAGE TICKET ×1</small>' +
            'ノアに挑戦する' +
          '</button>' +
          '<div class="noah-piece-complete" id="noah-piece-complete">楽園の欠片がすべて揃いました。</div>' +
        '</footer>' +
      '</section>';

    document.body.appendChild(overlay);
  }

  function renderNoahPiecePanel(){
    buildPanel();
    const count = getNoahPieceCount();
    const ticket = getSpecialTicketCount();

    const lapEl = document.getElementById('noah-piece-lap');
    if (lapEl) lapEl.textContent = serverLap + '周目';
    const progress = document.getElementById('noah-piece-progress-now');
    if (progress) progress.textContent = String(count);

    const ticketEl = document.getElementById('noah-piece-ticket-count');
    if (ticketEl) ticketEl.textContent = String(ticket);

    document.querySelectorAll('[data-noah-piece]').forEach(function(el){
      const pieceNo = Number(el.getAttribute('data-noah-piece') || 0);
      const open = pieceNo <= count;
      el.classList.toggle('locked', !open);
      el.classList.toggle('open', open);
    });

    const button = document.getElementById('noah-piece-challenge');
    if (button) {
      // build1704: 元の仕様どおり、チケットが無くてもステージ選択（GIMMICK確認）までは開ける
      button.disabled = false;
      const small = button.querySelector('small');
      if (small) {
        small.textContent = 'SPECIAL TICKET -ノア-　所持 ' + ticket + '枚';
      }
    }

    const complete = document.getElementById('noah-piece-complete');
    if (complete) { complete.classList.toggle('show', !!lastRewardMessage); complete.textContent = lastRewardMessage; }
  }

  async function openNoahPiecePanel(){
    if (typeof window.requireChapter03ContentUnlock === 'function' && !window.requireChapter03ContentUnlock()) return;
    buildPanel();
    if (typeof window.refreshSpecialTicketUI === 'function') {
      try { await window.refreshSpecialTicketUI(); } catch (_) {}
    }
    await refreshNoahProgress();
    renderNoahPiecePanel();

    const overlay = document.getElementById('noah-piece-overlay');
    overlay.classList.add('active');
    overlay.setAttribute('aria-hidden','false');
  }

  function closeNoahPiecePanel(){
    const overlay = document.getElementById('noah-piece-overlay');
    if (!overlay) return;
    overlay.classList.remove('active');
    overlay.setAttribute('aria-hidden','true');
  }

  function challengeNoahSpecialStage(){
    const ticket = getSpecialTicketCount();
    if (ticket < 1) {
      if (typeof window.showToast === 'function') window.showToast('SPECIAL STAGE TICKETがありません');
      else alert('SPECIAL STAGE TICKETがありません');
      return;
    }

    closeNoahPiecePanel();

    if (typeof window.openShootingEvent === 'function') {
      window.openShootingEvent({ stageId: STAGE_ID });
    } else {
      console.error('[NoahPiece] openShootingEvent is not available');
    }
  }

  async function syncUnlockedNoahToLocal(characterRowId){
    if (!characterRowId) return;
    try {
      const sb = window.zsSupabase;
      if (!sb) return;

      const rowRes = await sb.from('collected_characters')
        .select('*')
        .eq('id', Number(characterRowId))
        .maybeSingle();
      if (rowRes && rowRes.error) throw rowRes.error;
      const row = rowRes && rowRes.data;
      if (!row) return;

      const chara = typeof getCharaById === 'function' ? getCharaById(52) : null;
      if (!chara) return;

      const entry = typeof buildOwnedEntryFromChara === 'function'
        ? buildOwnedEntryFromChara(chara, row)
        : (typeof createCharaSummonData === 'function'
            ? createCharaSummonData(chara, new Date(row.captured_at || Date.now()))
            : null);

      if (!entry) return;
      entry.db_id = row.id;

      if (typeof box !== 'undefined' && Array.isArray(box) &&
          !box.some(x => x && Number(x.db_id) === Number(entry.db_id))) {
        box.push(entry);
      }
      if (typeof collected !== 'undefined' && collected) {
        collected[52] = collected[52] || entry;
      }

      try { if (typeof renderBox === 'function') renderBox(); } catch (_) {}
      try { if (typeof updateMainUI === 'function') updateMainUI(); } catch (_) {}
      try { if (typeof updateZukanLimitBreakNotice === 'function') updateZukanLimitBreakNotice(); } catch (_) {}
      try { if (typeof window.refreshShootingRoster === 'function') window.refreshShootingRoster(); } catch (_) {}
    } catch (err) {
      console.warn('[NoahPiece] local Noah sync failed:', err);
    }
  }

  async function finishNoahClear(){
    if (finishPending) return;

    const attemptId = String(window.__noahAttemptId || '');
    if (!attemptId) {
      console.warn('[NoahPiece] no attempt id; clear reward skipped');
      return;
    }

    const sb = window.zsSupabase;
    if (!sb || typeof sb.rpc !== 'function') return;

    finishPending = true;
    try {
      const res = await sb.rpc('finish_noah_attempt', { p_attempt_id: attemptId });
      if (res && res.error) throw res.error;

      let data = res ? res.data : null;
      if (typeof data === 'string') {
        try { data = JSON.parse(data); } catch (_) {}
      }
      if (!data || data.ok === false) {
        throw new Error((data && data.message) || 'ノアの欠片を受け取れませんでした');
      }

      window.__noahAttemptId = null;
      const before = getNoahPieceCount();
      if (Number.isInteger(Number(data.lap)) && Number(data.lap) >= 1) {
        serverLap = Number(data.lap);
        window.__noahLap = serverLap;
      }
      lastRewardMessage = data.completed_lap != null ? String(data.message || '') : '';
      const after = setDisplayPieceCount(data.piece_count);

      if (data.granted_noah) {
        await syncUnlockedNoahToLocal(data.character_row_id);
        if (data.unlocked_noah && typeof window.showNoahCompletePopup === 'function') {
          try { window.showNoahCompletePopup(); } catch (_) {}
        } else if (typeof window.showToast === 'function') {
          window.showToast(data.message || 'ノアを1体獲得（限界突破に使えます）');
        }
      } else if (data.completed_lap != null && typeof window.showToast === 'function') {
        window.showToast(data.message || '周回完了');
      } else if (after > before && typeof window.showToast === 'function') {
        window.showToast('ノアの欠片を1つ獲得しました');
      }
    } catch (err) {
      console.error('[NoahPiece] finish attempt failed:', err);
      if (typeof window.showToast === 'function') {
        window.showToast(err && err.message ? err.message : 'ノアの欠片の受取に失敗しました');
      }
    } finally {
      finishPending = false;
    }
  }

  function handleShootingStageResult(event){
    const detail = event && event.detail ? event.detail : null;
    if (!detail || detail.stageId !== STAGE_ID) return;

    if (detail.win) {
      void finishNoahClear();
    } else {
      // 敗北したattemptは報酬に使わず、次の挑戦では新しいattemptを発行する。
      window.__noahAttemptId = null;
    }
  }

  window.getNoahPieceCount = getNoahPieceCount;
  window.refreshNoahProgress = refreshNoahProgress;
  window.renderNoahPiecePanel = renderNoahPiecePanel;
  window.openNoahPiecePanel = openNoahPiecePanel;
  window.closeNoahPiecePanel = closeNoahPiecePanel;
  window.challengeNoahSpecialStage = challengeNoahSpecialStage;

  window.addEventListener('shooting-stage-result', handleShootingStageResult);
  window.addEventListener('pageshow', function(){
    void refreshNoahProgress();
  });
})();
