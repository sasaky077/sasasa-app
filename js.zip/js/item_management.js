
(function(){
  'use strict';

  const SELLABLE_DEFAULT_ORDER = [
    'kyoumei_stone',
    'soul_vessel_fire',
    'soul_vessel_aqua',
    'soul_vessel_wood',
    'soul_vessel_dark',
    'soul_vessel_light'
  ];

  // 廃止済みの素材は所持データを消さず、画面からのみ除外する。
  const RETIRED_EVOLUTION_ITEMS = new Set(['soul_vessel_logos', 'eri_origin_wing']);

  const LEGACY_LABELS = {
    soul_vessel_mystis:'魂の器(MYSTIS)',
    soul_vessel_chaos:'魂の器(CHAOS)'
  };

  const FALLBACK_EVOLUTION = {
    kyoumei_stone:{name:'共鳴石',img:'images/item_kyoumeistone.webp',desc:'プリモアの魂を同調させる神秘的な石。'},
    soul_vessel_fire:{name:'魂の器(火)',img:'images/item_soul_vessel_fire.webp',desc:'火属性の魂を受け止める神具。'},
    soul_vessel_aqua:{name:'魂の器(水)',img:'images/item_soul_vessel_aqua.webp',desc:'水属性の魂を受け止める神具。'},
    soul_vessel_wood:{name:'魂の器(木)',img:'images/item_soul_vessel_wood.webp',desc:'木属性の魂を受け止める神具。'},
    soul_vessel_dark:{name:'魂の器(闇)',img:'images/item_soul_vessel_dark.webp',desc:'闇属性の魂を受け止める神具。'},
    soul_vessel_light:{name:'魂の器(光)',img:'images/item_soul_vessel_light.webp',desc:'光属性の魂を受け止める神具。'},
    seihai:{name:'聖なる盃',img:'images/item_seihai.webp',desc:'神聖な力を湛えた進化用素材。'},
    overseer_blk_core:{name:'竜型レムナント亜種の心核',img:'images/item_overseer_blk_core.webp',desc:'特殊強化に使用する異質な心核。'},
    soul_vessel_mystis:{name:'魂の器(MYSTIS)',img:'',desc:'旧式の進化素材。'},
    soul_vessel_chaos:{name:'魂の器(CHAOS)',img:'',desc:'旧式の進化素材。'}
  };

  const FALLBACK_LEVEL = [
    {id:'level_exp_small',name:'強化素材・銅',shortName:'銅',img:'images/item_exp_bronze.webp',exp:100},
    {id:'level_exp_medium',name:'強化素材・銀',shortName:'銀',img:'images/item_exp_silver.webp',exp:500},
    {id:'level_exp_large',name:'強化素材・金',shortName:'金',img:'images/item_exp_gold.webp',exp:2000}
  ];

  const OTHER_ITEMS = [
    {
      // build1486: 残響の塔15F（トワ）の報酬。使い道は今後実装。
      id:'towa_memory',
      source:'inventory',
      name:'トワの記憶',
      img:'images/item_towa_memory.webp',
      kicker:'ECHO MEMORY',
      desc:'残響の塔の最深部で、トワが遺した記憶の結晶。その使い道はまだ分からない。',
      tag:'記憶'
    },
    {
      id:'special_stage_ticket',
      source:'profile',
      name:'ノア挑戦チケット',
      img:'images/special_stage_ticket.webp',
      kicker:'QUEST TICKET',
      desc:'SPECIAL STAGE「理想郷 -ノア-」への挑戦に使用するチケット。',
      tag:'クエスト'
    },
    {
      id:'tower_limited_ten_ticket',
      source:'inventory',
      name:'限定邂逅10連無料TICKET',
      img:'images/gacha_ticket_10.webp',
      kicker:'LIMITED ENCOUNTER TICKET',
      desc:'残響の塔7Fの報酬。限定邂逅（ニーナ／オリビア／スマイル）で10連を1回無料で引けます。',
      tag:'ガチャ'
    },
    {
      id:'flower_r',
      source:'inventory',
      name:'聖霊花(R)',
      img:'images/item_flower_r.webp',
      kicker:'SPIRIT FLOWER',
      desc:'Rキャラクターが完凸後に重複した際、代わりに獲得する交換素材。',
      tag:'交換素材'
    },
    {
      id:'flower_sr',
      source:'inventory',
      name:'聖霊花(SR)',
      img:'images/item_flower_sr.webp',
      kicker:'SPIRIT FLOWER',
      desc:'SRキャラクターが完凸後に重複した際、代わりに獲得する交換素材。',
      tag:'交換素材'
    }
  ];

  // build1645: SR確定単発チケット。抽選はサーバーで行う。
  OTHER_ITEMS.push({id:'sr_guaranteed_ticket',source:'inventory',name:'SR確定ガチャTICKET',
    img:'images/gacha_ticket_10.webp',kicker:'SR GUARANTEED',
    desc:'指定SR13体から1体確定。邂逅の「超特別邂逅」から使用。',tag:'ガチャ'});

  // build1813: 使用型チケット（レイドリセット券・位相回遊スキップ券・創世ptルーレット券）。定義は item_tickets.js
  if(window.ItemTickets && Array.isArray(window.ItemTickets.ORDER)){
    window.ItemTickets.ORDER.forEach(id=>{
      const m=window.ItemTickets.ITEMS[id];
      if(m) OTHER_ITEMS.push({id:m.id,source:'inventory',name:m.name,img:m.img,kicker:m.kicker,desc:m.desc,tag:m.tag,useTicket:true});
    });
  }

  const FLOWER_SR_EXCHANGES = [
    {id:'noah_ticket_1',cost:1,name:'ノア挑戦チケット ×1',img:'images/special_stage_ticket.webp',desc:'SPECIAL STAGE「理想郷 -ノア-」へ挑戦'},
    {id:'flower_r_3',cost:1,name:'聖霊花(R) ×3',img:'images/item_flower_r.webp',desc:'聖霊花(R)を3個獲得'},
    {id:'sr_ticket_1',cost:5,name:'SR確定ガチャTICKET ×1',img:'images/gacha_ticket_10.webp',desc:'恒常SRが1体確定する単発チケット'}
  ];

  const FLOWER_R_EXCHANGES = [
    {
      group:'R ×1',
      id:'exp_gold_5',
      cost:1,
      name:'経験値素材・金 ×5',
      img:'images/item_exp_gold.webp',
      desc:'強化素材・金を5個獲得'
    },
    {
      group:'R ×1',
      id:'kyoumei_1',
      cost:1,
      name:'共鳴石 ×1',
      img:'images/item_kyoumeistone.webp',
      desc:'共鳴石を1個獲得'
    },
    {
      group:'R ×1',
      id:'vessel_fire_2',
      cost:1,
      name:'魂の器(火) ×2',
      img:'images/item_soul_vessel_fire.webp',
      desc:'火属性の器を2個獲得'
    },
    {
      group:'R ×1',
      id:'vessel_aqua_2',
      cost:1,
      name:'魂の器(水) ×2',
      img:'images/item_soul_vessel_aqua.webp',
      desc:'水属性の器を2個獲得'
    },
    {
      group:'R ×1',
      id:'vessel_wood_2',
      cost:1,
      name:'魂の器(木) ×2',
      img:'images/item_soul_vessel_wood.webp',
      desc:'木属性の器を2個獲得'
    },
    {
      group:'R ×1',
      id:'vessel_dark_2',
      cost:1,
      name:'魂の器(闇) ×2',
      img:'images/item_soul_vessel_dark.webp',
      desc:'闇属性の器を2個獲得'
    },
    {
      group:'R ×1',
      id:'vessel_light_2',
      cost:1,
      name:'魂の器(光) ×2',
      img:'images/item_soul_vessel_light.webp',
      desc:'光属性の器を2個獲得'
    },
    {
      group:'R ×3',
      id:'exp_set_10',
      cost:3,
      name:'経験値素材セット',
      img:'images/item_exp_gold.webp',
      desc:'金・銀・銅を各10個ずつ獲得'
    },
    {
      group:'R ×3',
      id:'vessel_all_1',
      cost:3,
      name:'各種器セット',
      img:'images/item_kyoumeistone.webp',
      desc:'火・水・木・闇・光の器を各1個獲得'
    },
    {
      group:'R ×5',
      id:'event_ticket_silver',
      cost:5,
      name:'イベントticket銀',
      img:'',
      desc:'今後実装予定',
      disabled:true
    },
    {
      group:'R ×10',
      id:'event_ticket_gold',
      cost:10,
      name:'イベントticket金',
      img:'',
      desc:'今後実装予定',
      disabled:true
    },
    {
      group:'R ×10',
      id:'skin_3_limited_01',
      cost:10,
      name:'限定衣装',
      characterId:3,
      img:'images/chara_03_b_panel.webp',
      desc:'キャラクター衣装を解放'
    },
    {
      group:'R ×10',
      id:'skin_9_limited_01',
      cost:10,
      name:'限定衣装',
      characterId:9,
      img:'images/chara_09_b_panel.webp',
      desc:'キャラクター衣装を解放'
    },
    {
      group:'R ×10',
      id:'skin_20_limited_01',
      cost:10,
      name:'限定衣装',
      characterId:20,
      img:'images/chara_20_b_panel.webp',
      desc:'キャラクター衣装を解放'
    },
    {
      group:'R ×10',
      id:'skin_36_limited_01',
      cost:10,
      name:'限定衣装',
      characterId:36,
      img:'images/chara_36_b_panel.webp',
      desc:'キャラクター衣装を解放'
    }
    // build1706: レオナクロス ハロウィン衣装はお知らせのプレゼントで全員に配布（交換所には出さない）
  ];

  let state = {
    tab:'evolution',
    loading:false,
    items:{},
    sellPrices:{},
    coin:0,
    specialStageTicket:0,
    sellItemId:'',
    sellQty:1,
    exchanging:false
  };

  function fmt(n){
    return Math.max(0,Math.floor(Number(n)||0)).toLocaleString('ja-JP');
  }

  function toast(msg){
    if(typeof window.showToast==='function') window.showToast(msg);
    else if(msg) alert(msg);
  }

  function normalizeItemId(raw){
    return String(raw||'').replace(/^evo:/,'');
  }

  function normalizedItems(raw){
    const out={};
    Object.keys(raw||{}).forEach(key=>{
      const id=normalizeItemId(key);
      const qty=Math.max(0,Math.floor(Number(raw[key])||0));
      out[id]=(out[id]||0)+qty;
    });
    return out;
  }

  function evolutionMaster(){
    const master=Object.assign({},FALLBACK_EVOLUTION);
    const ext=window.ShootingResonance && window.ShootingResonance.MATERIAL_MASTER;
    if(ext && typeof ext==='object'){
      Object.keys(ext).forEach(id=>{
        master[id]=Object.assign({},master[id]||{},ext[id]||{});
      });
    }
    Object.keys(LEGACY_LABELS).forEach(id=>{
      if(!master[id]) master[id]={name:LEGACY_LABELS[id],img:'',desc:'進化素材。'};
    });
    // build1711: レイドボスの欠片（〇〇の欠片／images/raid_piece_<キャラ名>.webp）。定義は raid_event.js に一本化。
    if(typeof window.getRaidPieceItemMeta==='function'){
      Object.keys(state.items||{}).forEach(id=>{
        if(master[id]) return;
        const pm=window.getRaidPieceItemMeta(id);
        if(pm) master[id]=pm;
      });
    }
    return master;
  }

  function levelMaster(){
    const fallbackById=Object.fromEntries(FALLBACK_LEVEL.map(x=>[x.id,Object.assign({},x)]));
    const ext=window.CharacterLeveling && Array.isArray(window.CharacterLeveling.MATERIALS)
      ? window.CharacterLeveling.MATERIALS
      : [];

    ext.forEach(x=>{
      const id=String(x.id||'');
      if(!id) return;
      fallbackById[id]=Object.assign({},fallbackById[id]||{},x||{});
    });

    return FALLBACK_LEVEL.map(base=>{
      const x=fallbackById[base.id]||base;
      return {
        id:String(x.id||base.id),
        name:String(base.name),
        shortName:String(base.shortName),
        img:String(base.img||x.img||''),
        exp:Math.max(0,Number(x.exp!=null?x.exp:base.exp)||0)
      };
    });
  }

  async function fetchSnapshot(){
    const client=window.zsSupabase;
    if(!client || typeof client.rpc!=='function') throw new Error('サーバーへ接続できません');

    if(window.zsAuthReady){
      try{ await window.zsAuthReady; }catch(_){}
    }

    const res=await client.rpc('get_my_inventory_snapshot');
    if(res && res.error) throw res.error;

    let data=res ? res.data : null;
    if(typeof data==='string'){
      try{ data=JSON.parse(data); }catch(_){}
    }
    if(!data || data.ok===false) throw new Error((data&&data.message)||'アイテム情報を取得できません');

    state.items=normalizedItems(data.items||{});
    state.sellPrices=data.sell_prices||{};
    state.coin=Math.max(0,Math.floor(Number(data.coin)||0));
    state.specialStageTicket=Math.max(0,Math.floor(Number(data.special_stage_ticket)||0));

    if(window.userProfile){
      window.userProfile.coin=state.coin;
      window.userProfile.special_stage_ticket=state.specialStageTicket;
      if(typeof window.writeProfileCache==='function'){
        try{ window.writeProfileCache(window.userProfile); }catch(_){}
      }
    }
    if(typeof window.updateMainUI==='function') window.updateMainUI();
    return data;
  }

  // 進化素材は明示的な許可リストのみ。チケット・記憶・交換アイテムは所持していても表示しない。
  function isEvolutionItem(id){
    if(RETIRED_EVOLUTION_ITEMS.has(id)) return false;
    if(id==='kyoumei_stone') return true;
    if(/^soul_vessel_(fire|aqua|wood|dark|light|mystis|chaos)$/.test(id)) return true;
    // レイド欠片の正本定義を参照し、名前が似た非レイド素材は含めない。
    return typeof window.getRaidPieceItemMeta==='function' && !!window.getRaidPieceItemMeta(id);
  }

  function getEvolutionIds(){
    const seen=new Set();
    const ids=[];
    function add(id){ if(isEvolutionItem(id) && !seen.has(id)){seen.add(id);ids.push(id);} }
    SELLABLE_DEFAULT_ORDER.forEach(add);
    Object.keys(state.items).forEach(add);
    return ids;
  }

  function countOwnedTypes(ids){
    return ids.reduce((sum,id)=>sum+((state.items[id]||0)>0?1:0),0);
  }

  function renderIcon(meta, type){
    if(meta && meta.img){
      return '<div class="item-row-icon'+(type==='level'?' is-exp':'')+'"><img src="'+escapeHtml(meta.img)+'" alt="" onerror="this.style.display=\'none\'"></div>';
    }
    const fallback=(type==='level' ? (meta.shortName||'強') : String(meta.name||'?').slice(0,1));
    return '<div class="item-row-icon is-level"><span>'+escapeHtml(fallback)+'</span></div>';
  }

  function escapeHtml(value){
    return String(value==null?'':value)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#39;');
  }

  function render(){
    const list=document.getElementById('item-management-list');
    if(!list) return;

    const coin=document.getElementById('item-screen-coin');
    if(coin) coin.textContent=fmt(state.coin);

    const evoMaster=evolutionMaster();
    const evoIds=getEvolutionIds();
    const lvlMaster=levelMaster();

    document.querySelectorAll('#screen-item .item-category-tab').forEach(btn=>{
      btn.classList.toggle('is-active',btn.dataset.itemTab===state.tab);
    });

    const kicker=document.getElementById('item-panel-kicker');
    const title=document.getElementById('item-panel-title');

    if(state.tab==='other'){
      if(kicker) kicker.textContent='OTHER ITEM';
      if(title) title.textContent='その他';

      list.innerHTML=OTHER_ITEMS.map(meta=>{
        const qty=meta.source==='profile'
          ? state.specialStageTicket
          : Math.max(0,Number(state.items[meta.id]||0));

        const isFlowerR=meta.id==='flower_r';
        const isFlowerSR=meta.id==='flower_sr';
        const actionHtml=isFlowerR
          ? '<div class="item-row-actions item-row-actions-other"><button class="item-exchange-open-btn" type="button" data-open-flower-exchange>交換</button></div>'
          : (isFlowerSR
              ? '<div class="item-row-actions item-row-actions-other"><button class="item-exchange-open-btn" type="button" data-open-flower-sr-exchange>交換</button></div>'
              : ((meta.useTicket || meta.id==='special_stage_ticket' || meta.id==='tower_limited_ten_ticket' || meta.id==='sr_guaranteed_ticket')
                  ? '<div class="item-row-actions item-row-actions-other"><button class="item-exchange-open-btn" type="button" data-use-other-ticket="'+escapeHtml(meta.id)+'" '+(qty>0?'':'disabled')+'>使用</button></div>'
                  : ''));

        return ''+
          '<article class="item-row item-row-other'+(qty<=0?' is-zero':'')+(meta.useTicket?' is-ticket':'')+'">'+
            renderIcon(meta,'other')+
            '<div class="item-row-main">'+
              '<div class="item-row-kicker">'+escapeHtml(meta.kicker||'OTHER ITEM')+'</div>'+
              '<div class="item-row-name">'+escapeHtml(meta.name)+'</div>'+
              '<div class="item-row-desc">'+escapeHtml(meta.desc||'')+'</div>'+
              '<div class="item-row-count item-row-count-other"><span>OWNED</span><strong>'+(isFlowerSR&&qty<=0?'—':fmt(qty))+'</strong></div>'+
            '</div>'+
            actionHtml+
          '</article>';
      }).join('');
      return;
    }

    if(state.tab==='level'){
      if(kicker) kicker.textContent='ENHANCE MATERIAL';
      if(title) title.textContent='強化素材';

      list.innerHTML=lvlMaster.map(meta=>{
        const qty=Math.max(0,Number(state.items[meta.id]||0));
        const price=Math.max(0,Number(state.sellPrices[meta.id]||0));
        const sellable=price>0 && qty>0;
        return ''+
          '<article class="item-row'+(qty<=0?' is-zero':'')+'">'+
            renderIcon(meta,'level')+
            '<div class="item-row-main">'+
              '<div class="item-row-kicker">ENHANCE ITEM</div>'+
              '<div class="item-row-name">'+escapeHtml(meta.name)+'</div>'+
              '<div class="item-row-desc">キャラクター経験値 +'+fmt(meta.exp)+'</div>'+
              '<div class="item-row-count"><span>OWNED</span><strong>'+fmt(qty)+'</strong></div>'+
            '</div>'+
            '<div class="item-row-actions">'+
              '<button class="item-sell-btn" type="button" data-sell-item="'+escapeHtml(meta.id)+'" '+(sellable?'':'disabled')+'>売却</button>'+
              '<div class="item-row-price">'+
                (price>0?'<img src="images/icon_coin.webp" alt=""> '+fmt(price)+' / 個':'売却対象外')+
              '</div>'+
            '</div>'+
          '</article>';
      }).join('');
      return;
    }

    if(kicker) kicker.textContent='EVOLUTION MATERIAL';
    if(title) title.textContent='進化素材';

    list.innerHTML=evoIds.map(id=>{
      const meta=evoMaster[id]||{name:id,img:'',desc:'進化素材。'};
      const qty=Math.max(0,Number(state.items[id]||0));
      const price=Math.max(0,Number(state.sellPrices[id]||0));
      const sellable=price>0 && qty>0;
      return ''+
        '<article class="item-row'+(qty<=0?' is-zero':'')+'">'+
          renderIcon(meta,'evolution')+
          '<div class="item-row-main">'+
            '<div class="item-row-kicker">EVOLUTION ITEM</div>'+
            '<div class="item-row-name">'+escapeHtml(meta.name||id)+'</div>'+
            '<div class="item-row-desc">'+escapeHtml(meta.desc||'進化に使用する素材。')+'</div>'+
            '<div class="item-row-count"><span>OWNED</span><strong>'+fmt(qty)+'</strong></div>'+
          '</div>'+
          '<div class="item-row-actions">'+
            '<button class="item-sell-btn" type="button" data-sell-item="'+escapeHtml(id)+'" '+(sellable?'':'disabled')+'>売却</button>'+
            '<div class="item-row-price">'+
              (price>0?'<img src="images/icon_coin.webp" alt=""> '+fmt(price)+' / 個':'売却対象外')+
            '</div>'+
          '</div>'+
        '</article>';
    }).join('');
  }

  async function refresh(){
    if(state.loading) return;
    state.loading=true;
    const list=document.getElementById('item-management-list');
    if(list) list.innerHTML='<div class="item-management-loading">読み込み中...</div>';
    const srList=document.getElementById('spirit-flower-sr-exchange-list');
    if(srList)srList.addEventListener('click',e=>{const btn=e.target.closest('[data-flower-sr-exchange-id]');if(btn&&!btn.disabled)exchangeFlowerSR(btn.dataset.flowerSrExchangeId);});
    document.querySelectorAll('[data-flower-sr-exchange-close]').forEach(el=>el.addEventListener('click',closeFlowerSRExchange));

    const refreshBtn=document.getElementById('item-refresh-btn');
    if(refreshBtn) refreshBtn.disabled=true;

    try{
      await fetchSnapshot();
      render();
    }catch(err){
      console.error('[ItemManagement] refresh failed',err);
      if(list) list.innerHTML='<div class="item-management-empty">アイテム情報を読み込めませんでした。<br>通信状態を確認して再度お試しください。</div>';
      toast(err&&err.message?err.message:'アイテム情報の取得に失敗しました');
    }finally{
      state.loading=false;
      if(refreshBtn) refreshBtn.disabled=false;
    }
  }

  function closeSell(){
    const modal=document.getElementById('item-sell-modal');
    if(!modal) return;
    modal.hidden=true;
    modal.setAttribute('aria-hidden','true');
    state.sellItemId='';
    state.sellQty=1;
  }

  function getSellMeta(id){
    const evo=evolutionMaster();
    const level=levelMaster().find(x=>x.id===id);
    const meta=level || evo[id] || {name:id,img:'',desc:''};
    return {
      id,
      meta,
      owned:Math.max(0,Math.floor(Number(state.items[id]||0))),
      price:RETIRED_EVOLUTION_ITEMS.has(id)
        ? 0
        : Math.max(0,Math.floor(Number(state.sellPrices[id]||0)))
    };
  }

  function updateSellUI(){
    const id=state.sellItemId;
    if(!id) return;
    const data=getSellMeta(id);
    const max=Math.max(1,data.owned);
    state.sellQty=Math.max(1,Math.min(max,Math.floor(Number(state.sellQty)||1)));

    const qty=document.getElementById('item-sell-qty');
    if(qty){
      qty.max=String(max);
      qty.value=String(state.sellQty);
    }

    const owned=document.getElementById('item-sell-owned');
    const unit=document.getElementById('item-sell-unit-price');
    const total=document.getElementById('item-sell-total-price');
    if(owned) owned.textContent=fmt(data.owned);
    if(unit) unit.textContent=fmt(data.price);
    if(total) total.textContent=fmt(data.price*state.sellQty);

    const confirm=document.getElementById('item-sell-confirm');
    if(confirm) confirm.disabled=!(data.owned>0 && data.price>0 && state.sellQty>0);
  }

  function openSell(id){
    const data=getSellMeta(id);
    if(!(data.owned>0 && data.price>0)) return;

    state.sellItemId=id;
    state.sellQty=1;

    const modal=document.getElementById('item-sell-modal');
    const name=document.getElementById('item-sell-name');
    const icon=document.getElementById('item-sell-icon');
    if(name) name.textContent=data.meta.name||id;
    if(icon){
      icon.innerHTML=data.meta.img
        ? '<img src="'+escapeHtml(data.meta.img)+'" alt="" onerror="this.style.display=\'none\'">'
        : '<span>'+escapeHtml(String(data.meta.name||'?').slice(0,1))+'</span>';
    }
    updateSellUI();
    if(modal){
      modal.hidden=false;
      modal.setAttribute('aria-hidden','false');
    }
  }

  async function sell(){
    const id=state.sellItemId;
    if(!id) return;
    updateSellUI();
    const qty=Math.max(1,Math.floor(Number(state.sellQty)||1));
    const confirm=document.getElementById('item-sell-confirm');
    if(confirm){confirm.disabled=true;confirm.textContent='売却中...';}

    try{
      const client=window.zsSupabase;
      if(!client || typeof client.rpc!=='function') throw new Error('サーバーへ接続できません');

      const res=await client.rpc('sell_inventory_item',{
        p_item_id:id,
        p_quantity:qty
      });
      if(res && res.error) throw res.error;

      let result=res?res.data:null;
      if(typeof result==='string'){
        try{result=JSON.parse(result)}catch(_){}
      }
      if(!result || result.ok===false) throw new Error((result&&result.message)||'売却に失敗しました');

      state.items[id]=Math.max(0,Math.floor(Number(result.remaining_quantity)||0));
      state.coin=Math.max(0,Math.floor(Number(result.coin)||0));

      if(window.userProfile){
        window.userProfile.coin=state.coin;
        if(typeof window.writeProfileCache==='function'){
          try{window.writeProfileCache(window.userProfile)}catch(_){}
        }
      }

      // Other growth UI/local inventory uses the same server source; reload it after sale.
      const userId=String(localStorage.getItem('zukan_user_id')||'').trim();
      if(userId && typeof window.loadInventoryFromSupabase==='function'){
        try{await window.loadInventoryFromSupabase(userId)}catch(err){console.warn('[ItemManagement] local inventory sync skipped',err);}
      }

      if(typeof window.updateMainUI==='function') window.updateMainUI();
      try{window.dispatchEvent(new CustomEvent('sasaphia:growth-resources-changed'))}catch(_){}

      closeSell();
      render();
      toast((result.sold_quantity||qty)+'個を売却し、'+fmt(result.coin_gain)+'コインを獲得しました');
    }catch(err){
      console.error('[ItemManagement] sell failed',err);
      toast(err&&err.message?err.message:'売却に失敗しました');
    }finally{
      if(confirm){confirm.disabled=false;confirm.textContent='売却する';}
    }
  }

  function closeFlowerExchange(){
    const modal=document.getElementById('spirit-flower-exchange-modal');
    if(!modal) return;
    modal.hidden=true;
    modal.setAttribute('aria-hidden','true');
  }

  function renderFlowerExchange(){
    const list=document.getElementById('spirit-flower-exchange-list');
    const ownedEl=document.getElementById('flower-r-exchange-owned');
    if(!list) return;

    const owned=Math.max(0,Math.floor(Number(state.items.flower_r||0)));
    if(ownedEl) ownedEl.textContent=fmt(owned);

    // build1475: 必要数は各行に表示するため、グループ見出し（R ×1 など）は出さない。
    list.innerHTML=FLOWER_R_EXCHANGES.map(item=>{
      const groupHead='';

      const skinId=item.characterId ? 'limited_01' : '';
      const skinOwned=!!(item.characterId && window.CharacterSkins &&
        typeof window.CharacterSkins.isOwned==='function' &&
        window.CharacterSkins.isOwned(item.characterId,skinId));
      const canExchange=!item.disabled && !skinOwned && owned>=item.cost && !state.exchanging;
      // build1489: 限定衣装は画像タップで衣装の立ち絵をプレビューできる。
      const previewAttr=item.characterId ? ' data-skin-preview="'+Number(item.characterId)+'" role="button" tabindex="0" aria-label="限定衣装をプレビュー"' : '';
      const icon=item.img
        ? '<div class="item-exchange-reward-icon'+(item.characterId?' is-previewable':'')+'"'+previewAttr+'><img src="'+escapeHtml(item.img)+'" alt="" onerror="this.style.display=\'none\'"></div>'
        : '<div class="item-exchange-reward-icon is-placeholder"><span>?</span></div>';

      let displayName=item.name;
      let displayDesc=item.desc||'';
      if(item.characterId){
        const c=(Array.isArray(window.CHARACTERS)?window.CHARACTERS:[]).find(x=>x&&Number(x.id)===Number(item.characterId));
        const sk=window.CharacterSkins&&typeof window.CharacterSkins.getSkin==='function'?window.CharacterSkins.getSkin(item.characterId,skinId):null;
        displayName=(c&&c.name?c.name+' ':'')+((sk&&sk.name)||'限定衣装');
        displayDesc=skinOwned?'取得済み':'キャラクター衣装を解放';
      }

      return groupHead+
        '<article class="item-exchange-row'+(item.disabled?' is-disabled':'')+(skinOwned?' is-owned':'')+'">'+
          icon+
          '<div class="item-exchange-copy">'+
            '<strong>'+escapeHtml(displayName)+'</strong>'+
            '<span>'+escapeHtml(displayDesc)+'</span>'+
          '</div>'+
          '<div class="item-exchange-cost'+(owned<item.cost?' is-short':'')+'" aria-label="必要数 聖霊花(R) '+fmt(item.cost)+'">'+
            '<img src="images/item_flower_r.webp" alt="" onerror="this.style.visibility=\'hidden\'"><b>'+fmt(item.cost)+'</b>'+
          '</div>'+
          '<button type="button" class="item-exchange-btn" data-flower-exchange-id="'+escapeHtml(item.id)+'" '+
            (canExchange?'':'disabled')+'>'+
            (item.disabled?'準備中':(skinOwned?'取得済み':'交換'))+
          '</button>'+
        '</article>';
    }).join('');
  }

  function openFlowerExchange(){
    const modal=document.getElementById('spirit-flower-exchange-modal');
    if(!modal) return;
    renderFlowerExchange();
    modal.hidden=false;
    modal.setAttribute('aria-hidden','false');
  }

  function buildExchangeGrantText(grants){
    const evo=evolutionMaster();
    const levels=Object.fromEntries(levelMaster().map(x=>[x.id,x]));
    return Object.keys(grants||{}).map(id=>{
      const meta=levels[id]||evo[id]||{name:id};
      return (meta.name||id)+' ×'+fmt(grants[id]);
    }).join(' / ');
  }

  async function exchangeFlowerR(exchangeId){
    if(state.exchanging) return;
    const def=FLOWER_R_EXCHANGES.find(x=>x.id===exchangeId);
    if(!def || def.disabled) return;

    const owned=Math.max(0,Math.floor(Number(state.items.flower_r||0)));
    if(owned<def.cost){
      toast('聖霊花(R)が不足しています');
      return;
    }

    state.exchanging=true;
    renderFlowerExchange();

    try{
      const client=window.zsSupabase;
      if(!client || typeof client.rpc!=='function') throw new Error('サーバーへ接続できません');

      const res=await client.rpc('exchange_spirit_flower_r',{
        p_exchange_id:exchangeId
      });
      if(res && res.error) throw res.error;

      let result=res?res.data:null;
      if(typeof result==='string'){
        try{result=JSON.parse(result)}catch(_){}
      }
      if(!result || result.ok===false) throw new Error((result&&result.message)||'交換に失敗しました');

      state.items.flower_r=Math.max(0,Math.floor(Number(result.remaining_flower_r)||0));
      Object.keys(result.grants||{}).forEach(id=>{
        state.items[id]=Math.max(0,Math.floor(Number(state.items[id]||0)))+
          Math.max(0,Math.floor(Number(result.grants[id]||0)));
      });

      const userId=String(localStorage.getItem('zukan_user_id')||'').trim();
      if(userId && typeof window.loadInventoryFromSupabase==='function'){
        try{await window.loadInventoryFromSupabase(userId)}catch(err){
          console.warn('[ItemManagement] exchange local inventory sync skipped',err);
        }
      }

      if(result.skin && result.skin.character_id && result.skin.skin_id){
        if(window.CharacterSkins && typeof window.CharacterSkins.notifySkinAcquired==='function'){
          window.CharacterSkins.notifySkinAcquired(result.skin.character_id,result.skin.skin_id);
        }
        if(window.CharacterSkins && typeof window.CharacterSkins.reloadMySkins==='function'){
          try{await window.CharacterSkins.reloadMySkins()}catch(_){}
        }
      }

      try{window.dispatchEvent(new CustomEvent('sasaphia:growth-resources-changed'))}catch(_){}
      renderFlowerExchange();
      render();

      if(result.skin && result.skin.character_id){
        const c=(Array.isArray(window.CHARACTERS)?window.CHARACTERS:[]).find(x=>x&&Number(x.id)===Number(result.skin.character_id));
        const skDone=window.CharacterSkins&&typeof window.CharacterSkins.getSkin==='function'?window.CharacterSkins.getSkin(def.characterId,'limited_01'):null;
        toast('交換しました：'+((c&&c.name)||'キャラクター')+' '+((skDone&&skDone.name)||'限定衣装'));
      }else{
        toast('交換しました：'+buildExchangeGrantText(result.grants||{}));
      }
    }catch(err){
      console.error('[ItemManagement] spirit flower exchange failed',err);
      toast(err&&err.message?err.message:'交換に失敗しました');
    }finally{
      state.exchanging=false;
      renderFlowerExchange();
    }
  }

  function closeFlowerSRExchange(){
    const modal=document.getElementById('spirit-flower-sr-exchange-modal');
    if(modal){modal.hidden=true;modal.setAttribute('aria-hidden','true');}
  }
  function renderFlowerSRExchange(){
    const list=document.getElementById('spirit-flower-sr-exchange-list');
    if(!list) return;
    const owned=Math.max(0,Math.floor(Number(state.items.flower_sr||0)));
    const count=document.getElementById('flower-sr-exchange-owned');
    if(count)count.textContent=fmt(owned);
    list.innerHTML=FLOWER_SR_EXCHANGES.map(item=>
      '<article class="item-exchange-row">'+
       '<div class="item-exchange-reward-icon"><img src="'+escapeHtml(item.img)+'" alt=""></div>'+
       '<div class="item-exchange-copy"><strong>'+escapeHtml(item.name)+'</strong><span>'+escapeHtml(item.desc)+'</span></div>'+
       '<div class="item-exchange-cost'+(owned<item.cost?' is-short':'')+'"><img src="images/item_flower_sr.webp" alt=""><b>'+fmt(item.cost)+'</b></div>'+
       '<button type="button" class="item-exchange-btn" data-flower-sr-exchange-id="'+escapeHtml(item.id)+'" '+(state.exchanging||owned<item.cost?'disabled':'')+'>交換</button>'+
      '</article>'
    ).join('');
  }
  function openFlowerSRExchange(){
    renderFlowerSRExchange();
    const modal=document.getElementById('spirit-flower-sr-exchange-modal');
    if(modal){modal.hidden=false;modal.setAttribute('aria-hidden','false');}
  }
  async function exchangeFlowerSR(exchangeId){
    if(state.exchanging)return;
    const def=FLOWER_SR_EXCHANGES.find(x=>x.id===exchangeId);
    if(!def)return;
    if(Number(state.items.flower_sr||0)<def.cost){toast('聖霊花(SR)が不足しています');return;}
    if(!window.confirm('聖霊花(SR) ×'+def.cost+' を消費して\n「'+def.name+'」に交換しますか？'))return;
    state.exchanging=true;renderFlowerSRExchange();
    try{
      const client=window.zsSupabase;
      if(!client||typeof client.rpc!=='function')throw new Error('サーバーへ接続できません');
      const res=await client.rpc('exchange_spirit_flower_sr',{p_exchange_id:exchangeId});
      if(res&&res.error)throw res.error;
      let data=res&&res.data; if(typeof data==='string')data=JSON.parse(data);
      if(!data||data.ok===false)throw new Error((data&&data.message)||'交換に失敗しました');
      await fetchSnapshot();
      if(typeof window.loadInventoryFromSupabase==='function'){
        const userId=String(localStorage.getItem('zukan_user_id')||'').trim();
        if(userId)try{await window.loadInventoryFromSupabase(userId)}catch(_){}
      }
      render();renderFlowerSRExchange();
      try{window.dispatchEvent(new CustomEvent('sasaphia:growth-resources-changed'))}catch(_){}
      toast('交換しました：'+def.name);
    }catch(err){console.error('[ItemManagement] SR exchange failed',err);toast(err&&err.message||'交換に失敗しました');}
    finally{state.exchanging=false;renderFlowerSRExchange();}
  }
  async function useSRTicket(){
    if(state.exchanging||Number(state.items.sr_guaranteed_ticket||0)<1)return;
    if(!window.confirm('SR確定ガチャTICKETを1枚使って恒常SRを1体獲得しますか？'))return;
    state.exchanging=true;
    try{
      const client=window.zsSupabase;
      if(!client||typeof client.rpc!=='function')throw new Error('サーバーへ接続できません');
      const res=await client.rpc('use_sr_guaranteed_ticket');
      if(res&&res.error)throw res.error;
      let data=res&&res.data;if(typeof data==='string')data=JSON.parse(data);
      if(!data||data.ok===false)throw new Error((data&&data.message)||'チケットを使用できませんでした');
      await fetchSnapshot();
      const userId=String(localStorage.getItem('zukan_user_id')||'').trim();
      if(userId&&typeof window.loadInventoryFromSupabase==='function')try{await window.loadInventoryFromSupabase(userId)}catch(_){}
      render();
      try{window.dispatchEvent(new CustomEvent('sasaphia:growth-resources-changed'))}catch(_){}
      toast(data.converted?'SR確定：'+data.character_name+'（完凸分を聖霊花(SR)へ変換）':'SR確定：'+data.character_name+' を獲得！');
    }catch(err){console.error('[ItemManagement] SR ticket use failed',err);toast(err&&err.message||'チケットを使用できませんでした');}
    finally{state.exchanging=false;render();}
  }

  // build1489: 限定衣装プレビュー（chara_XX_b_cut.webp）。画像が無ければ衣装パネル画像を表示。
  function openSkinPreview(characterId){
    const id=Number(characterId||0);
    if(!id) return;
    const pad=String(id).padStart(2,'0');
    const skin=window.CharacterSkins && typeof window.CharacterSkins.getSkin==='function'
      ? window.CharacterSkins.getSkin(id,'limited_01') : null;
    const chain=['images/chara_'+pad+'_b_cut.webp', skin&&skin.home, skin&&skin.panel, 'images/chara_'+pad+'_b_panel.webp']
      .filter((v,i,a)=>v && a.indexOf(v)===i);
    const c=(Array.isArray(window.CHARACTERS)?window.CHARACTERS:[]).find(x=>x&&Number(x.id)===id);
    const name=(c&&c.name)||'';

    closeSkinPreview();
    const ov=document.createElement('div');
    ov.id='item-skin-preview';
    ov.setAttribute('role','dialog');
    ov.setAttribute('aria-modal','true');
    const skinName=(skin&&skin.name)||'限定衣装';
    ov.setAttribute('aria-label',(name?name+' ':'')+skinName);
    ov.innerHTML=
      '<div class="item-skin-preview-frame">'+
        '<img class="item-skin-preview-img" alt="">'+
        '<div class="item-skin-preview-caption"><small>LIMITED OUTFIT</small><strong>'+escapeHtml(name)+'</strong><span>'+escapeHtml(skinName)+'</span></div>'+
      '</div>'+
      '<button type="button" class="item-skin-preview-close" aria-label="閉じる">×</button>'+
      '<p class="item-skin-preview-hint">タップで閉じる</p>';
    const img=ov.querySelector('.item-skin-preview-img');
    img.onerror=function(){ const next=chain.shift(); if(next) this.src=next; else this.onerror=null; };
    img.src=chain.shift();
    ov.addEventListener('click',closeSkinPreview);
    document.addEventListener('keydown',onSkinPreviewKey);
    document.body.appendChild(ov);
    ov.querySelector('.item-skin-preview-close').focus();
  }
  function onSkinPreviewKey(e){ if(e.key==='Escape') closeSkinPreview(); }
  function closeSkinPreview(){
    const old=document.getElementById('item-skin-preview');
    if(old) old.remove();
    document.removeEventListener('keydown',onSkinPreviewKey);
  }

  function bind(){
    document.querySelectorAll('#screen-item .item-category-tab').forEach(btn=>{
      btn.addEventListener('click',()=>{
        const next=btn.dataset.itemTab;
        state.tab=(next==='level'||next==='other') ? next : 'evolution';
        const list=document.getElementById('item-management-list');
        if(list) list.scrollTop=0;
        render();
      });
    });

    const list=document.getElementById('item-management-list');
    if(list){
      list.addEventListener('click',e=>{
        const sellBtn=e.target.closest('[data-sell-item]');
        if(sellBtn && !sellBtn.disabled){
          openSell(sellBtn.dataset.sellItem);
          return;
        }
        const exchangeOpen=e.target.closest('[data-open-flower-exchange]');
        if(exchangeOpen && !exchangeOpen.disabled){
          openFlowerExchange();
          return;
        }
        if(e.target.closest('[data-open-flower-sr-exchange]')){openFlowerSRExchange();return;}
        const ticketBtn=e.target.closest('[data-use-other-ticket]');
        if(ticketBtn && !ticketBtn.disabled){
          const id=ticketBtn.dataset.useOtherTicket;
          if(id==='sr_guaranteed_ticket'){useSRTicket();return;}
          if(id==='special_stage_ticket'){
            if(typeof window.openNoahPiecePanel==='function') window.openNoahPiecePanel();
            else toast('特別巡行「楽園 -ノア-」から使用できます');
            return;
          }
          if(id==='tower_limited_ten_ticket'){
            // チケットは限定邂逅の10連実行時に消費する。ここでは邂逅へ移動するだけ。
            if(typeof window.showMainTab==='function') window.showMainTab('summon');
            else toast('限定邂逅の10連から使用できます');
            return;
          }
          if(window.ItemTickets){
            ticketBtn.disabled=true;
            Promise.resolve(window.ItemTickets.useFromItemScreen(id))
              .catch(err=>{console.error('[ItemManagement] ticket use failed',err);toast('チケットを使用できませんでした');})
              .finally(()=>{ if(!state.loading) refresh(); });
          }
          return;
        }
      });
    }

    const exchangeList=document.getElementById('spirit-flower-exchange-list');
    if(exchangeList){
      exchangeList.addEventListener('click',e=>{
        const preview=e.target.closest('[data-skin-preview]');
        if(preview){ openSkinPreview(Number(preview.dataset.skinPreview)); return; }
        const btn=e.target.closest('[data-flower-exchange-id]');
        if(btn && !btn.disabled) exchangeFlowerR(btn.dataset.flowerExchangeId);
      });
      exchangeList.addEventListener('keydown',e=>{
        if(e.key!=='Enter' && e.key!==' ') return;
        const preview=e.target.closest('[data-skin-preview]');
        if(preview){ e.preventDefault(); openSkinPreview(Number(preview.dataset.skinPreview)); }
      });
    }

    const refreshBtn=document.getElementById('item-refresh-btn');
    if(refreshBtn) refreshBtn.addEventListener('click',refresh);

    document.querySelectorAll('[data-item-sell-close]').forEach(el=>el.addEventListener('click',closeSell));
    document.querySelectorAll('[data-flower-exchange-close]').forEach(el=>el.addEventListener('click',closeFlowerExchange));

    const minus=document.getElementById('item-sell-minus');
    const plus=document.getElementById('item-sell-plus');
    const max=document.getElementById('item-sell-max');
    const qty=document.getElementById('item-sell-qty');
    const confirm=document.getElementById('item-sell-confirm');

    if(minus) minus.addEventListener('click',()=>{state.sellQty--;updateSellUI();});
    if(plus) plus.addEventListener('click',()=>{state.sellQty++;updateSellUI();});
    if(max) max.addEventListener('click',()=>{
      if(state.sellItemId) state.sellQty=getSellMeta(state.sellItemId).owned;
      updateSellUI();
    });
    if(qty){
      qty.addEventListener('input',()=>{
        state.sellQty=Math.floor(Number(qty.value)||1);
        updateSellUI();
      });
    }
    if(confirm) confirm.addEventListener('click',sell);

    window.addEventListener('sasaphia:growth-resources-changed',()=>{
      if(document.getElementById('screen-item')?.classList.contains('active')) refresh();
    });
    window.addEventListener('zeraphia:skins-loaded',()=>{
      const modal=document.getElementById('spirit-flower-exchange-modal');
      if(modal && !modal.hidden) renderFlowerExchange();
    });
    window.addEventListener('zeraphia:skin-changed',()=>{
      const modal=document.getElementById('spirit-flower-exchange-modal');
      if(modal && !modal.hidden) renderFlowerExchange();
    });
  }


  /* ---------------------------------------------------------
     Gacha excess-copy conversion display bridge
     Server draw_gacha() returns flower_r / flower_sr as
     material results when effective ownership is already 5/5.
     --------------------------------------------------------- */
  const OTHER_GACHA_REWARDS = {
    flower_r:{
      name:'聖霊花(R)',
      img:'images/item_flower_r.webp',
      rarity:'r',
      itemCategory:'exchange'
    },
    flower_sr:{
      name:'聖霊花(SR)',
      img:'images/item_flower_sr.webp',
      rarity:'sr',
      itemCategory:'exchange'
    }
  };

  const originalGetGachaMaterialRewardData =
    typeof window.getGachaMaterialRewardData==='function'
      ? window.getGachaMaterialRewardData
      : null;

  if(originalGetGachaMaterialRewardData){
    window.getGachaMaterialRewardData=function(materialId,count,timeStr,capturedAt){
      const id=String(materialId||'');
      const other=OTHER_GACHA_REWARDS[id];

      if(other){
        const n=Math.max(1,Number(count||1));
        return {
          resultKind:'material',
          materialId:id,
          itemCount:n,
          id:'material_'+id,
          name:other.name,
          img:other.img,
          upImg:other.img,
          cutImg:other.img,
          element:'',
          baseStats:{},
          stats:{},
          limitBreak:0,
          rarity:other.rarity,
          hasRarity:false,
          isNew:false,
          itemCategory:other.itemCategory,
          time:timeStr||new Date().toLocaleString(),
          capturedAt:capturedAt||new Date().toISOString()
        };
      }

      return originalGetGachaMaterialRewardData.apply(this,arguments);
    };
  }

  window.ItemManagement={
    refresh,
    getCount:function(itemId){
      const id=String(itemId||'');
      if(id==='special_stage_ticket') return state.specialStageTicket;
      return Math.max(0,Math.floor(Number(state.items[id]||0)));
    }
  };

  window.openItemScreen=function(){
    if(typeof window.showMainTab==='function'){
      window.showMainTab('item');
      if(typeof window.setBnavActive==='function') window.setBnavActive('main');
    }

    // Only the material list scrolls. Always enter that viewport at its top.
    const list=document.getElementById('item-management-list');
    if(list){
      list.scrollTop=0;
      requestAnimationFrame(()=>{ list.scrollTop=0; });
    }

    setTimeout(()=>{
      const current=document.getElementById('item-management-list');
      if(current) current.scrollTop=0;
      refresh();
    },0);
  };

  window.refreshItemManagement=refresh;

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',bind,{once:true});
  }else{
    bind();
  }
})();
