// Zeraphia Shooting Resonance
// シューティング専用共鳴マスター。
// Strategy / Battle32 / LINK / moveType / combo / range には一切依存しない。
(function () {
  'use strict';

  const MAX_LEVEL = 4;

  // 強化素材はゲーム共通の育成資産として継続利用する。
  const MATERIAL_STORAGE_KEY = 'zeraphia_evolution_materials_v1';

  const MATERIAL_MASTER = Object.freeze({
    memory_fragment: Object.freeze({
      id: 'memory_fragment', name: '記憶の欠片', shortName: '記憶の欠片',
      img: 'images/item_wing.webp',
      desc: 'ストーリーで仲間になるキャラクター共通の限界突破素材。'
    }),
    kyoumei_stone: Object.freeze({
      id: 'kyoumei_stone',
      name: '共鳴石',
      shortName: '共鳴石',
      img: 'images/item_kyoumeistone.webp',
      desc: 'プリモアの魂を同調させる神秘的な石。'
    }),
    soul_vessel_fire: Object.freeze({
      id: 'soul_vessel_fire',
      name: '魂の器(火)',
      shortName: '魂の器(火)',
      img: 'images/item_soul_vessel_fire.webp',
      element: 'fire',
      desc: '火属性の魂を受け止める神具。'
    }),
    soul_vessel_aqua: Object.freeze({
      id: 'soul_vessel_aqua',
      name: '魂の器(水)',
      shortName: '魂の器(水)',
      img: 'images/item_soul_vessel_aqua.webp',
      element: 'aqua',
      desc: '水属性の魂を受け止める神具。'
    }),
    soul_vessel_wood: Object.freeze({
      id: 'soul_vessel_wood',
      name: '魂の器(木)',
      shortName: '魂の器(木)',
      img: 'images/item_soul_vessel_wood.webp',
      element: 'wood',
      desc: '木属性の魂を受け止める神具。'
    }),
    soul_vessel_dark: Object.freeze({
      id: 'soul_vessel_dark',
      name: '魂の器(闇)',
      shortName: '魂の器(闇)',
      img: 'images/item_soul_vessel_dark.webp',
      element: 'dark',
      desc: '闇属性の魂を受け止める神具。'
    }),
    soul_vessel_light: Object.freeze({
      id: 'soul_vessel_light',
      name: '魂の器(光)',
      shortName: '魂の器(光)',
      img: 'images/item_soul_vessel_light.webp',
      element: 'light',
      desc: '光属性の魂を受け止める神具。'
    }),
    seihai: Object.freeze({
      id: 'seihai',
      name: '聖なる盃',
      shortName: '聖なる盃',
      img: 'images/item_seihai.webp',
      desc: '神聖な力を湛えた進化用素材。'
    }),
    overseer_blk_core: Object.freeze({
      id: 'overseer_blk_core',
      name: '竜型レムナント亜種の心核',
      shortName: '亜種の心核',
      img: 'images/item_overseer_blk_core.webp',
      desc: '竜型レムナント亜種から回収された異質な心核。今後の特殊強化に使用する素材。'
    })
  });

  // effect type
  // statRate:          hp / atk の基礎値へ加算倍率
  // profileMultiply:   SHOOTING_CHARACTERS の数値フィールドへ乗算
  // profileSet:        数値/設定を指定値へ変更
  // profileAdd:        数値フィールドへ加算
  //
  // Lv1〜現在Lvまでを順番に累積適用する。
  const BONUS_MASTER = Object.freeze({
    1: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +5%', '基礎HPとATKが5%上昇する。', [
        { type:'statRate', hp:0.05, atk:0.05 }
      ]),
      2: bonus('閃光増幅', '通常射撃ダメージ +8%', '通常射撃の1Hitダメージを8%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.08 }
      ]),
      3: bonus('共鳴加速', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('三重閃光', '通常射撃 2発 → 3発', '通常射撃の同時発射数が3発になる。', [
        { type:'profileAdd', field:'shotCount', add:1 }
      ])
    }),

    26: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', '基礎HPとATKが4%上昇する。', [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('夢弾深化', '通常射撃ダメージ +10%', '通常射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('夢域同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('深層睡眠', 'ULTスタン 5秒 → 6.5秒', '「どりいむたいむ」のスタン時間を6.5秒へ延長する。', [
        { type:'profileSet', field:'ultStunMs', value:6500 }
      ])
    }),

    31: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', '基礎HPとATKが4%上昇する。', [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('星光増幅', '通常射撃ダメージ +10%', '通常射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('星環同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('星環深化', 'ULTダメージ ATK×3.0 → ×4.0', '4秒の時計演出・全回復・敵弾消去はそのまま、ULTダメージだけをATK×4.0へ強化する。', [
        { type:'profileSet', field:'ultDamageAtkMultiplier', value:4.0 }
      ])
    }),

    20: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', '基礎HPとATKが4%上昇する。', [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('瞬迅増幅', '通常射撃ダメージ +10%', '通常射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('千刻加速', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      // build1672: 持続延長（斬撃回数が1.6倍になり強すぎた）→ 斬撃回数の上限を増やす（最大ATK×4.55→×5.6）
      4: bonus('千ノ刻・極', 'ULT斬撃 最大13回 → 16回', 'ULT「瞬迅・千ノ刻」で出せる斬撃の最大回数を13回から16回へ増やす。', [
        { type:'profileSet', field:'arnoSlashMaxHits', value:16 }
      ])
    }),

    27: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', '基礎HPとATKが4%上昇する。', [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('遊戯増幅', '通常射撃ダメージ +10%', '通常射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('空想同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      // build1668: ULT刷新（HPなし・4秒）に合わせて、散弾ダメージ+40%・持続5秒に変更
      4: bonus('終わらない遊戯', '散弾ダメージ +40%・持続5秒', 'デコイの散弾ダメージを40%強化し、持続時間を4秒から5秒へ延長する。', [
        { type:'profileMultiply', field:'decoyBulletDamage', multiplier:1.40 },
        { type:'profileSet', field:'decoyDurationMs', value:5000 }
      ])
    }),

    6: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', '基礎HPとATKが4%上昇する。', [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('猛炎増幅', 'レーザーダメージ +10%', '通常レーザーのダメージを10%強化する。', [
        { type:'profileMultiply', field:'laserDamageAtkRate', multiplier:1.10 }
      ]),
      3: bonus('火勢同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('灼熱連鎖', '燃焼ダメージ +25%・持続6秒', '燃焼1Tickのダメージを25%強化し、持続時間を5秒から6秒へ延長する。', [
        { type:'profileMultiply', field:'burnDamageAtkRate', multiplier:1.25 },
        { type:'profileSet', field:'burnDurationMs', value:6000 }
      ])
    }),

    9: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', '基礎HPとATKが4%上昇する。', [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('種子増幅', '種弾ダメージ +10%', '通常の種弾ダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('花園同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('満開の心', 'ハート回復・ダメージ +25%', 'ULTのハートによる回復量と敵へのダメージを25%強化する。', [
        { type:'profileMultiply', field:'flowerHeartHealAmount', multiplier:1.25 },
        { type:'profileMultiply', field:'flowerHeartDamageAtkRate', multiplier:1.25 }
      ])
    }),
    // build974: 専用定義がないキャラクターも全員Lv1〜Lv4まで基本共鳴を持つ。
    3: genericSet('アウラ'),
    5: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', '基礎HPとATKが4%上昇する。', [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('閃光増幅', '通常射撃ダメージ +10%', '通常射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('光路同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('SCRAMBLE RAY・極', 'ULTレーザー 6本 → 9本', 'ULT「SCRAMBLE RAY」で同時展開する閃光レーザーを9本へ増加する。', [
        { type:'profileSet', field:'jigUltBeamCount', value:9 }
      ])
    }),
    10: genericSet('オリオン'),
    12: genericSet('シイナ'),
    17: genericSet('アイナ'),
    18: genericSet('シオン'),
    19: genericSet('ラグナ'),
    22: genericSet('ベロニカ'),
    23: genericSet('セレナ'),
    24: genericSet('ノエル'),
    25: genericSet('リュネ'),
    30: genericSet('リズ'),
    32: genericSet('ルナティア'),
    33: genericSet('レイ'),
    34: genericSet('グレシャ'),
    35: genericSet('ジゼル'),
    36: genericSet('ニーナ'),
    37: genericSet('トイフェル'),
    38: genericSet('クロエ'),
    // build1639: レオナクロス専用。Lv3でTRAPの爆発範囲が大きく広がり、使用感が変わる。
    39: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%\nTRAP起爆 3秒→2秒', 'レオナクロスの基礎HPとATKが4%上昇し、TRAPが設置から2秒で爆発するようになる。', [
        { type:'statRate', hp:0.04, atk:0.04 },
        { type:'profileSet', field:'trapCountdownMs', value:2000 }
      ]),
      2: bonus('射撃増幅', '通常攻撃ダメージ +30%', 'TRAPの通常攻撃ダメージを30%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.30 }
      ]),
      3: bonus('広域起爆', 'TRAP爆発範囲 150%', 'TRAPの爆発範囲を1.5倍に拡大する。', [
        { type:'profileMultiply', field:'trapExplosionRadius', multiplier:1.50 }
      ]),
      4: bonus('深層同調', 'ULTゲージ獲得量 +20%\nTRAP設置数 3→4', '命中時のULTゲージ獲得量を20%増加し、同時に置けるTRAPが4個になる。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.20 },
        { type:'profileSet', field:'trapMaxPlaced', value:4 }
      ])
    }),
    40: genericSet('オリビア'),

    28: genericSet('ミモザ'),
    16: genericSet('パトラ'),
    15: genericSet('アリス'),
    13: genericSet('シグレ'),

    4: Object.freeze({
      1: bonus('疾風の共鳴', 'ATK +5%', '基礎ATKが5%上昇する。', [
        { type:'statRate', hp:0, atk:0.05 }
      ]),
      2: bonus('雷光増幅', '通常射撃ダメージ +8%', '通常射撃の1Hitダメージを8%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.08 }
      ]),
      3: bonus('月光同調', 'ULTゲージ獲得量 +12%', '命中時のULTゲージ獲得量を12%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.12 }
      ]),
      4: bonus('雷光巡行・極', 'ULT中の連射性能 約15%強化', 'ULT中の射撃間隔をさらに約15%短縮する。', [
        { type:'profileMultiply', field:'moonlightFireRateMultiplier', multiplier:0.85 }
      ])
    }),
    14: genericSet('ミア'),

    11: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', '基礎HPとATKが4%上昇する。', [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('精密増幅', '通常射撃ダメージ +10%', '通常射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('暴走同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('臨界射撃', '4発ごとの強化弾 ×1.65 → ×2.0', '4発ごとに放つ強化弾の威力倍率を2.0へ強化する。', [
        { type:'profileSet', field:'chargedPowerMultiplier', value:2.0 }
      ])
    }),

    29: Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', '基礎HPとATKが4%上昇する。', [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('重力増幅', '通常射撃ダメージ +10%', '通常射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('事象同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('事象深淵', 'ブラックホール10秒・吸引力強化', 'ブラックホール持続時間を8秒から10秒へ延長し、吸引力を20%強化する。', [
        { type:'profileSet', field:'blackHoleDurationMs', value:10000 },
        { type:'profileMultiply', field:'blackHolePullStrength', multiplier:1.20 }
      ])
    }),
    7: genericSet('ミト'),
    21: genericSet('アンジェ'),

    2: Object.freeze({
      1: bonus('狩狼の共鳴', 'HP・ATK +5%', 'ウルフの基礎HPとATKが5%上昇する。', [
        { type:'statRate', hp:0.05, atk:0.05 }
      ]),
      2: bonus('追牙増幅', '通常射撃ダメージ +10%', 'J字ホーミング射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('狩場同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('深月の領域', 'ATK UP 1.5倍 → 1.65倍', 'ULTで展開するATK UPフィールドの倍率を1.65倍へ強化する。', [
        { type:'profileSet', field:'ultFieldAtkMultiplier', value:1.65 }
      ])
    }),

    50: Object.freeze({
      1: bonus('艦砲同調', 'ATK +5%', 'テストの基礎ATKが5%上昇する。', [
        { type:'statRate', hp:0, atk:0.05 }
      ]),
      2: bonus('Vレーザー増幅', '通常射撃ダメージ +10%', 'Vレーザーの1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'laserDamageAtkRate', multiplier:1.10 }
      ]),
      3: bonus('ブラックシップ同調', 'ULTゲージ獲得量 +15%', '命中時のULTゲージ獲得量を15%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.15 }
      ]),
      4: bonus('ブラックシップ・フルストライク', 'ULT落雷 ATK×2.8 → ×3.5', 'ULT「ブラックシップ・ストライク」の落雷1発のダメージをATK×2.8からATK×3.5へ強化する。', [
        { type:'profileSet', field:'ninaUltHitAtkMultiplier', value:3.5 }
      ])
    }),

    8: Object.freeze({
      1: bonus('紅月覚醒', 'HP・ATK +5%', 'シュリの基礎HPとATKが5%上昇する。', [
        { type:'statRate', hp:0.05, atk:0.05 }
      ]),
      2: bonus('緋月深化', '通常射撃ダメージ +12%', '紅黒の5WAY気弾の1Hitダメージを12%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.12 }
      ]),
      3: bonus('彼岸収束', 'ULT吸引力 +25%', '「彼岸残月」の吸引力を25%強化し、敵をより素早く波動中心へ引き寄せる。', [
        { type:'profileMultiply', field:'gojoPurplePullStrength', multiplier:1.25 }
      ]),
      4: bonus('残月極致', 'ULT ATK×3.5 → ×4.5', '「彼岸残月」の吸引・停止時間はそのまま、継続ダメージ総量をATK×3.5からATK×4.5へ強化する。', [
        { type:'profileSet', field:'ultDamageAtkMultiplier', value:4.5 }
      ])
    }),

    101: Object.freeze({
      1: bonus('常闇の器', 'HP +10%', 'トワの最大HPが10%上昇する。', [
        {type:'statRate', hp:0.10, atk:0}
      ]),
      2: bonus('黒き加護', 'ATK +10%', 'トワのATKが10%上昇する。', [
        {type:'statRate', hp:0, atk:0.10}
      ]),
      3: bonus('深淵の奔流', 'CHARGE M → CHARGE L', '通常ショットがCHARGE Lになり、威力・サイズ・破裂範囲もL規格へ強化される。', [
        {type:'chargeSize', value:'L'}
      ]),
      4: bonus('永劫の常闇', 'ULT 5秒 → 7秒', '「常闇」の暗転・弾生成停止時間を7秒へ延長する。', [
        {type:'profileSet', field:'towaDarkDurationMs', value:7000}
      ])
    }),

    52: Object.freeze({
      1: bonus('理想の共鳴', 'HP・ATK +5%', 'ノアの基礎HPとATKが5%上昇する。', [
        { type:'statRate', hp:0.05, atk:0.05 }
      ]),
      2: bonus('灰白星路', 'レーザー・波動弾 +10%', '通常射撃の中心レーザーと2発の波動ホーミング弾をそれぞれ10%強化する。', [
        { type:'profileMultiply', field:'laserDamageAtkRate', multiplier:1.10 },
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('停止世界の残光', '落雷ダメージ +15%', '16発の落雷それぞれのダメージを15%強化する。', [
        { type:'profileMultiply', field:'noahUltHitAtkMultiplier', multiplier:1.15 }
      ]),
      4: bonus('完成された理想郷', 'スタン 1.5秒 → 2.2秒', '落雷を受けた敵に発生するスタン時間を2.2秒へ延長する。', [
        { type:'profileSet', field:'noahUltParalyzeMs', value:2200 }
      ])
    })
  });

  function bonus(title, summary, detail, effects) {
    return Object.freeze({
      title: String(title || ''),
      summary: String(summary || ''),
      detail: String(detail || ''),
      effects: Object.freeze((effects || []).map(effect => Object.freeze({ ...effect })))
    });
  }

  // 既存の共通ボーナスはそのまま維持する（元から汎用設定済みのキャラ向け）。
  function genericSet(name) {
    return Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', `${name}の基礎HPとATKが4%上昇する。`, [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('射撃増幅', '通常射撃ダメージ +10%', '通常射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:'shotPowerRate', multiplier:1.10 }
      ]),
      3: bonus('射撃加速', '通常射撃の連射速度 ×1.09', '通常射撃の連射速度を約1.09倍にする。', [
        { type:'profileMultiply', field:'fireRate', multiplier:0.92 }
      ]),
      4: bonus('深層同調', 'ULTゲージ獲得量 +20%', '命中時のULTゲージ獲得量を20%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.20 }
      ])
    });
  }

  // build1319: 新規キャラ向け共通共鳴。固有マスターがあるキャラには一切適用しない。
  // CHARGEの連射間隔は0なのでチャージ時間を、LASERの通常ダメージはレーザー倍率を強化。
  function defaultSet(name, shotType) {
    const shot = String(shotType || '').toLowerCase();
    const charge = shot === 'charge';
    const laser = shot === 'laser';
    const damageField = laser ? 'laserDamageAtkRate' : 'shotPowerRate';
    const speedEffects = charge
      ? [
          { type:'profileMultiply', field:'chargeMinMs', multiplier:0.92 },
          { type:'profileMultiply', field:'chargeMaxMs', multiplier:0.92 }
        ]
      : [{ type:'profileMultiply', field:'fireRate', multiplier:0.92 }];
    return Object.freeze({
      1: bonus('基礎共鳴', 'HP・ATK +4%', `${name}の基礎HPとATKが4%上昇する。`, [
        { type:'statRate', hp:0.04, atk:0.04 }
      ]),
      2: bonus('射撃増幅', '通常射撃ダメージ +10%', '通常射撃の1Hitダメージを10%強化する。', [
        { type:'profileMultiply', field:damageField, multiplier:1.10 }
      ]),
      3: bonus('射撃加速', charge ? 'チャージ時間 -8%' : '通常射撃の連射速度 ×1.09',
        charge ? 'CHARGEの溜め時間を8%短縮する。' : '通常射撃の連射速度を約1.09倍にする。', speedEffects),
      4: bonus('深層同調', 'ULTゲージ獲得量 +20%', '命中時のULTゲージ獲得量を20%増加する。', [
        { type:'profileMultiply', field:'ultGainPerHit', multiplier:1.20 }
      ])
    });
  }

  // build1321: 提供割合は未所持キャラも表示するため、古いキャラマスターが
  // ブラウザに残っていると、新規12体の汎用レゾナンスだけ見えなくなることがあった。
  // build1319で確定済みの12体のみ、表示・効果共通の安全な登録済み情報を保持する。
  // CHARGE / LASER は属性・攻撃方式に合わせたLv.2/Lv.3効果を維持。
  const RECENT_DEFAULT_CHARACTERS = Object.freeze({
    41: Object.freeze({name:'シャオラン',shotType:'spread'}),
    42: Object.freeze({name:'キョウ',shotType:'strike'}),
    43: Object.freeze({name:'スズ',shotType:'parallel'}),
    44: Object.freeze({name:'メロリア',shotType:'piercing'}),
    45: Object.freeze({name:'キリマル',shotType:'spread'}),
    46: Object.freeze({name:'アイレナ',shotType:'charge'}),
    47: Object.freeze({name:'リンリン',shotType:'parallel'}),
    48: Object.freeze({name:'ムゥムゥ',shotType:'orbit'}),
    49: Object.freeze({name:'メグメグ',shotType:'laser'}),
    51: Object.freeze({name:'チャチャ',shotType:'spread'}),
    53: Object.freeze({name:'ルイルイ',shotType:'cluster'}),
    54: Object.freeze({name:'ハオ',shotType:'charge'})
  });
  const AUTO_BONUS_CACHE = Object.create(null);

  function getBonusMaster(characterId) {
    const id = Number(characterId);
    if (!Number.isSafeInteger(id) || id <= 0) return null;
    // 既存42体の固有効果・設定済み汎用効果は必ず優先し、変更しない。
    if (Object.prototype.hasOwnProperty.call(BONUS_MASTER, id)) return BONUS_MASTER[id];

    const registry = window.ShootingCharacters;
    const master = registry && typeof registry.getShootingCharacterMaster === 'function'
      ? registry.getShootingCharacterMaster(id) : null;
    const profile = registry && registry.SHOOTING_CHARACTERS
      ? registry.SHOOTING_CHARACTERS[id] : null;
    const known = RECENT_DEFAULT_CHARACTERS[id] || null;
    // 未登録IDまでレゾナンスを作ることはしない。
    if (!master && !known) return null;
    if (!AUTO_BONUS_CACHE[id]) {
      AUTO_BONUS_CACHE[id] = defaultSet(
        String((master && master.name) || (known && known.name) || `No.${id}`),
        (profile && profile.shotType) || (known && known.shotType) || ''
      );
    }
    return AUTO_BONUS_CACHE[id];
  }

  function getBonus(characterId, level) {
    const master = getBonusMaster(characterId);
    return master ? master[Math.max(1, Math.min(MAX_LEVEL, Number(level || 1)))] || null : null;
  }

  function getUnlockedBonuses(characterId, level) {
    const master = getBonusMaster(characterId);
    if (!master) return [];
    const current = Math.max(0, Math.min(MAX_LEVEL, Number(level || 0)));
    const result = [];
    for (let lv = 1; lv <= current; lv++) {
      if (master[lv]) result.push(master[lv]);
    }
    return result;
  }

  function applyEffect(profile, effect) {
    if (!profile || !effect) return;

    switch (effect.type) {
      case 'statRate': {
        if (Number.isFinite(Number(profile.hp))) {
          profile.hp = Math.floor(Number(profile.hp) * (1 + Number(effect.hp || 0)));
        }
        if (Number.isFinite(Number(profile.atk))) {
          profile.atk = Math.floor(Number(profile.atk) * (1 + Number(effect.atk || 0)));
        }
        break;
      }

      case 'profileMultiply': {
        const field = String(effect.field || '');
        if (!field || !Number.isFinite(Number(profile[field]))) break;
        profile[field] = Number(profile[field]) * Number(effect.multiplier || 1);
        break;
      }

      case 'profileSet': {
        const field = String(effect.field || '');
        if (!field) break;
        profile[field] = effect.value;
        break;
      }

      case 'chargeSize': {
        // Keep numeric CHARGE damage/area parameters and the shot icon in sync.
        const size = String(effect.value || 'M').toUpperCase() === 'L' ? 'L' : 'M';
        const preset = window.ShootingCharacters?.CHARGE_SIZE_PRESETS?.[size];
        if (profile.shotType !== 'charge' || !preset) break;
        Object.assign(profile, preset);
        profile.chargeSize = size;
        profile.mainShot = { ...(profile.mainShot || {}), type:'charge', size };
        break;
      }
      case 'profileAdd': {
        const field = String(effect.field || '');
        if (!field || !Number.isFinite(Number(profile[field]))) break;
        profile[field] = Number(profile[field]) + Number(effect.add || 0);
        break;
      }
    }
  }

  function applyToProfile(baseProfile, level) {
    if (!baseProfile) return null;

    // 現状のshooting profileはprimitive中心なので浅いcloneで独立できる。
    // uiScaleだけは明示cloneして共有参照を避ける。
    const profile = {
      ...baseProfile,
      uiScale: baseProfile.uiScale ? { ...baseProfile.uiScale } : {}
    };

    const bonuses = getUnlockedBonuses(profile.id, level);
    bonuses.forEach(b => b.effects.forEach(effect => applyEffect(profile, effect)));

    profile.resonanceLevel = Math.max(0, Math.min(MAX_LEVEL, Number(level || 0)));
    return profile;
  }

  window.ShootingResonance = Object.freeze({
    MAX_LEVEL,
    MATERIAL_STORAGE_KEY,
    MATERIAL_MASTER,
    BONUS_MASTER,
    getBonusMaster,
    getBonus,
    getUnlockedBonuses,
    applyToProfile
  });
})();
