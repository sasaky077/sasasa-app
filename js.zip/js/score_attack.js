/* Sasaphia - SCORE ATTACK / すこあた！ */
(function(){
'use strict';
const STAGES={normal:'shooting_score_attack_normal',hard:'shooting_score_attack_hard'};
const PANEL_MAP={"1": "images/chara_01_panel.webp", "2": "images/chara_02_panel.webp", "3": "images/chara_03_panel.webp", "4": "images/chara_04_panel.webp", "5": "images/chara_05_panel.webp", "6": "images/chara_06_panel.webp", "7": "images/chara_07_panel.webp", "8": "images/chara_08_panel.webp", "9": "images/chara_09_panel.webp", "10": "images/chara_10_panel.webp", "11": "images/chara_11_panel.webp", "12": "images/chara_12_panel.webp", "13": "images/chara_13_panel.webp", "14": "images/chara_14_panel.webp", "15": "images/chara_15_panel.webp", "16": "images/chara_16_panel.webp", "17": "images/chara_17_panel.webp", "50": "images/chara_50_panel.webp"};
let currentDifficulty='normal',currentRankingScope='friends',root=null,currentAttemptId=null,rankingRequestSeq=0;
const rankingCache=Object.create(null);
function uid(){return String(localStorage.getItem('zukan_user_id')||'').trim().toLowerCase();}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function playerName7(v){
 const s=String(v==null?'':v).trim()||'Player';
 return Array.from(s).slice(0,7).join('');
}
function panelSrc(id){
 id=Number(id||0);
 if(!id)return '';
 try{
  const m=window.ShootingCharacters&&window.ShootingCharacters.SHOOTING_CHARACTER_MASTER;
  if(m&&m[id]&&m[id].panelImage)return m[id].panelImage;
 }catch(_){}
 // build530: score attack may render before ShootingCharacters is ready.
 // Party IDs are character IDs, so derive the canonical panel path directly.
 return PANEL_MAP[id]||('images/chara_'+String(id).padStart(2,'0')+'_panel.webp');
}
function partyHtml(ids,large){const a=Array.isArray(ids)?ids.slice(0,3):[];while(a.length<3)a.push(0);return '<div class="score-attack-party'+(large?' is-large':'')+'">'+a.map(id=>{const src=panelSrc(id);return src?'<span><img src="'+esc(src)+'" alt="" draggable="false"></span>':'<span class="empty"></span>';}).join('')+'</div>';}
function ensureRoot(){
 if(root && root.isConnected && root.dataset.scoreAttackUi==='694')return root;
 // build694: if an older SCORE ATTACK DOM survived an asset update/BFCache restore,
 // discard it before rendering the current markup. This prevents old FRIEND/全国
 // controls from mixing with the new navigation CSS.
 const stale=document.getElementById('score-attack-root');
 if(stale)stale.remove();
 root=document.createElement('div');
 root.id='score-attack-root';
 root.className='app-page app-page--overlay score-attack-app-page';
 root.dataset.scoreAttackUi='694';
 root.setAttribute('aria-hidden','true');
 root.innerHTML=`<div class="score-attack-page app-page-surface">
 <div class="score-attack-bg-deco score-attack-bg-deco-a" aria-hidden="true"></div>
 <div class="score-attack-bg-deco score-attack-bg-deco-b" aria-hidden="true"></div>

 <header class="app-page-header score-attack-head">
   <button type="button" class="app-page-back" onclick="closeScoreAttack()">＜戻る</button>
   <div class="app-page-heading">
     <small class="app-page-eyebrow">SCORE ATTACK</small>
     <h1 class="app-page-title">スコアアタック</h1>
   </div>
   <div class="app-page-action score-attack-head-mark" aria-hidden="true"></div>
 </header>

 <div class="app-page-content score-attack-scroll">

  <section class="score-attack-ranking score-attack-ranking-first" data-ranking-scope="friends">
    <div class="score-attack-ranking-nav" aria-label="ランキング切替">
      <button id="score-attack-swipe-prev" type="button" class="score-attack-swipe-cue is-prev" aria-label="フレンドランキングへ" onclick="setScoreAttackRankingScope('friends')">‹</button>
      <strong id="score-attack-ranking-title">フレンドランキング</strong>
      <button id="score-attack-swipe-next" type="button" class="score-attack-swipe-cue is-next" aria-label="全国ランキングへ" onclick="setScoreAttackRankingScope('national')">›</button>
    </div>
    <div id="score-attack-list" class="score-attack-list"><div class="score-attack-loading">読み込み中...</div></div>
  </section>

  <section class="score-attack-mode-card">
    <div class="score-attack-mode-head">
      <div>
        <small>DIFFICULTY</small>
        <strong>難易度を選択</strong>
      </div>
    </div>
    <div class="score-attack-tabs">
      <button id="score-attack-tab-normal" class="active" onclick="setScoreAttackDifficulty('normal')">
        <small>NORMAL</small>
      </button>
      <button id="score-attack-tab-hard" onclick="setScoreAttackDifficulty('hard')">
        <small>HARD</small>
      </button>
    </div>
  </section>

  <section class="score-attack-me score-attack-start-only">
    <button type="button" class="score-attack-start" onclick="startScoreAttack()">
      <span>挑戦する</span>
    </button>
  </section>

 </div></div>`;
 document.body.appendChild(root);
 installRankingSwipe(root);
 updateRankingScopeUi();
 return root;
}
function rankingKey(scope){return currentDifficulty+':'+scope;}
async function fetchRanking(scope){
 const sb=window.zsSupabase,userId=uid();
 if(!sb||typeof sb.rpc!=='function'||!userId)return[];
 const isNational=scope==='national';
 const rpcName=isNational?'get_score_attack_national_ranking':'get_score_attack_friend_ranking';
 const args=isNational
   ? {p_difficulty:currentDifficulty}
   : {p_user_id:userId,p_difficulty:currentDifficulty};
 const res=await sb.rpc(rpcName,args);
 if(res&&res.error)throw res.error;
 return Array.isArray(res&&res.data)?res.data:[];
}
function updateRankingScopeUi(){
 const r=ensureRoot();
 const national=currentRankingScope==='national';
 const section=r.querySelector('.score-attack-ranking');
 const title=r.querySelector('#score-attack-ranking-title');
 const prevCue=r.querySelector('#score-attack-swipe-prev');
 const nextCue=r.querySelector('#score-attack-swipe-next');
 if(section)section.setAttribute('data-ranking-scope',national?'national':'friends');
 if(title)title.textContent=national?'全国ランキング':'フレンドランキング';
 if(prevCue){prevCue.disabled=!national;prevCue.setAttribute('aria-disabled',!national?'true':'false');}
 if(nextCue){nextCue.disabled=national;nextCue.setAttribute('aria-disabled',national?'true':'false');}
}
function animateRankingSwap(direction){
 const list=ensureRoot().querySelector('#score-attack-list');
 if(!list)return;
 list.classList.remove('swipe-from-left','swipe-from-right');
 void list.offsetWidth;
 list.classList.add(direction==='right'?'swipe-from-left':'swipe-from-right');
 setTimeout(()=>list.classList.remove('swipe-from-left','swipe-from-right'),280);
}
function installRankingSwipe(r){
 const section=r.querySelector('.score-attack-ranking');
 if(!section||section.dataset.swipeReady==='1')return;
 section.dataset.swipeReady='1';
 let sx=0,sy=0;
 section.addEventListener('touchstart',ev=>{
   const t=ev.touches&&ev.touches[0];
   if(!t)return;
   sx=t.clientX;sy=t.clientY;
 },{passive:true});
 section.addEventListener('touchend',ev=>{
   const t=ev.changedTouches&&ev.changedTouches[0];
   if(!t)return;
   const dx=t.clientX-sx,dy=t.clientY-sy;
   if(Math.abs(dx)<46||Math.abs(dx)<=Math.abs(dy)*1.15)return;
   if(dx<0&&currentRankingScope==='friends')window.setScoreAttackRankingScope('national');
   else if(dx>0&&currentRankingScope==='national')window.setScoreAttackRankingScope('friends');
 },{passive:true});
}
function renderRows(rows,scope){
 const r=ensureRoot(),myId=uid(),list=r.querySelector('#score-attack-list');
 const isNational=scope==='national';

 if(!rows.length){
   list.innerHTML='<div class="score-attack-empty">'+(isNational?'全国ランキングに記録がありません':'まだ記録がありません')+'</div>';
   return;
 }

 const TOP_COUNT=isNational?20:5;
 const html=rows.map((row,i)=>{
   const me=String(row.user_id||'').toLowerCase()===myId;
   const rank=Number(row.rank_no||i+1);
   const extra=(!isNational&&i>=TOP_COUNT)?' score-attack-row-extra':'';
   return '<div class="score-attack-row'+(me?' is-me':'')+extra+'">'+
     '<span class="score-attack-rank-no">'+rank+'</span>'+
     '<div class="score-attack-row-main">'+
       '<b title="'+esc(row.display_name||row.user_id||'Player')+'"><span class="score-attack-player-name">'+esc(playerName7(row.display_name||row.user_id||'Player'))+'</span>'+(me?'<em>自分</em>':'')+'</b>'+
       partyHtml(row.party_ids,false)+
     '</div>'+
     '<strong>'+Number(row.best_score||0).toLocaleString('ja-JP')+'</strong>'+
   '</div>';
 }).join('');

 const moreCount=isNational?0:Math.max(0,rows.length-TOP_COUNT);
 const toggleHtml=moreCount>0
   ? '<button type="button" class="score-attack-more" onclick="toggleScoreAttackRankingMore(this)" aria-expanded="false">'+
       '<span>6位以下を表示</span><small>+'+moreCount+'</small>'+
     '</button>'
   : '';

 list.innerHTML=html+toggleHtml;
}
async function prefetchRanking(scope){
 const key=rankingKey(scope);
 if(rankingCache[key])return;
 try{rankingCache[key]=await fetchRanking(scope);}catch(err){console.warn('[ScoreAttack] ranking prefetch failed',scope,err);}
}
async function refresh(options){
 const opts=options||{};
 const r=ensureRoot(),scope=currentRankingScope,key=rankingKey(scope),list=r.querySelector('#score-attack-list');
 updateRankingScopeUi();
 if(list)list.scrollTop=0;
 if(!opts.force&&rankingCache[key])renderRows(rankingCache[key],scope);
 else if(list)list.innerHTML='<div class="score-attack-loading">読み込み中...</div>';
 const seq=++rankingRequestSeq;
 try{
   const rows=await fetchRanking(scope);
   rankingCache[key]=rows;
   if(seq!==rankingRequestSeq||scope!==currentRankingScope)return;
   renderRows(rows,scope);
 }catch(err){
   console.error('[ScoreAttack] ranking failed',err);
   if(seq!==rankingRequestSeq||scope!==currentRankingScope)return;
   list.innerHTML='<div class="score-attack-empty">ランキングを取得できません。<br>もう一度お試しください。</div>';
 }
}
window.openScoreAttack=function(){
  const r=ensureRoot();
  r.classList.add('show');
  r.setAttribute('aria-hidden','false');

  // UI Foundation v2: Score Attack is a Standard Page.
  // Chrome visibility is controlled by the shared application policy only.
  if(window.setGameChromeImmersive) window.setGameChromeImmersive(false,'score-attack');
  if(window.setNavVisible) window.setNavVisible(true);
  if(window.setBnavActive) window.setBnavActive('main');
  if(typeof window.updateHeaderHeight==='function') window.updateHeaderHeight();
  updateRankingScopeUi();
  refresh();
  void prefetchRanking(currentRankingScope==='friends'?'national':'friends');
};
window.closeScoreAttack=function(){
  const r=ensureRoot();
  r.classList.remove('show');
  r.setAttribute('aria-hidden','true');
  if(window.setNavVisible) window.setNavVisible(true);
};
window.setScoreAttackDifficulty=function(d){
 currentDifficulty=d==='hard'?'hard':'normal';
 const r=ensureRoot();
 r.querySelector('#score-attack-tab-normal').classList.toggle('active',currentDifficulty==='normal');
 r.querySelector('#score-attack-tab-hard').classList.toggle('active',currentDifficulty==='hard');
 refresh({force:true});
 void prefetchRanking(currentRankingScope==='friends'?'national':'friends');
};
window.setScoreAttackRankingScope=function(scope){
 const next=scope==='national'?'national':'friends';
 if(next===currentRankingScope)return;
 const direction=next==='national'?'left':'right';
 currentRankingScope=next;
 updateRankingScopeUi();
 animateRankingSwap(direction);
 refresh();
};
window.toggleScoreAttackRankingMore=function(btn){
 const r=ensureRoot();
 const list=r.querySelector('#score-attack-list');
 if(!list||!btn)return;
 const open=list.classList.toggle('show-all');
 btn.setAttribute('aria-expanded',open?'true':'false');
 const span=btn.querySelector('span');
 if(span)span.textContent=open?'6位以下を閉じる':'6位以下を表示';
};
window.startScoreAttack=async function(){
  const stageId=STAGES[currentDifficulty];
  const sb=window.zsSupabase;
  if(!sb||typeof sb.rpc!=='function'){
    alert('通信準備ができていません。もう一度お試しください。');
    return;
  }

  // build532:
  // この時点ではまだパーティ未選択。
  // attemptは戦闘開始ボタン押下時に実編成で作成する。
  currentAttemptId=null;
  closeScoreAttack();
  if(typeof window.openShootingEvent==='function'){
    window.openShootingEvent({stageId});
  }
};
window.ScoreAttack={
  async beginAttemptForParty(partyIds){
    const sb=window.zsSupabase;
    const ids=(Array.isArray(partyIds)?partyIds:[])
      .map(Number)
      .filter((id,index,arr)=>id>0&&arr.indexOf(id)===index)
      .slice(0,3);

    if(!sb||typeof sb.rpc!=='function'){
      alert('通信準備ができていません。もう一度お試しください。');
      return false;
    }
    if(!ids.length){
      alert('出撃キャラクターを選択してください。');
      return false;
    }

    try{
      const res=await sb.rpc('begin_score_attack_attempt',{
        p_difficulty:currentDifficulty,
        p_party_ids:ids
      });
      if(res&&res.error)throw res.error;

      const data=res&&res.data;
      const attemptId=data&&data.attempt_id;
      if(!attemptId)throw new Error('attempt_id was not returned');

      currentAttemptId=String(attemptId);
      console.log('[ScoreAttack] attempt started:',currentAttemptId,'party=',ids);
      return true;
    }catch(err){
      console.error('[ScoreAttack] begin attempt failed',err);
      alert('スコアアタックを開始できませんでした。通信状況を確認してもう一度お試しください。');
      return false;
    }
  },

  async submitResult(detail){
    if(!detail||!String(detail.stageId||'').startsWith('shooting_score_attack_'))return;

    const sb=window.zsSupabase;
    if(!sb||typeof sb.rpc!=='function'){
      console.error('[ScoreAttack] finish blocked: Supabase is not ready');
      return;
    }

    // 復帰時などattemptが無い場合は、結果に含まれる実編成から復旧を試みる。
    if(!currentAttemptId){
      const ok=await window.ScoreAttack.beginAttemptForParty(detail.partyIds||[]);
      if(!ok){
        console.error('[ScoreAttack] finish blocked: attempt_id is missing');
        return;
      }
    }

    const attemptId=currentAttemptId;
    try{
      const resultPartyIds=(Array.isArray(detail.partyIds)?detail.partyIds:[])
        .map(Number)
        .filter((id,index,arr)=>id>0&&arr.indexOf(id)===index)
        .slice(0,3);

      const res=await sb.rpc('finish_score_attack_attempt_v2',{
        p_attempt_id:attemptId,
        p_score:Math.max(0,Math.floor(Number(detail.score||0))),
        p_party_ids:resultPartyIds
      });
      if(res&&res.error)throw res.error;

      console.log('[ScoreAttack] attempt finished:',attemptId,'party=',resultPartyIds,res&&res.data);
      currentAttemptId=null;
    }catch(err){
      console.error('[ScoreAttack] finish attempt failed',err);
    }
  },
  refresh
};
window.addEventListener('shooting-stage-result',ev=>{const d=ev&&ev.detail;if(d&&String(d.stageId||'').startsWith('shooting_score_attack_'))void window.ScoreAttack.submitResult(d);});
})();
