(()=>{'use strict';
const canvas=document.getElementById('world');
const ctx=canvas.getContext('2d',{alpha:false});
const placeEl=document.getElementById('place');
const questEl=document.getElementById('quest');
const dialog=document.getElementById('dialog');
const speaker=document.getElementById('speaker');
const line=document.getElementById('line');
const overlay=document.getElementById('overlay');
const T=44, MW=27, MH=22;
let W=360,H=640,dpr=1,clock=0,last=0,enabled=false,dialogQueue=[],dialogEnd=null,joystick={x:0,y:0},target=null,toastUntil=0;
let save={x:13.5*T,y:13.5*T,met:false,gate:false,map:'庭園'};
try{const s=JSON.parse(localStorage.getItem('zeraphia_ch10_rpg_demo_v1')||'null');if(s&&Number.isFinite(s.x)&&Number.isFinite(s.y))save={...save,...s};}catch(_){ }
const tileCenter=n=>(n+.5)*T;
const tileIndex=v=>Math.floor(v/T);
const player={x:tileCenter(tileIndex(save.x)),y:tileCenter(tileIndex(save.y)),dir:'down',move:false,animTimer:0,animStepIndex:0};
const TILE_DURATION=.24;
let tileMotion=null;
let map='庭園';
const WALK_SEQUENCE=['idle','walk1','idle','walk2'];
const ANIM_INTERVAL=.13, STEP_BOUNCE_Y=3.5;
const assets={};
for(const dir of ['up','down','left','right']) for(const anim of ['idle','walk1','walk2']){
  const im=new Image(); im.src=`images/chara_01_${dir}_${anim}.webp`; assets[dir+'_'+anim]=im;
}
const zigImage=new Image(); zigImage.src='images/chara_05_front_idle.webp';
const maps={
  '庭園':{ gate:{x:23,y:6}, npc:{x:13,y:9,name:'ジグ',lines:[]}},
  '回廊':{ gate:{x:3,y:11}, npc:{x:14,y:11,name:'残響',lines:['世界は終わったのではない。','……ここから先が、あなたたちの新しい旅になる。']}}
};
const gardenBlocked = new Set();
function addRect(x,y,w,h){ for(let yy=y; yy<y+h; yy++) for(let xx=x; xx<x+w; xx++) gardenBlocked.add(`${xx},${yy}`); }
// outer walk range and decorative obstacles (roughly linked to the visible ruins)
addRect(0,0,MW,5); addRect(0,19,MW,3); addRect(0,0,3,MH); addRect(24,0,3,MH);
addRect(3,8,2,2); addRect(21,8,2,2); addRect(4,15,3,3); addRect(19,15,3,3); addRect(10,11,2,1); addRect(16,13,2,1);
// openings to allow play area.
for(const key of ['13,9']) gardenBlocked.delete(key);
function walkableTile(tx,ty){
  if(map!=='庭園') return tx>=1&&tx<MW-1&&ty>=1&&ty<MH-1;
  if(tx<3||tx>23||ty<5||ty>18) return false;
  if(gardenBlocked.has(`${tx},${ty}`)) return false;
  return true;
}
if(map==='庭園'){
  const cx=tileIndex(player.x), cy=tileIndex(player.y);
  if(!walkableTile(cx,cy) || (cx===maps[map].npc.x && cy===maps[map].npc.y)){
    player.x=tileCenter(13); player.y=tileCenter(13);
  }
}
function resize(){ dpr=Math.min(2,window.devicePixelRatio||1); W=canvas.clientWidth; H=canvas.clientHeight; canvas.width=Math.round(W*dpr); canvas.height=Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0); ctx.imageSmoothingEnabled=true; }
window.addEventListener('resize',resize); resize();
function updateAnimation(vx,vy,dt){
  const moving=Math.hypot(vx,vy)>.001;
  if(!moving){ player.move=false; player.animTimer=0; player.animStepIndex=0; return; }
  player.move=true;
  if(Math.abs(vx)>Math.abs(vy)) player.dir=vx>0?'right':'left'; else player.dir=vy>0?'down':'up';
  player.animTimer+=dt;
  while(player.animTimer>=ANIM_INTERVAL){ player.animTimer-=ANIM_INTERVAL; player.animStepIndex=(player.animStepIndex+1)%WALK_SEQUENCE.length; }
}
function saveNow(){ if(tileMotion) return; try{ localStorage.setItem('zeraphia_ch10_rpg_demo_v1',JSON.stringify({...save,x:player.x,y:player.y,map})); }catch(_){ } }
function pop(msg){ const el=document.getElementById('toast'); el.textContent=msg; el.classList.add('show'); toastUntil=performance.now()+1900; }
function speak(name,lines,onEnd){ dialogQueue=lines.slice(); dialogEnd=onEnd||null; speaker.textContent=name; dialog.hidden=false; nextLine(); }
function nextLine(){ if(dialogQueue.length){ line.textContent=dialogQueue.shift(); return; } dialog.hidden=true; const cb=dialogEnd; dialogEnd=null; if(cb) cb(); }
dialog.addEventListener('click',nextLine);
function nearby(){ const n=maps[map].npc; return Math.abs(tileIndex(player.x)-n.x)+Math.abs(tileIndex(player.y)-n.y)===1; }
function interact(){
  if(!dialog.hidden){ nextLine(); return; }
  if(novel.active){ advanceNovel(); return; }
  if(tileMotion) return;
  const m=maps[map];
  if(nearby()){
    const n=m.npc;
    if(map==='庭園'){
      if(!save.met){ save.met=true; saveNow(); questEl.textContent='目的：北東の光の門へ'; }
      startZigNovel(); return;
    }
    speak(n.name,n.lines); return;
  }
  const dx=player.x-(m.gate.x+.5)*T, dy=player.y-(m.gate.y+.5)*T;
  if(Math.hypot(dx,dy)<T*1.55){ portal(); return; }
  pop('隣のマスから話しかけてください');
}
document.getElementById('action').addEventListener('click',interact);
function portal(){
  if(map==='庭園'){
    map='回廊'; player.x=tileCenter(5); player.y=tileCenter(11); tileMotion=null; updateAnimation(0,0,0);
    placeEl.textContent='忘却の回廊'; questEl.textContent='目的：残響を探す';
    speak('SYSTEM',['新たな場所に到着した。','第十章の探索は、ここから始まる。']);
  }else{
    map='庭園'; player.x=tileCenter(20); player.y=tileCenter(11); tileMotion=null; updateAnimation(0,0,0);
    placeEl.textContent='灰色の庭園'; questEl.textContent='目的：光の門を探す';
  }
  target=null; saveNow();
}
function fieldLayout(){ const step=Math.min(W*.094,H*.036); return { step, originX:W*.505, originY:H*.474 }; }
function screenForTile(worldX,worldY){ const f=fieldLayout(); return { x:f.originX+(worldX-tileCenter(13))/T*f.step, y:f.originY+(worldY-tileCenter(13))/T*f.step }; }
function drawCrack(points,width=2){ ctx.beginPath(); ctx.moveTo(points[0][0],points[0][1]); for(let i=1;i<points.length;i++) ctx.lineTo(points[i][0],points[i][1]); ctx.strokeStyle=`rgba(166,160,170,${0.24+Math.random()*0.06})`; ctx.lineWidth=width; ctx.stroke(); }
function drawBackground(){
  ctx.fillStyle='#efedf2'; ctx.fillRect(0,0,W,H);
  const grad=ctx.createLinearGradient(0,0,0,H); grad.addColorStop(0,'#f1eff4'); grad.addColorStop(1,'#ece8ef'); ctx.fillStyle=grad; ctx.fillRect(0,0,W,H);
  // tiled plaza
  const step=Math.min(W*.17,H*.09);
  ctx.strokeStyle='rgba(174,166,176,.16)'; ctx.lineWidth=1.2;
  for(let y=-1;y<H/step+2;y++) for(let x=-1;x<W/step+2;x++){
    const px=x*step + (y%2?step*.07:0), py=y*step;
    ctx.fillStyle=((x+y)&1)?'rgba(255,255,255,.06)':'rgba(0,0,0,.015)'; ctx.fillRect(px,py,step+1,step+1); ctx.strokeRect(px,py,step+1,step+1);
  }
  // major cracks
  const cracks=[
    [[W*.08,H*.22],[W*.22,H*.28],[W*.18,H*.35],[W*.34,H*.44],[W*.28,H*.60]],
    [[W*.61,H*.18],[W*.53,H*.26],[W*.67,H*.34],[W*.58,H*.45],[W*.74,H*.56],[W*.67,H*.72]],
    [[W*.14,H*.72],[W*.28,H*.66],[W*.43,H*.74],[W*.59,H*.67],[W*.82,H*.76]],
    [[W*.48,H*.36],[W*.42,H*.49],[W*.53,H*.55],[W*.45,H*.66],[W*.55,H*.83]],
    [[W*.74,H*.26],[W*.88,H*.34],[W*.80,H*.46]],
    [[W*.26,H*.49],[W*.16,H*.56],[W*.21,H*.66]],
  ];
  for(const pts of cracks) drawCrack(pts,2.4);
  // compass motif
  ctx.save(); ctx.translate(W*.505,H*.62); ctx.strokeStyle='rgba(176,168,184,.48)'; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(0,-28); ctx.lineTo(16,0); ctx.lineTo(0,28); ctx.lineTo(-16,0); ctx.closePath(); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0,-17); ctx.lineTo(9,0); ctx.lineTo(0,17); ctx.lineTo(-9,0); ctx.closePath(); ctx.stroke(); ctx.restore();
  // decorative arches / columns / rubble
  drawArch(W*.085,H*.55,78,160,true); drawArch(W*.915,H*.63,74,145,false); drawMiniRuins(W*.16,H*.29); drawMiniRuins(W*.83,H*.31); drawColumn(W*.20,H*.72,38,92); drawSmallColumn(W*.81,H*.52); drawRubble(W*.58,H*.34,28); drawRubble(W*.58,H*.50,28); drawRubble(W*.79,H*.68,24);
  // petals
  for(const [x,y,s,a] of [[.17,.39,8,-.35],[.67,.86,8,.15],[.33,.80,7,-.3]]){ ctx.save(); ctx.translate(W*x,H*y); ctx.rotate(a); ctx.fillStyle='rgba(242,221,221,.95)'; ctx.beginPath(); ctx.ellipse(0,0,s*1.3,s*.58,0,0,Math.PI*2); ctx.fill(); ctx.restore(); }
}
function drawArch(x,y,w,h,left){
  ctx.save(); ctx.translate(x,y);
  ctx.fillStyle='#e7e4eb'; ctx.strokeStyle='rgba(166,156,173,.45)'; ctx.lineWidth=2;
  ctx.fillRect(left?0:-w*0.18,-h,w*0.18,h); ctx.strokeRect(left?0:-w*0.18,-h,w*0.18,h);
  ctx.fillRect(left?w*0.6:0,-h*0.86,w*0.18,h*0.86); ctx.strokeRect(left?w*0.6:0,-h*0.86,w*0.18,h*0.86);
  ctx.beginPath(); ctx.arc(left?w*0.39:w*0.39,-h*0.86,w*0.39,Math.PI,0); ctx.stroke();
  ctx.beginPath(); ctx.arc(left?w*0.39:w*0.39,-h*0.86,w*0.34,Math.PI,0); ctx.stroke();
  // banner
  const bx=left?w*0.58:w*0.10; ctx.fillStyle='#8d99ba'; ctx.beginPath(); ctx.moveTo(bx,-h*0.78); ctx.lineTo(bx+w*0.22,-h*0.74); ctx.lineTo(bx+w*0.18,-h*0.18); ctx.lineTo(bx+w*0.07,-h*0.34); ctx.lineTo(bx,-h*0.28); ctx.closePath(); ctx.fill();
  ctx.strokeStyle='rgba(220,204,170,.7)'; ctx.beginPath(); ctx.moveTo(bx+w*.11,-h*0.58); ctx.lineTo(bx+w*.11,-h*0.43); ctx.moveTo(bx+w*.05,-h*0.50); ctx.lineTo(bx+w*.17,-h*0.50); ctx.stroke();
  ctx.restore();
}
function drawMiniRuins(x,y){ ctx.save(); ctx.translate(x,y); ctx.fillStyle='#ece9ef'; ctx.strokeStyle='rgba(166,156,173,.35)'; ctx.lineWidth=1.8; ctx.fillRect(-26,-20,22,32); ctx.strokeRect(-26,-20,22,32); ctx.fillRect(-4,-16,22,28); ctx.strokeRect(-4,-16,22,28); ctx.beginPath(); ctx.arc(-4,-16,11,Math.PI,0); ctx.stroke(); drawRubble(14,14,20); ctx.restore(); }
function drawColumn(x,y,w,h){ ctx.save(); ctx.translate(x,y); ctx.fillStyle='#ece9ef'; ctx.strokeStyle='rgba(166,156,173,.38)'; ctx.lineWidth=1.8; ctx.fillRect(-w/2,-h,w,h); ctx.strokeRect(-w/2,-h,w,h); for(let i=-w/2+7;i<w/2;i+=8){ ctx.beginPath(); ctx.moveTo(i,-h); ctx.lineTo(i,0); ctx.stroke(); } ctx.restore(); }
function drawSmallColumn(x,y){ ctx.save(); ctx.translate(x,y); ctx.fillStyle='#ece9ef'; ctx.strokeStyle='rgba(166,156,173,.38)'; ctx.lineWidth=1.5; ctx.fillRect(-12,-35,24,35); ctx.strokeRect(-12,-35,24,35); for(let i=-7;i<=7;i+=7){ ctx.beginPath(); ctx.moveTo(i,-35); ctx.lineTo(i,0); ctx.stroke(); } ctx.restore(); }
function drawRubble(x,y,r){ ctx.save(); ctx.translate(x,y); ctx.fillStyle='#ded9e4'; ctx.strokeStyle='rgba(164,154,169,.28)'; for(const [dx,dy,rx,ry] of [[0,0,r*.55,r*.33],[-r*.55,r*.12,r*.36,r*.24],[r*.44,r*.10,r*.34,r*.22],[0,-r*.18,r*.22,r*.18]]){ ctx.beginPath(); ctx.ellipse(dx,dy,rx,ry,0,0,Math.PI*2); ctx.fill(); ctx.stroke(); } ctx.restore(); }
function drawNpc(){
  const n=maps[map].npc, pos=screenForTile(tileCenter(n.x),tileCenter(n.y));
  const f=fieldLayout(); const s=f.step*2.65;
  ctx.fillStyle='rgba(32,33,43,.22)'; ctx.beginPath(); ctx.ellipse(pos.x,pos.y+3,s*.24,s*.07,0,0,7); ctx.fill();
  if(zigImage.complete&&zigImage.naturalWidth){ ctx.drawImage(zigImage,pos.x-s/2,pos.y-s*.85,s,s); }
  if(nearby()){ ctx.fillStyle='#a78744'; ctx.textAlign='center'; ctx.font=`${Math.max(13,f.step*.65)}px Georgia`; ctx.fillText('!',pos.x,pos.y-s*.87); }
}
function drawPlayer(){
  const p=screenForTile(player.x,player.y), frame=player.move?WALK_SEQUENCE[player.animStepIndex]:'idle';
  const ready=im=>im&&im.complete&&im.naturalWidth>0;
  let img=assets[player.dir+'_'+frame], flip=false;
  if(!ready(img)&&player.dir==='right'){ img=assets['left_'+frame]; flip=true; }
  if(!ready(img)){ img=assets[player.dir+'_idle']; flip=false; }
  if(!ready(img)&&player.dir==='right'){ img=assets.left_idle; flip=true; }
  const size=fieldLayout().step*2.65;
  ctx.fillStyle='rgba(32,33,43,.24)'; ctx.beginPath(); ctx.ellipse(p.x,p.y+4,size*.26,size*.075,0,0,7); ctx.fill();
  if(ready(img)){
    const bounce=player.move&&frame!=='idle'?STEP_BOUNCE_Y*(W/950):0; const y=p.y-size*.85+bounce;
    ctx.save(); if(flip){ ctx.translate(p.x,0); ctx.scale(-1,1); ctx.drawImage(img,-size/2,y,size,size); } else { ctx.drawImage(img,p.x-size/2,y,size,size); } ctx.restore();
  }else{ ctx.fillStyle='#dbcfd3'; ctx.beginPath(); ctx.arc(p.x,p.y-24,16,0,Math.PI*2); ctx.fill(); }
}
function render(){ drawBackground(); if(map==='庭園') drawNpc(); drawPlayer(); }
const novelRoot=document.getElementById('ch10-novel');
const novelName=document.getElementById('ch10-novel-name');
const novelText=document.getElementById('ch10-novel-text');
const novelScene=document.getElementById('ch10-novel-scene');
const novel={active:false,index:0,typed:0,timer:0,ready:false,entries:[
  {speaker:'ジグ',text:'まだ開発中だ。この先は遊べねぇぞ。'},
  {speaker:'エリ',text:'……うん。\n出来上がるのが、楽しみだね。'},
]};
function startZigNovel(){ target=null; joystick.x=joystick.y=0; setKnob(0,0); novel.active=true; novel.index=0; novelRoot.hidden=false; showNovelEntry(); }
function showNovelEntry(){ const e=novel.entries[novel.index]; if(!e){ endNovel(); return; } novelName.textContent=e.speaker; novelText.textContent=''; novel.typed=0; novel.timer=0; novel.ready=false; novelScene.textContent='灰色の庭園  —  第十章'; document.getElementById('ch10-novel-next').textContent='TAP TO CONTINUE'; }
function advanceNovel(){ if(!novel.active) return; const e=novel.entries[novel.index]; if(!novel.ready){ novelText.textContent=e.text; novel.typed=Array.from(e.text).length; novel.ready=true; return; } novel.index++; if(novel.index>=novel.entries.length){ endNovel(); return; } showNovelEntry(); }
function endNovel(){ novel.active=false; novelRoot.hidden=true; updateAnimation(0,0,0); saveNow(); }
function updateNovel(dt){ if(!novel.active||novel.ready) return; novel.timer+=dt; const chars=Array.from(novel.entries[novel.index].text); while(novel.timer>=.032&&novel.typed<chars.length){ novel.timer-=.032; novel.typed++; } novelText.textContent=chars.slice(0,novel.typed).join(''); if(novel.typed>=chars.length) novel.ready=true; }
novelRoot.addEventListener('click',advanceNovel);
const keys=new Set();
window.addEventListener('keydown',e=>{ if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key)) e.preventDefault(); keys.add(e.key.toLowerCase()); if(e.key==='Enter'||e.key===' ') interact(); if(e.key==='Escape'&&!novel.active){ overlay.hidden=false; dialog.hidden=true; } });
window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));
window.addEventListener('blur',()=>{ keys.clear(); joystick.x=joystick.y=0; target=null; setKnob(0,0); });
function inputDirection(){
  let vx=joystick.x, vy=joystick.y;
  if(keys.has('arrowleft')||keys.has('a')) vx-=1;
  if(keys.has('arrowright')||keys.has('d')) vx+=1;
  if(keys.has('arrowup')||keys.has('w')) vy-=1;
  if(keys.has('arrowdown')||keys.has('s')) vy+=1;
  if(Math.hypot(vx,vy)>.20){ if(Math.abs(vx)>Math.abs(vy)) return {dx:Math.sign(vx),dy:0}; return {dx:0,dy:Math.sign(vy)}; }
  if(target){ const cx=tileIndex(player.x), cy=tileIndex(player.y); const dx=target.x-cx, dy=target.y-cy; if(dx===0&&dy===0){ target=null; return null; } if(Math.abs(dx)>Math.abs(dy)) return {dx:Math.sign(dx),dy:0}; return {dx:0,dy:Math.sign(dy)}; }
  return null;
}
function beginTileStep(dir){ const tx=tileIndex(player.x)+dir.dx, ty=tileIndex(player.y)+dir.dy; if(!walkableTile(tx,ty) || (maps[map].npc.x===tx&&maps[map].npc.y===ty)){ target=null; player.dir=dir.dx ? (dir.dx>0?'right':'left') : (dir.dy>0?'down':'up'); return false; } tileMotion={fromX:player.x,fromY:player.y,toX:tileCenter(tx),toY:tileCenter(ty),elapsed:0,dx:dir.dx,dy:dir.dy}; return true; }
function move(dt){ if(!enabled||!overlay.hidden||!dialog.hidden||novel.active){ if(!tileMotion) updateAnimation(0,0,dt); return; } if(!tileMotion){ const dir=inputDirection(); if(!dir||!beginTileStep(dir)){ updateAnimation(0,0,dt); return; } } const motion=tileMotion; motion.elapsed=Math.min(TILE_DURATION,motion.elapsed+dt); const t=motion.elapsed/TILE_DURATION; player.x=motion.fromX+(motion.toX-motion.fromX)*t; player.y=motion.fromY+(motion.toY-motion.fromY)*t; updateAnimation(motion.dx,motion.dy,dt); if(t>=1){ player.x=motion.toX; player.y=motion.toY; tileMotion=null; const g=maps[map].gate; if(tileIndex(player.x)===g.x&&tileIndex(player.y)===g.y){ portal(); return; } saveNow(); if(!inputDirection()) updateAnimation(0,0,0); } }
function loop(ts){ const dt=Math.min(.05,Math.max(0,(ts-last)/1000||0)); last=ts; clock+=dt; move(dt); updateNovel(dt); render(); if(toastUntil&&ts>toastUntil){ document.getElementById('toast').classList.remove('show'); toastUntil=0; } requestAnimationFrame(loop); }
requestAnimationFrame(loop);
const stick=document.getElementById('stick');
const knob=document.getElementById('stick-knob');
let stickPid=null;
function setKnob(nx,ny){ const r=stick.clientWidth*.29; knob.style.transform=`translate(calc(-50% + ${nx*r}px), calc(-50% + ${ny*r}px))`; }
function setStick(e){ const b=stick.getBoundingClientRect(), cx=b.left+b.width/2, cy=b.top+b.height/2; let dx=e.clientX-cx, dy=e.clientY-cy; const r=b.width*.29, len=Math.hypot(dx,dy)||1; const clamped=Math.min(1,len/r); joystick.x=(dx/len)*clamped; joystick.y=(dy/len)*clamped; setKnob(joystick.x,joystick.y); target=null; }
function resetStick(){ stickPid=null; joystick.x=joystick.y=0; setKnob(0,0); }
stick.addEventListener('pointerdown',e=>{ e.preventDefault(); stickPid=e.pointerId; stick.setPointerCapture(e.pointerId); setStick(e); });
stick.addEventListener('pointermove',e=>{ if(e.pointerId===stickPid) setStick(e); });
stick.addEventListener('pointerup',resetStick); stick.addEventListener('pointercancel',resetStick);
canvas.addEventListener('pointerup',e=>{ if(!enabled||!overlay.hidden||!dialog.hidden||novel.active) return; const r=canvas.getBoundingClientRect(); const f=fieldLayout(), sx=e.clientX-r.left, sy=e.clientY-r.top; const wx=tileCenter(13)+(sx-f.originX)/f.step*T, wy=tileCenter(13)+(sy-f.originY)/f.step*T; const n=maps[map].npc; if(Math.hypot(wx-tileCenter(n.x),wy-tileCenter(n.y))<T*1.1&&nearby()){ interact(); return; } const tx=Math.max(3,Math.min(23,tileIndex(wx))), ty=Math.max(5,Math.min(18,tileIndex(wy))); if(walkableTile(tx,ty)) target={x:tx,y:ty}; });
document.getElementById('back-to-story').addEventListener('click',e=>{ e.stopPropagation(); try{ if(window.parent&&window.parent!==window&&typeof window.parent.closeZeraphiaCh10RPG==='function'){ window.parent.closeZeraphiaCh10RPG(); return; } }catch(_){ } history.back(); });
document.getElementById('returnToStory').addEventListener('click',()=>{ saveNow(); try{ if(window.parent&&window.parent!==window&&typeof window.parent.closeZeraphiaCh10RPG==='function'){ window.parent.closeZeraphiaCh10RPG(); return; } }catch(_){ } history.back(); });
document.getElementById('novel-skip').addEventListener('click',e=>{ e.stopPropagation(); endNovel(); });
document.getElementById('start').addEventListener('click',()=>{ enabled=true; overlay.hidden=true; pop('上下左右、1マスずつ移動します'); });
document.getElementById('menu').addEventListener('click',()=>{ saveNow(); overlay.hidden=false; });
document.getElementById('reset').addEventListener('click',()=>{ try{ localStorage.removeItem('zeraphia_ch10_rpg_demo_v1'); }catch(_){ } map='庭園'; player.x=tileCenter(13); player.y=tileCenter(13); tileMotion=null; player.dir='down'; player.animTimer=0; player.animStepIndex=0; player.move=false; save={x:player.x,y:player.y,met:false,gate:false,map}; placeEl.textContent='灰色の庭園'; questEl.textContent='目的：光の門を探す'; target=null; enabled=true; overlay.hidden=true; });
})();